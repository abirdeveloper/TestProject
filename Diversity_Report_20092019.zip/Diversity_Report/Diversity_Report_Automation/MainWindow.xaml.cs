﻿using OfficeOpenXml;
using OfficeOpenXml.Style;
using OfficeOpenXml.Table.PivotTable;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Xml;
using WPFNotification.Model;
using WPFNotification.Services;

namespace Diversity_Report_Automation
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public string excelpath ;

        EventLog eventLog = new EventLog();

        //List<DataTableCollection> dtList = new List<DataTableCollection>();

        public MainWindow()
        {
            InitializeComponent();
            excelpath = "";
        }


        private void BrowseButton_Click(object sender, RoutedEventArgs e)
        {
            // Create OpenFileDialog
            Microsoft.Win32.OpenFileDialog openFileDlg = new Microsoft.Win32.OpenFileDialog();
            openFileDlg.Multiselect = true;
            openFileDlg.Filter = "All files (*.*)|*.*";
            // Launch OpenFileDialog by calling ShowDialog method
            Nullable<bool> result = openFileDlg.ShowDialog();
            // Get the selected file name and display in a TextBox.
            // Load content of file in a TextBlock
            if (result == true)
            {
                if (openFileDlg.FileNames.Count() > 0)
                {
                    string fname = "";
                    foreach (var item in openFileDlg.FileNames)
                    {
                        fname = item + ";" + fname ;
                    }

                    FileNameTextBox.Text = fname.TrimEnd(';');
                    TextBlock1.Visibility = Visibility.Visible;
                }
                else
                    FileNameTextBox.Text = openFileDlg.FileName;
                    TextBlock1.Visibility = Visibility.Visible;


            }
        }


        private void button_Click(object sender, RoutedEventArgs e)
        {
            
            string[] filename = FileNameTextBox.Text.Split(';');           
            getData(filename);
            //Thread thread = new Thread(() => getData(filename));
            //thread.SetApartmentState(ApartmentState.STA);
            //thread.IsBackground = true;
            //thread.Start();

        }

        public void getData(string[] filename)
        {
            try
            {

                INotificationDialogService _dailogService = new NotificationDialogService();
                string con = "";
                DataSet ds = new DataSet();
                DataTableCollection dt = ds.Tables ;
         
                    for (int i = 0; i < filename.Length; i++)
                    {
                        con =
          @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filename[i] + " ;" +
          @"Extended Properties='Excel 12.0;HDR=NO;IMEX=1'";

                        if (filename[i].Contains("ROV_Report"))
                        {
                            using (OleDbConnection connection = new OleDbConnection(con))
                            {
                                connection.Open();

                                OleDbCommand commandAD = new OleDbCommand("select * from [ROV Base$]", connection);
                                commandAD.CommandType = CommandType.Text;
                                //OleDbCommand commandAD = new OleDbCommand("select * from [Abacus Demand Dump -6th Aug'19$]", connection);
                                OleDbDataAdapter myDataAdaptorAD = new OleDbDataAdapter(commandAD);
                                //OleDbDataAdapter myDataAdaptorAD = new OleDbDataAdapter(commandAD);

                                myDataAdaptorAD.Fill(ds, "ROV Base");
                                //myDataAdaptorAD.Fill(ds, "Abacus Demand Dump -6th Aug'19");
                                dt = ds.Tables;


                            }
                        }
                        if (filename[i].Contains("Resource dump"))
                        {
                            using (OleDbConnection connection = new OleDbConnection(con))
                            {
                                connection.Open();
                                OleDbCommand commandBD = new OleDbCommand("select * from [Sheet1$]", connection);
                                //OleDbCommand commandAD = new OleDbCommand("select * from [Abacus Demand Dump -6th Aug'19$]", connection);
                                OleDbDataAdapter myDataAdaptorBD = new OleDbDataAdapter(commandBD);
                                //OleDbDataAdapter myDataAdaptorAD = new OleDbDataAdapter(commandAD);

                                myDataAdaptorBD.Fill(ds, "Resource dump");
                                //myDataAdaptorAD.Fill(ds, "Abacus Demand Dump -6th Aug'19");
                                dt = ds.Tables;



                            }
                        }
                        if (filename[i].Contains("Travelers diversity"))
                        {
                            using (OleDbConnection connection = new OleDbConnection(con))
                            {
                                connection.Open();
                                OleDbCommand commandCD = new OleDbCommand("select * from [Sheet1$]", connection);
                                //OleDbCommand commandAD = new OleDbCommand("select * from [Abacus Demand Dump -6th Aug'19$]", connection);
                                OleDbDataAdapter myDataAdaptorCD = new OleDbDataAdapter(commandCD);
                                //OleDbDataAdapter myDataAdaptorAD = new OleDbDataAdapter(commandAD);

                                myDataAdaptorCD.Fill(ds, "Travelers diversity");
                                //myDataAdaptorAD.Fill(ds, "Abacus Demand Dump -6th Aug'19");
                                dt = ds.Tables;


                            }
                        }
                    if (filename[i].Contains("Demand dump"))
                    {
                        using (OleDbConnection connection = new OleDbConnection(con))
                        {
                            connection.Open();
                            OleDbCommand commandDD = new OleDbCommand("select * from [Sheet 1$]", connection);
                            //OleDbCommand commandAD = new OleDbCommand("select * from [Abacus Demand Dump -6th Aug'19$]", connection);
                            OleDbDataAdapter myDataAdaptorDD = new OleDbDataAdapter(commandDD);
                            //OleDbDataAdapter myDataAdaptorAD = new OleDbDataAdapter(commandAD);

                            myDataAdaptorDD.Fill(ds, "Demand dump");
                            //myDataAdaptorAD.Fill(ds, "Abacus Demand Dump -6th Aug'19");
                            dt = ds.Tables;


                        }
                    }

                    if (filename[i].Contains("FHL Dump"))
                    {
                        using (OleDbConnection connection = new OleDbConnection(con))
                        {
                            connection.Open();
                            OleDbCommand commandDE = new OleDbCommand("select * from [Sheet 1$]", connection);
                            //OleDbCommand commandAD = new OleDbCommand("select * from [Abacus Demand Dump -6th Aug'19$]", connection);
                            OleDbDataAdapter myDataAdaptorDE = new OleDbDataAdapter(commandDE);
                            //OleDbDataAdapter myDataAdaptorAD = new OleDbDataAdapter(commandAD);

                            myDataAdaptorDE.Fill(ds, "FHL dump");
                            //myDataAdaptorAD.Fill(ds, "Abacus Demand Dump -6th Aug'19");
                            dt = ds.Tables;


                        }
                    }



                }
                string startupPath = System.AppDomain.CurrentDomain.BaseDirectory + "ASE Status.xlsx";

                con =
      @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + startupPath + " ;" +
      @"Extended Properties='Excel 12.0;HDR=NO;IMEX=1'";

                using (OleDbConnection connection = new OleDbConnection(con))
                {
                    connection.Open();
                    OleDbCommand commandDF = new OleDbCommand("select * from [Sheet1$]", connection);
                    //OleDbCommand commandAD = new OleDbCommand("select * from [Abacus Demand Dump -6th Aug'19$]", connection);
                    OleDbDataAdapter myDataAdaptorDF = new OleDbDataAdapter(commandDF);
                    //OleDbDataAdapter myDataAdaptorAD = new OleDbDataAdapter(commandAD);

                    myDataAdaptorDF.Fill(ds, "ASE Status");
                    //myDataAdaptorAD.Fill(ds, "Abacus Demand Dump -6th Aug'19");
                    dt = ds.Tables;


                }

                generateExcel(dt);
                TextBlock1.Text = "Completed";
                var newNotification = new Notification()
                {
                    Title = "Excel Created",
                    Message = "Excel file created , you can find the file : " + excelpath
                };
                _dailogService.ShowNotificationWindow(newNotification);

            }
            catch (Exception ex)
            {
                MessageBox.Show("A handled exception just occurred: " + ex.Message, "Exception : ", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        public void generateExcel(DataTableCollection Dtvalue)
        {
     
            try
            {

                String timeStamp = GetTimestamp(DateTime.Now);

                if (!Directory.Exists(@"C:\RE__Diversity_report"))
                    Directory.CreateDirectory(@"C:\RE__Diversity_report");

                excelpath = @"C:\RE__Diversity_report\Diversity Calculation_" + timeStamp + ".xlsx";

                DateTime date = DateTime.Now;
                string dateFormat = string.Format("{0:dd MMM yy}", date);

                FileInfo finame = new FileInfo(excelpath);
                string ROV = "ROV-" + dateFormat;
                string RES = "Res Dump-" + dateFormat;
                string Abacus = "Abacus Demand Dump -" + dateFormat;
                string FHL = "FHL Dump -" + dateFormat;
                if (!System.IO.File.Exists(excelpath))
                {

                    using (ExcelPackage excel = new ExcelPackage())
                    {

                        ExcelWorksheet ws =  excel.Workbook.Worksheets.Add(RES);
                        ExcelWorksheet ws2 = excel.Workbook.Worksheets.Add(ROV);
                        ExcelWorksheet ws3 = excel.Workbook.Worksheets.Add("Base");
                        ExcelWorksheet ws4 = excel.Workbook.Worksheets.Add(Abacus);
                        ExcelWorksheet ws5 = excel.Workbook.Worksheets.Add(FHL);
                        ExcelWorksheet ws6 = excel.Workbook.Worksheets.Add("ASE Status");
                        ExcelWorksheet wsPivot = excel.Workbook.Worksheets.Add("Pivot-Base");
                        ExcelWorksheet wsPivot1 = excel.Workbook.Worksheets.Add("Abacus-Pivot");

                        int count  = 0;
                        int count1 = 0;
                        int count2 = 0;
                        int count3 = 0;
                        int count4 = 0;
                        int count5 = 0;

                        for (int y = 0; y < Dtvalue.Count; y++)
                        {
                            #region FHL Dump

                            if (Dtvalue[y].TableName == "FHL dump")
                            {
                                foreach (DataRow dr in Dtvalue[y].Rows.Cast<DataRow>().Skip(3))
                                {
                                    count4 = count4 + 1;
                                    int n = 0;
                                    for (int j = 8; j <= 127; j++)
                                    {
                                        n = n + 1;
                                        int result4;
                                        var isNumeric = int.TryParse(dr.ItemArray[j].ToString(), out result4);
                                        if (isNumeric == true)
                                        {
                                            ws5.Cells[count4, n].Value = Convert.ToInt32(dr.ItemArray[j]);
                                            ws5.Cells[count4, n].Style.Numberformat.Format = "0";
                                        }
                                        else
                                        {
                                            ws5.Cells[count4, n].Value = dr.ItemArray[j].ToString();
                                        }

                                        if (count4 == 1)
                                        {

                                            ws5.Cells[count4, n].Style.Font.Bold = true;
                                            ws5.Cells[count4, n].Style.Font.Size = 10;
                                            ws5.Cells[count4, n].Style.Font.Name = "Verdana";

                                        }


                                        if (dr.ItemArray[j] == null)
                                        {
                                            break;
                                        }
                                    }

                                }
                            }
                            #endregion

                            #region Abacus Demand Dump

                            if (Dtvalue[y].TableName == "Demand dump")
                            {
                                foreach (DataRow dr in Dtvalue[y].Rows.Cast<DataRow>().Skip(3))
                                {
                                    count3 = count3 + 1;
                                    int n = 0;

                                    for (int j = 8; j <= 130; j++)
                                    {

                                        n = n + 1;
                                        int result3;
                                        var isNumeric = int.TryParse(dr.ItemArray[j].ToString(), out result3);
                                        if (isNumeric == true)
                                        {
                                            ws4.Cells[count3, n].Value = Convert.ToInt32(dr.ItemArray[j]);
                                            ws4.Cells[count3, n].Style.Numberformat.Format = "0";
                                        }
                                        else
                                        {
                                            ws4.Cells[count3, n].Value = dr.ItemArray[j].ToString();
                                        }

                                        if (count3 == 1)
                                        {

                                            ws4.Cells[count3, n].Style.Font.Bold = true;
                                            ws4.Cells[count3, n].Style.Font.Size = 10;
                                            ws4.Cells[count3, n].Style.Font.Name = "Verdana";

                                        }


                                        if (dr.ItemArray[j] == null)
                                        {
                                            break;
                                        }


                                    }

                                }
                            }

                            #endregion

                            #region Resource Dump
                            if (Dtvalue[y].TableName == "Resource dump")
                            {
                                foreach (DataRow dr in Dtvalue[y].Rows.Cast<DataRow>().Skip(3))
                                {
                                    count1 = count1 + 1;
                                    int n = 0;
                                    for (int j = 0; j <= 142; j++)
                                    {
                                        n = n + 1;
                                        if (j <= 138)
                                        {
                                            int result;
                                            var isNumeric = int.TryParse(dr.ItemArray[j].ToString(), out result);
                                            if (isNumeric == true)
                                            {
                                                ws.Cells[count1, n].Value = Convert.ToInt32(dr.ItemArray[j]);
                                                ws.Cells[count1, n].Style.Numberformat.Format = "0";
                                            }
                                            else
                                            {
                                                ws.Cells[count1, n].Value = dr.ItemArray[j].ToString();
                                            }

                                            if (count1 == 1)
                                            {

                                                ws.Cells[count1, n].Style.Font.Bold = true;
                                                ws.Cells[count1, n].Style.Font.Size = 10;
                                                ws.Cells[count1, n].Style.Font.Name = "Verdana";

                                            }

                                        }


                                        if (j == 139)
                                        {

                                            if (count1 == 1)
                                            {
                                                ws.Cells[count1, n].Value = "Lock Start Month";
                                                ws.Cells[count1, n].Style.Font.Bold = true;
                                                ws.Cells[count1, n].Style.Font.Size = 10;
                                                ws.Cells[count1, n].Style.Font.Name = "Verdana";
                                                ws.Cells[count1, n].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                                ws.Cells[count1, n].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);

                                            }
                                            else
                                            {
                                                //ws3.Cells[count2, n].Formula = "VLOOKUP(C" + count2 + ",'Res Dump-6th Aug''19'!$Q:Q,1,0)";
                                                ws.Cells[count1, n].Formula = "TEXT(AE" + count1 + ",\"mmm-yy\")";


                                            }


                                        }
                                        if (j == 140)
                                        {

                                            if (count1 == 1)
                                            {
                                                ws.Cells[count1, n].Value = "Base Data";
                                                ws.Cells[count1, n].Style.Font.Bold = true;
                                                ws.Cells[count1, n].Style.Font.Size = 10;
                                                ws.Cells[count1, n].Style.Font.Name = "Verdana";
                                                ws.Cells[count1, n].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                                ws.Cells[count1, n].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);

                                            }
                                            else
                                            {
                                                //ws3.Cells[count2, n].Formula = "VLOOKUP(C" + count2 + ",'Res Dump-6th Aug''19'!$Q:Q,1,0)";
                                                ws.Cells[count1, n].Formula = "VLOOKUP(Q" + count1 + ",'Base'!$C:C,1,0)";


                                            }
                                           

                                        }

                                        if (j == 141)
                                        {
                                            if (count1 == 1)
                                            {
                                                ws.Cells[count1, n].Value = "Personnel No.";
                                                ws.Cells[count1, n].Style.Font.Bold = true;
                                                ws.Cells[count1, n].Style.Font.Size = 10;
                                                ws.Cells[count1, n].Style.Font.Name = "Verdana";
                                                ws.Cells[count1, n].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                                ws.Cells[count1, n].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);

                                            }
                                            else
                                            {
                                                //ws3.Cells[count2, n].Formula = "VLOOKUP(C" + count2 + ",'Res Dump-6th Aug''19'!$Q:Q,1,0)";
                                                ws.Cells[count1, n].Formula = "VLOOKUP(Q" + count1 + ",'" + ws.Name + "'!$Q:Q,1,0)";
                                                
                                            }

                                        }

                                        if (j == 142)
                                        {

                                            if (count1 == 1)
                                            {
                                                ws.Cells[count1, n].Value = "Status";
                                                ws.Cells[count1, n].Style.Font.Bold = true;
                                                ws.Cells[count1, n].Style.Font.Size = 10;
                                                ws.Cells[count1, n].Style.Font.Name = "Verdana";
                                                ws.Cells[count1, n].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                                ws.Cells[count1, n].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);

                                            }
                                            else
                                            {
                                                //ws3.Cells[count2, n].Formula = "VLOOKUP(C" + count2 + ",'Res Dump-6th Aug''19'!$Q:Q,1,0)";
                                                ws.Cells[count1, n].Formula = "VLOOKUP(R" + count1 + ",'" + ws.Name + "'!$R:R,1,0)";

                                            }


                                        }



                                    }
                                }
                            }
                            #endregion

                            #region Rov Base  
                            if (Dtvalue[y].TableName == "ROV Base")
                            {
                                foreach (DataRow dr in Dtvalue[y].Rows.Cast<DataRow>().Where(
      row => row.ItemArray.Any(field => !(field is System.DBNull))))
                                {

                                    count = count + 1;
                                    int n = 0;

                                    for (int j = 0; j <= 23; j++)
                                    {

                                        n = n + 1;
                                        int result1;
                                        var isNumeric = int.TryParse(dr.ItemArray[j].ToString(), out result1);
                                        if (isNumeric == true)
                                        {
                                            ws2.Cells[count, n].Value = Convert.ToInt32(dr.ItemArray[j]);
                                            ws2.Cells[count, n].Style.Numberformat.Format = "0";
                                        }
                                        else
                                        {
                                            ws2.Cells[count, n].Value = dr.ItemArray[j].ToString();
                                        }
                                        if (count == 1)
                                        {

                                            ws2.Cells[count, n].Style.Font.Bold = true;
                                            ws2.Cells[count, n].Style.Font.Size = 10;
                                            ws2.Cells[count, n].Style.Font.Name = "Verdana";

                                        }


                                        if (dr.ItemArray[j] == null)
                                        {
                                            break;
                                        }


                                    }
                                }
                            }
                            #endregion

                            #region  Travelers diversity

                            if (Dtvalue[y].TableName == "Travelers diversity")
                            {
                                foreach (DataRow dr in Dtvalue[y].Rows)
                                {
                                    count2 = count2 + 1;
                                    int n = 0;

                                    for (int j = 0; j <= 49; j++)
                                    {

                                        n = n + 1;

                                        if (j <= 44)
                                        {
                                            int result2;
                                            var isNumeric = int.TryParse(dr.ItemArray[j].ToString(), out result2);
                                            if (isNumeric == true)
                                            {
                                                ws3.Cells[count2, n].Value = Convert.ToInt32(dr.ItemArray[j]);
                                                ws3.Cells[count2, n].Style.Numberformat.Format = "0";
                                            }
                                            else
                                            {
                                                ws3.Cells[count2, n].Value = dr.ItemArray[j].ToString();
                                            }
                                            if (count2 == 1)
                                            {

                                                ws3.Cells[count2, n].Style.Font.Bold = true;
                                                ws3.Cells[count2, n].Style.Font.Size = 10;
                                                ws3.Cells[count2, n].Style.Font.Name = "Verdana";

                                            }
                                        }
                                        if (j == 45)
                                        {

                                            if (count2 == 1)
                                            {
                                                ws3.Cells[count2, n].Value = "Resource Dump_Abacus";
                                                ws3.Cells[count2, n].Style.Font.Bold = true;
                                                ws3.Cells[count2, n].Style.Font.Size = 10;
                                                ws3.Cells[count2, n].Style.Font.Name = "Verdana";
                                                ws3.Cells[count2, n].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                                ws3.Cells[count2, n].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);

                                            }
                                            else
                                            {
                                                //ws3.Cells[count2, n].Formula = "VLOOKUP(C" + count2 + ",'Res Dump-6th Aug''19'!$Q:Q,1,0)";
                                                ws3.Cells[count2, n].Formula = "VLOOKUP(C" + count2 + ",'" + ws.Name + "'!$Q:Q,1,0)";
                                            }
                                        }
                                        if (j == 46)
                                        {

                                            if (count2 == 1)
                                            {
                                                ws3.Cells[count2, n].Value = ws2.Name;
                                                ws3.Cells[count2, n].Style.Font.Bold = true;
                                                ws3.Cells[count2, n].Style.Font.Size = 10;
                                                ws3.Cells[count2, n].Style.Font.Name = "Verdana";
                                                ws3.Cells[count2, n].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                                ws3.Cells[count2, n].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);

                                            }
                                            else
                                            {
                                                //ws3.Cells[count2, n].Formula = "VLOOKUP(C" + count2 + ",'ROV-6th Aug''19'!B:Q,16,0)";

                                                ws3.Cells[count2, n].Formula = "VLOOKUP(C" + count2 + ",'" + ws2.Name + "'!B:Q,16,0)";
                                            }
                                        }
                                        if (j == 47)
                                        {

                                            if (count2 == 1)
                                            {
                                                ws3.Cells[count2, n].Value = "ROV Date";
                                                ws3.Cells[count2, n].Style.Font.Bold = true;
                                                ws3.Cells[count2, n].Style.Font.Size = 10;
                                                ws3.Cells[count2, n].Style.Font.Name = "Verdana";
                                                ws3.Cells[count2, n].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                                ws3.Cells[count2, n].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);
                                            }
                                            else
                                            {
                                                //ws3.Cells[count2, n].Formula = "VLOOKUP(C" + count2 + ",'ROV-6th Aug''19'!B:M,12,0)";
                                                ws3.Cells[count2, n].Formula = "VLOOKUP(C" + count2 + ",'" + ws2.Name + "'!B:M,12,0)";

                                            }
                                        }
                                        if (j == 48)
                                        {

                                            if (count2 == 1)
                                            {
                                                ws3.Cells[count2, n].Value = "ROV Month";
                                                ws3.Cells[count2, n].Style.Font.Bold = true;
                                                ws3.Cells[count2, n].Style.Font.Size = 10;
                                                ws3.Cells[count2, n].Style.Font.Name = "Verdana";
                                                ws3.Cells[count2, n].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                                ws3.Cells[count2, n].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);
                                            }
                                            else
                                            {
                                                ws3.Cells[count2, n].Formula = "TEXT(AV" + count2 + ", \"mmm-yy\")";

                                            }
                                        }
                                        if (j == 49)
                                        {
                                            if (count2 == 1)
                                            {
                                                ws3.Cells[count2, n].Value = "Personnel No";
                                                ws3.Cells[count2, n].Style.Font.Bold = true;
                                                ws3.Cells[count2, n].Style.Font.Size = 10;
                                                ws3.Cells[count2, n].Style.Font.Name = "Verdana";
                                                ws3.Cells[count2, n].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                                ws3.Cells[count2, n].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);
                                            }
                                            else
                                            {
                                                ws3.Cells[count2, n].Formula = "VLOOKUP(C" + count2 + ",'" + ws3.Name + "'!$C:C,1,0)";

                                            }
                                        }



                                    }

                                }
                            }
                            #endregion

                            #region ASE Status
                            if (Dtvalue[y].TableName == "ASE Status")
                            {
                                foreach (DataRow dr in Dtvalue[y].Rows)
                                {
                                    count5 = count5 + 1;
                                    int n = 0;

                                    for (int j = 0; j <= 13; j++)
                                    {
                                        n = n + 1;

                                        if (j <= 7)
                                        {
                                            int result6;
                                            var isNumeric = int.TryParse(dr.ItemArray[j].ToString(), out result6);
                                            if (isNumeric == true)
                                            {
                                                ws6.Cells[count5, n].Value = Convert.ToInt32(dr.ItemArray[j]);
                                                ws6.Cells[count5, n].Style.Numberformat.Format = "0";
                                            }
                                            else
                                            {
                                                ws6.Cells[count5, n].Value = dr.ItemArray[j].ToString();
                                            }
                                            if (count5 == 1)
                                            {

                                                ws6.Cells[count5, n].Style.Font.Bold = true;
                                                ws6.Cells[count5, n].Style.Font.Size = 10;
                                                ws6.Cells[count5, n].Style.Font.Name = "Verdana";

                                            }
                                        }

                                        if (j == 8)
                                        {

                                            if (count5 == 1)
                                            {
                                                ws6.Cells[count5, n].Value = "Emp Id";
                                                ws6.Cells[count5, n].Style.Font.Bold = true;
                                                ws6.Cells[count5, n].Style.Font.Size = 10;
                                                ws6.Cells[count5, n].Style.Font.Name = "Verdana";
                                                ws6.Cells[count5, n].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                                ws6.Cells[count5, n].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);

                                            }
                                            else
                                            {
                                                ws6.Cells[count5, n].Formula = "VLOOKUP(B" + count5 + ",'" + ws.Name + "'!Y:EL,118,0)";
                                            }
                                        }

                                        if (j == 9)
                                        {

                                            if (count5 == 1)
                                            {
                                                ws6.Cells[count5, n].Value = "Lock Start Date";
                                                ws6.Cells[count5, n].Style.Font.Bold = true;
                                                ws6.Cells[count5, n].Style.Font.Size = 10;
                                                ws6.Cells[count5, n].Style.Font.Name = "Verdana";
                                                ws6.Cells[count5, n].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                                ws6.Cells[count5, n].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);

                                            }
                                            else
                                            {
                                                ws6.Cells[count5, n].Formula = "VLOOKUP(B" + count5 + ",'" + ws.Name + "'!Y:AE,7,0)";
                                            }
                                        }

                                        if (j == 10)
                                        {

                                            if (count5 == 1)
                                            {
                                                ws6.Cells[count5, n].Value = "Demand";
                                                ws6.Cells[count5, n].Style.Font.Bold = true;
                                                ws6.Cells[count5, n].Style.Font.Size = 10;
                                                ws6.Cells[count5, n].Style.Font.Name = "Verdana";
                                                ws6.Cells[count5, n].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                                ws6.Cells[count5, n].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);

                                            }
                                            else
                                            {
                                                ws6.Cells[count5, n].Formula = "VLOOKUP(B" + count5 + ",'" + ws4.Name + "'!A:D,4,0)";
                                            }
                                        }

                                        if (j == 11)
                                        {

                                            if (count5 == 1)
                                            {
                                                ws6.Cells[count5, n].Value = "PMO Status";
                                                ws6.Cells[count5, n].Style.Font.Bold = true;
                                                ws6.Cells[count5, n].Style.Font.Size = 10;
                                                ws6.Cells[count5, n].Style.Font.Name = "Verdana";
                                                ws6.Cells[count5, n].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                                ws6.Cells[count5, n].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);

                                            }
                                            else
                                            {
                                                //ws6.Cells[count5, n].Formula = "IF(K" + count5 + " = \"Yes\", \"Open Demand\" , IF(I" + count5 + " > 0 , \"Fulfilled\" , \"FHL\" ))";
                                               ws6.Cells[count5, n].Formula = "IF(I" + count5 + " > 0, \"Fulfilled\" , \"Open Demand\" )";
                                               //ws6.Cells[count5, n].Formula = "VLOOKUP(B" + count5 + ",'" + ws4.Name + "'!A:D,4,0)";
                                            }
                                        }

                                        if (j == 12)
                                        {

                                            if (count5 == 1)
                                            {
                                                ws6.Cells[count5, n].Value = "Gender";
                                                ws6.Cells[count5, n].Style.Font.Bold = true;
                                                ws6.Cells[count5, n].Style.Font.Size = 10;
                                                ws6.Cells[count5, n].Style.Font.Name = "Verdana";
                                                ws6.Cells[count5, n].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                                ws6.Cells[count5, n].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);

                                            }
                                            else
                                            {
                                                ws6.Cells[count5, n].Formula = "VLOOKUP(B" + count5 + ",'" + ws.Name + "'!Y:CF,60,0)";
                                               
                                            }
                                        }
                                    }
                                }
                            }
                            #endregion
                        }

                        #region Pivot logic for Base

                        var dataRangeBase = ws3.Cells[ws3.Dimension.Address.ToString()];
                        dataRangeBase.AutoFitColumns();

                        #region Block-1
                        var pivotTableBase = wsPivot.PivotTables.Add(wsPivot.Cells[3,1], dataRangeBase, "Pivot Base");
                        pivotTableBase.MultipleFieldFilters = true;
                        pivotTableBase.RowGrandTotals = true;
                        pivotTableBase.ColumnGrandTotals = true;
                        pivotTableBase.Compact = true;
                        pivotTableBase.CompactData = true;
                        pivotTableBase.GridDropZones = false;
                        pivotTableBase.Outline = false;
                        pivotTableBase.OutlineData = false;
                        pivotTableBase.ShowError = true;
                        pivotTableBase.ErrorCaption = "[error]";
                        pivotTableBase.ShowHeaders = true;
                        pivotTableBase.UseAutoFormatting = true;
                        pivotTableBase.ApplyWidthHeightFormats = true;
                        pivotTableBase.ShowDrill = true;
                        pivotTableBase.FirstDataCol = 3;
                        pivotTableBase.RowHeaderCaption = "GW Excluded";

                        var NameField = pivotTableBase.Fields["Name"];
                        pivotTableBase.DataFields.Add(NameField);
                        pivotTableBase.DataFields[0].Function = DataFieldFunctions.Count;

                        var careerField = pivotTableBase.Fields["Career Level"];
                        pivotTableBase.ColumnFields.Add(careerField);

                        var DUField = pivotTableBase.Fields["DU"];
                        pivotTableBase.RowFields.Add(DUField);
                        #endregion

                        #region Block-2
                        var pivotTableBase_1 = wsPivot.PivotTables.Add(wsPivot.Cells[3,16], dataRangeBase, "Pivot Base -1");
                        pivotTableBase_1.MultipleFieldFilters = true;
                        pivotTableBase_1.RowGrandTotals = true;
                        pivotTableBase_1.ColumnGrandTotals = true;
                        pivotTableBase_1.Compact = true;
                        pivotTableBase_1.CompactData = true;
                        pivotTableBase_1.GridDropZones = false;
                        pivotTableBase_1.Outline = false;
                        pivotTableBase_1.OutlineData = false;
                        pivotTableBase_1.ShowError = true;
                        pivotTableBase_1.ErrorCaption = "[error]";
                        pivotTableBase_1.ShowHeaders = true;
                        pivotTableBase_1.UseAutoFormatting = true;
                        pivotTableBase_1.ApplyWidthHeightFormats = true;
                        pivotTableBase_1.ShowDrill = true;
                        pivotTableBase_1.FirstDataCol = 3;

                        var GenderBaseField_1 = pivotTableBase_1.Fields["Gender"];
                        pivotTableBase_1.PageFields.Add(GenderBaseField_1);

                        var ROVField_1 = pivotTableBase_1.Fields[ROV];
                        pivotTableBase_1.PageFields.Add(ROVField_1);

                        var ROVMonthField_1 = pivotTableBase_1.Fields["ROV Month"];
                        pivotTableBase_1.PageFields.Add(ROVMonthField_1);

                        var ResAbacusField_1 = pivotTableBase_1.Fields["Resource Dump_Abacus"];
                        pivotTableBase_1.PageFields.Add(ResAbacusField_1);

                        var NameField_1 = pivotTableBase_1.Fields["Name"];
                        pivotTableBase_1.DataFields.Add(NameField_1);
                        pivotTableBase_1.DataFields[0].Function = DataFieldFunctions.Count;

                        var careerField_1 = pivotTableBase_1.Fields["Career Level"];
                        pivotTableBase_1.ColumnFields.Add(careerField_1);

                        var DUField_1 = pivotTableBase_1.Fields["DU"];
                        pivotTableBase_1.RowFields.Add(DUField_1);
                        #endregion

                        #region Block-3
                        var pivotTableBase_2 = wsPivot.PivotTables.Add(wsPivot.Cells[18, 1], dataRangeBase, "Pivot Base -2");
                        pivotTableBase_2.MultipleFieldFilters = true;
                        pivotTableBase_2.RowGrandTotals = true;
                        pivotTableBase_2.ColumnGrandTotals = true;
                        pivotTableBase_2.Compact = true;
                        pivotTableBase_2.CompactData = true;
                        pivotTableBase_2.GridDropZones = false;
                        pivotTableBase_2.Outline = false;
                        pivotTableBase_2.OutlineData = false;
                        pivotTableBase_2.ShowError = true;
                        pivotTableBase_2.ErrorCaption = "[error]";
                        pivotTableBase_2.ShowHeaders = true;
                        pivotTableBase_2.UseAutoFormatting = true;
                        pivotTableBase_2.ApplyWidthHeightFormats = true;
                        pivotTableBase_2.ShowDrill = true;
                        pivotTableBase_2.FirstDataCol = 3;

                        var GenderBaseField_2 = pivotTableBase_2.Fields["Gender"];
                        pivotTableBase_2.PageFields.Add(GenderBaseField_2);

                        var NameField_2 = pivotTableBase_2.Fields["Name"];
                        pivotTableBase_2.DataFields.Add(NameField_2);
                        pivotTableBase_2.DataFields[0].Function = DataFieldFunctions.Count;

                        var careerField_2 = pivotTableBase_2.Fields["Career Level"];
                        pivotTableBase_2.ColumnFields.Add(careerField_2);

                        var DUField_2 = pivotTableBase_2.Fields["DU"];
                        pivotTableBase_2.RowFields.Add(DUField_2);
                        #endregion

                        #region Block-4
                        var pivotTableBase_3 = wsPivot.PivotTables.Add(wsPivot.Cells[24, 16], dataRangeBase, "Pivot Base -3");
                        pivotTableBase_3.MultipleFieldFilters = true;
                        pivotTableBase_3.RowGrandTotals = true;
                        pivotTableBase_3.ColumnGrandTotals = true;
                        pivotTableBase_3.Compact = true;
                        pivotTableBase_3.CompactData = true;
                        pivotTableBase_3.GridDropZones = false;
                        pivotTableBase_3.Outline = false;
                        pivotTableBase_3.OutlineData = false;
                        pivotTableBase_3.ShowError = true;
                        pivotTableBase_3.ErrorCaption = "[error]";
                        pivotTableBase_3.ShowHeaders = true;
                        pivotTableBase_3.UseAutoFormatting = true;
                        pivotTableBase_3.ApplyWidthHeightFormats = true;
                        pivotTableBase_3.ShowDrill = true;
                        pivotTableBase_3.FirstDataCol = 3;

                        var GenderBaseField_3 = pivotTableBase_3.Fields["Gender"];
                        pivotTableBase_3.PageFields.Add(GenderBaseField_3);

                        var ROVField_3 = pivotTableBase_3.Fields[ROV];
                        pivotTableBase_3.PageFields.Add(ROVField_3);

                        var ROVMonthField_3 = pivotTableBase_3.Fields["ROV Month"];
                        pivotTableBase_3.PageFields.Add(ROVMonthField_3);
                       
                        var ResAbacusField_3 = pivotTableBase_3.Fields["Resource Dump_Abacus"];
                        pivotTableBase_3.PageFields.Add(ResAbacusField_3);

                        var NameField_3 = pivotTableBase_3.Fields["Name"];
                        pivotTableBase_3.DataFields.Add(NameField_3);
                        pivotTableBase_3.DataFields[0].Function = DataFieldFunctions.Count;

                        var careerField_3 = pivotTableBase_3.Fields["Career Level"];
                        pivotTableBase_3.ColumnFields.Add(careerField_3);

                        var DUField_3 = pivotTableBase_3.Fields["DU"];
                        pivotTableBase_3.RowFields.Add(DUField_3);


                        #endregion


                        #endregion

                        #region Pivot logic for Resource Dump


                        var dataRangeResourcedump = ws.Cells[ws.Dimension.Address.ToString()];
                        dataRangeResourcedump.AutoFitColumns();


                        #region Block-1
                        var pivotTableResource = wsPivot1.PivotTables.Add(wsPivot1.Cells[3,1], dataRangeResourcedump, "Abacus Pivot");
                        pivotTableResource.MultipleFieldFilters = true;
                        pivotTableResource.RowGrandTotals = true;
                        pivotTableResource.ColumnGrandTotals = true;
                        pivotTableResource.Compact = true;
                        pivotTableResource.CompactData = true;
                        pivotTableResource.GridDropZones = false;
                        pivotTableResource.Outline = false;
                        pivotTableResource.OutlineData = false;
                        pivotTableResource.ShowError = true;
                        pivotTableResource.ErrorCaption = "[error]";
                        pivotTableResource.ShowHeaders = true;
                        pivotTableResource.UseAutoFormatting = true;
                        pivotTableResource.ApplyWidthHeightFormats = true;
                        pivotTableResource.ShowDrill = true;
                        pivotTableResource.FirstDataCol = 3;

                        var LOCField = pivotTableResource.Fields["Lock Start Month"];
                        pivotTableResource.PageFields.Add(LOCField);

                        var BasedtField = pivotTableResource.Fields["Base Data"];
                        pivotTableResource.PageFields.Add(BasedtField);

                        var CRField = pivotTableResource.Fields["Career Level"];
                        pivotTableResource.DataFields.Add(CRField);
                        pivotTableResource.DataFields[0].Function = DataFieldFunctions.Count;

                        var CRField1 = pivotTableResource.Fields["Career Level"];
                        pivotTableResource.ColumnFields.Add(CRField1);

                        var DUFieldRES = pivotTableResource.Fields["DU"];
                        pivotTableResource.RowFields.Add(DUFieldRES);

                        #endregion

                        #region Block-2
                        var pivotTableResource_1 = wsPivot1.PivotTables.Add(wsPivot1.Cells[3, 12], dataRangeResourcedump, "Abacus Pivot-1");
                        pivotTableResource_1.MultipleFieldFilters = true;
                        pivotTableResource_1.RowGrandTotals = true;
                        pivotTableResource_1.ColumnGrandTotals = true;
                        pivotTableResource_1.Compact = true;
                        pivotTableResource_1.CompactData = true;
                        pivotTableResource_1.GridDropZones = false;
                        pivotTableResource_1.Outline = false;
                        pivotTableResource_1.OutlineData = false;
                        pivotTableResource_1.ShowError = true;
                        pivotTableResource_1.ErrorCaption = "[error]";
                        pivotTableResource_1.ShowHeaders = true;
                        pivotTableResource_1.UseAutoFormatting = true;
                        pivotTableResource_1.ApplyWidthHeightFormats = true;
                        pivotTableResource_1.ShowDrill = true;
                        pivotTableResource_1.FirstDataCol = 3;

                        var BasedtField_1 = pivotTableResource_1.Fields["Base Data"];
                        pivotTableResource_1.PageFields.Add(BasedtField_1);

                        var StatustField_1 = pivotTableResource_1.Fields["Status"];
                        pivotTableResource_1.PageFields.Add(StatustField_1);

                        var JoindateField_1 = pivotTableResource_1.Fields["Join Date"];
                        pivotTableResource_1.PageFields.Add(JoindateField_1);

                        var GenderField_1 = pivotTableResource_1.Fields["Gender"];
                        pivotTableResource_1.PageFields.Add(GenderField_1);

                        var CRField_1 = pivotTableResource_1.Fields["Career Level"];
                        pivotTableResource_1.DataFields.Add(CRField_1);
                        pivotTableResource_1.DataFields[0].Function = DataFieldFunctions.Count;

                        var CRField_2 = pivotTableResource_1.Fields["Career Level"];
                        pivotTableResource_1.ColumnFields.Add(CRField_2);

                        var DUFieldRES_1 = pivotTableResource_1.Fields["DU"];
                        pivotTableResource_1.RowFields.Add(DUFieldRES_1);

                        #endregion

                        #region Block-3
                        var pivotTableResource_2 = wsPivot1.PivotTables.Add(wsPivot1.Cells[18, 1], dataRangeResourcedump, "Abacus Pivot -2");
                        pivotTableResource_2.MultipleFieldFilters = true;
                        pivotTableResource_2.RowGrandTotals = true;
                        pivotTableResource_2.ColumnGrandTotals = true;
                        pivotTableResource_2.Compact = true;
                        pivotTableResource_2.CompactData = true;
                        pivotTableResource_2.GridDropZones = false;
                        pivotTableResource_2.Outline = false;
                        pivotTableResource_2.OutlineData = false;
                        pivotTableResource_2.ShowError = true;
                        pivotTableResource_2.ErrorCaption = "[error]";
                        pivotTableResource_2.ShowHeaders = true;
                        pivotTableResource_2.UseAutoFormatting = true;
                        pivotTableResource_2.ApplyWidthHeightFormats = true;
                        pivotTableResource_2.ShowDrill = true;
                        pivotTableResource_2.FirstDataCol = 3;

                        var RSLOCField2 = pivotTableResource_2.Fields["Lock Start Month"];
                        pivotTableResource_2.PageFields.Add(RSLOCField2);

                        var RSBasedtField2 = pivotTableResource_2.Fields["Base Data"];
                        pivotTableResource_2.PageFields.Add(RSBasedtField2);

                        var RSGenderField2 = pivotTableResource_2.Fields["Gender"];
                        pivotTableResource_2.PageFields.Add(RSGenderField2);

                        var CRField22 = pivotTableResource_2.Fields["Career Level"];
                        pivotTableResource_2.DataFields.Add(CRField22);
                        pivotTableResource_2.DataFields[0].Function = DataFieldFunctions.Count;

                        var CRField12 = pivotTableResource_2.Fields["Career Level"];
                        pivotTableResource_2.ColumnFields.Add(CRField12);

                        var DUFieldRES2 = pivotTableResource_2.Fields["DU"];
                        pivotTableResource_2.RowFields.Add(DUFieldRES2);

                        #endregion

                        #region Block-4
                        var pivotTableResource_3 = wsPivot1.PivotTables.Add(wsPivot1.Cells[24, 12], dataRangeResourcedump, "Abacus Pivot-3");
                        pivotTableResource_3.MultipleFieldFilters = true;
                        pivotTableResource_3.RowGrandTotals = true;
                        pivotTableResource_3.ColumnGrandTotals = true;
                        pivotTableResource_3.Compact = true;
                        pivotTableResource_3.CompactData = true;
                        pivotTableResource_3.GridDropZones = false;
                        pivotTableResource_3.Outline = false;
                        pivotTableResource_3.OutlineData = false;
                        pivotTableResource_3.ShowError = true;
                        pivotTableResource_3.ErrorCaption = "[error]";
                        pivotTableResource_3.ShowHeaders = true;
                        pivotTableResource_3.UseAutoFormatting = true;
                        pivotTableResource_3.ApplyWidthHeightFormats = true;
                        pivotTableResource_3.ShowDrill = true;
                        pivotTableResource_3.FirstDataCol = 3;

                        var BasedtField_31 = pivotTableResource_3.Fields["Base Data"];
                        pivotTableResource_3.PageFields.Add(BasedtField_31);

                        var StatustField_31 = pivotTableResource_3.Fields["Status"];
                        pivotTableResource_3.PageFields.Add(StatustField_31);

                        var JoindateField_31 = pivotTableResource_3.Fields["Join Date"];
                        pivotTableResource_3.PageFields.Add(JoindateField_31);

                        var GenderField_31 = pivotTableResource_3.Fields["Gender"];
                        pivotTableResource_3.PageFields.Add(GenderField_31);

                        var CRField_31 = pivotTableResource_3.Fields["Career Level"];
                        pivotTableResource_3.DataFields.Add(CRField_31);
                        pivotTableResource_3.DataFields[0].Function = DataFieldFunctions.Count;

                        var CRField_32 = pivotTableResource_3.Fields["Career Level"];
                        pivotTableResource_3.ColumnFields.Add(CRField_32);

                        var DUFieldRES_31 = pivotTableResource_3.Fields["DU"];
                        pivotTableResource_3.RowFields.Add(DUFieldRES_31);

                        #endregion

                        #endregion

                        excel.SaveAs(finame);

                    }
                }


            }

            catch (Exception ex)
            {
                MessageBox.Show("A handled exception just occurred: " + ex.Message, "Exception : ", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

        }

        public String GetTimestamp(DateTime value)
        {
            return value.ToString("yyyyMMddHHmmss");
        }


        
    }
}
