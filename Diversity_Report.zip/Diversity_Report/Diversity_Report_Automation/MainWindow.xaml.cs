﻿using OfficeOpenXml;
using OfficeOpenXml.Style;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using WPFNotification.Model;
using WPFNotification.Services;

namespace Diversity_Report_Automation
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public string excelpath ;

        EventLog eventLog = new EventLog();

        //List<DataTableCollection> dtList = new List<DataTableCollection>();

        public MainWindow()
        {
            InitializeComponent();
            excelpath = "";
        }


        private void BrowseButton_Click(object sender, RoutedEventArgs e)
        {
            // Create OpenFileDialog
            Microsoft.Win32.OpenFileDialog openFileDlg = new Microsoft.Win32.OpenFileDialog();
            openFileDlg.Multiselect = true;
            openFileDlg.Filter = "All files (*.*)|*.*";
            // Launch OpenFileDialog by calling ShowDialog method
            Nullable<bool> result = openFileDlg.ShowDialog();
            // Get the selected file name and display in a TextBox.
            // Load content of file in a TextBlock
            if (result == true)
            {
                if (openFileDlg.FileNames.Count() > 0)
                {
                    string fname = "";
                    foreach (var item in openFileDlg.FileNames)
                    {
                        fname = item + ";" + fname ;
                    }

                    FileNameTextBox.Text = fname.TrimEnd(';');
                    TextBlock1.Visibility = Visibility.Visible;
                }
                else
                    FileNameTextBox.Text = openFileDlg.FileName;
                    TextBlock1.Visibility = Visibility.Visible;


            }
        }


        private void button_Click(object sender, RoutedEventArgs e)
        {
            
            string[] filename = FileNameTextBox.Text.Split(';');           
            getData(filename);
            //Thread thread = new Thread(() => getData(filename));
            //thread.SetApartmentState(ApartmentState.STA);
            //thread.IsBackground = true;
            //thread.Start();

        }

        public void getData(string[] filename)
        {
            try
            {

                INotificationDialogService _dailogService = new NotificationDialogService();
                string con = "";
                DataSet ds = new DataSet();
                DataTableCollection dt = ds.Tables ;
         
                    for (int i = 0; i < filename.Length; i++)
                    {
                        con =
          @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filename[i] + " ;" +
          @"Extended Properties='Excel 12.0;HDR=NO;IMEX=1'";

                        if (filename[i].Contains("ROV_Report"))
                        {
                            using (OleDbConnection connection = new OleDbConnection(con))
                            {
                                connection.Open();

                                OleDbCommand commandAD = new OleDbCommand("select * from [ROV Base$]", connection);
                                commandAD.CommandType = CommandType.Text;
                                //OleDbCommand commandAD = new OleDbCommand("select * from [Abacus Demand Dump -6th Aug'19$]", connection);
                                OleDbDataAdapter myDataAdaptorAD = new OleDbDataAdapter(commandAD);
                                //OleDbDataAdapter myDataAdaptorAD = new OleDbDataAdapter(commandAD);

                                myDataAdaptorAD.Fill(ds, "ROV Base");
                                //myDataAdaptorAD.Fill(ds, "Abacus Demand Dump -6th Aug'19");
                                dt = ds.Tables;


                            }
                        }
                        if (filename[i].Contains("Resource dump"))
                        {
                            using (OleDbConnection connection = new OleDbConnection(con))
                            {
                                connection.Open();
                                OleDbCommand commandBD = new OleDbCommand("select * from [Sheet1$]", connection);
                                //OleDbCommand commandAD = new OleDbCommand("select * from [Abacus Demand Dump -6th Aug'19$]", connection);
                                OleDbDataAdapter myDataAdaptorBD = new OleDbDataAdapter(commandBD);
                                //OleDbDataAdapter myDataAdaptorAD = new OleDbDataAdapter(commandAD);

                                myDataAdaptorBD.Fill(ds, "Resource dump");
                                //myDataAdaptorAD.Fill(ds, "Abacus Demand Dump -6th Aug'19");
                                dt = ds.Tables;



                            }
                        }
                        if (filename[i].Contains("Travelers diversity"))
                        {
                            using (OleDbConnection connection = new OleDbConnection(con))
                            {
                                connection.Open();
                                OleDbCommand commandCD = new OleDbCommand("select * from [Sheet1$]", connection);
                                //OleDbCommand commandAD = new OleDbCommand("select * from [Abacus Demand Dump -6th Aug'19$]", connection);
                                OleDbDataAdapter myDataAdaptorCD = new OleDbDataAdapter(commandCD);
                                //OleDbDataAdapter myDataAdaptorAD = new OleDbDataAdapter(commandAD);

                                myDataAdaptorCD.Fill(ds, "Travelers diversity");
                                //myDataAdaptorAD.Fill(ds, "Abacus Demand Dump -6th Aug'19");
                                dt = ds.Tables;


                            }
                        }
                    if (filename[i].Contains("Demand dump"))
                    {
                        using (OleDbConnection connection = new OleDbConnection(con))
                        {
                            connection.Open();
                            OleDbCommand commandDD = new OleDbCommand("select * from [Sheet 1$]", connection);
                            //OleDbCommand commandAD = new OleDbCommand("select * from [Abacus Demand Dump -6th Aug'19$]", connection);
                            OleDbDataAdapter myDataAdaptorDD = new OleDbDataAdapter(commandDD);
                            //OleDbDataAdapter myDataAdaptorAD = new OleDbDataAdapter(commandAD);

                            myDataAdaptorDD.Fill(ds, "Demand dump");
                            //myDataAdaptorAD.Fill(ds, "Abacus Demand Dump -6th Aug'19");
                            dt = ds.Tables;


                        }
                    }


                }
       
                generateExcel(dt);
                TextBlock1.Text = "Completed";
                var newNotification = new Notification()
                {
                    Title = "Excel Created",
                    Message = "Excel file created , you can find the file : " + excelpath
                };
                _dailogService.ShowNotificationWindow(newNotification);

            }
            catch (Exception ex)
            {
                eventLog.WriteEntry(ex.InnerException.Message, EventLogEntryType.Error, 1002);
                eventLog.WriteEntry(ex.Message, EventLogEntryType.Error, 1003);
            }
        }

        public void generateExcel(DataTableCollection Dtvalue)
        {
     
            try
            {

                String timeStamp = GetTimestamp(DateTime.Now);

                if (!Directory.Exists(@"C:\RE__Diversity_report"))
                    Directory.CreateDirectory(@"C:\RE__Diversity_report");

                excelpath = @"C:\RE__Diversity_report\Diversity Calculation_" + timeStamp + ".xlsx";

                DateTime date = DateTime.Now;
                string dateFormat = string.Format("{0:dd MMM yy}", date);

                FileInfo finame = new FileInfo(excelpath);

                if (!System.IO.File.Exists(excelpath))
                {

                    using (ExcelPackage excel = new ExcelPackage())
                    {

                        ExcelWorksheet ws =  excel.Workbook.Worksheets.Add("Res Dump-" + dateFormat );
                        ExcelWorksheet ws2 = excel.Workbook.Worksheets.Add("ROV-" + dateFormat );
                        ExcelWorksheet ws3 = excel.Workbook.Worksheets.Add("Base");
                        ExcelWorksheet ws4 = excel.Workbook.Worksheets.Add("Abacus Demand Dump -" + dateFormat);

                        int count  = 0;
                        int count1 = 0;
                        int count2 = 0;
                        int count3 = 0;


                        #region Abacus Demand Dump

                        if (Dtvalue[3].TableName == "Demand dump")
                        {
                            foreach (DataRow dr in Dtvalue[3].Rows.Cast<DataRow>().Skip(3))
                            {
                                count3 = count3 + 1;
                                int n = 0;

                                for (int j = 8; j <= 130; j++)
                                {

                                    n = n + 1;
                                    int result3;
                                    var isNumeric = int.TryParse(dr.ItemArray[j].ToString(), out result3);
                                    if (isNumeric == true)
                                    {
                                        ws4.Cells[count3, n].Value = Convert.ToInt32(dr.ItemArray[j]);
                                        ws4.Cells[count3, n].Style.Numberformat.Format = "0";
                                    }
                                    else
                                    {
                                        ws4.Cells[count3, n].Value = dr.ItemArray[j].ToString();
                                    }

                                    if (count3 == 1)
                                    {

                                        ws4.Cells[count3, n].Style.Font.Bold = true;
                                        ws4.Cells[count3, n].Style.Font.Size = 10;
                                        ws4.Cells[count3, n].Style.Font.Name = "Verdana";

                                    }


                                    if (dr.ItemArray[j] == null)
                                    {
                                        break;
                                    }


                                }

                            }
                        }

                        #endregion

                        #region Resource Dump
                            if (Dtvalue[2].TableName == "Resource dump")
                            {
                                foreach (DataRow dr in Dtvalue[2].Rows.Cast<DataRow>().Skip(3))
                                {
                                    count1 = count1 + 1;
                                    int n = 0;

                                    for (int j = 0; j <= 141; j++)
                                    {
                                    n = n + 1;
                                    if (j <= 138)
                                    {
                                        int result;
                                        var isNumeric = int.TryParse(dr.ItemArray[j].ToString(), out result);
                                        if (isNumeric == true)
                                        {
                                            ws.Cells[count1, n].Value = Convert.ToInt32(dr.ItemArray[j]);
                                            ws.Cells[count1, n].Style.Numberformat.Format = "0";
                                        }
                                        else
                                        {
                                            ws.Cells[count1, n].Value = dr.ItemArray[j].ToString();
                                        }

                                        if (count1 == 1)
                                        {

                                            ws.Cells[count1, n].Style.Font.Bold = true;
                                            ws.Cells[count1, n].Style.Font.Size = 10;
                                            ws.Cells[count1, n].Style.Font.Name = "Verdana";

                                        }

                                    }

                                    if (j == 139)
                                    {
                                        if (count1 == 1)
                                        {
                                            ws.Cells[count1, n].Value = "Base Data";
                                            ws.Cells[count1, n].Style.Font.Bold = true;
                                            ws.Cells[count1, n].Style.Font.Size = 10;
                                            ws.Cells[count1, n].Style.Font.Name = "Verdana";
                                            ws.Cells[count1, n].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                            ws.Cells[count1, n].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);

                                        }
                                        else
                                        {
                                            //ws3.Cells[count2, n].Formula = "VLOOKUP(C" + count2 + ",'Res Dump-6th Aug''19'!$Q:Q,1,0)";
                                            ws.Cells[count1, n].Formula = "VLOOKUP(Q" + count1 + ",'Base'!$C:C,1,0)";
                                        }

                                    }

                                    if (j == 140)
                                    {
                                        if (count1 == 1)
                                        {
                                            ws.Cells[count1, n].Value = "Personnel No.";
                                            ws.Cells[count1, n].Style.Font.Bold = true;
                                            ws.Cells[count1, n].Style.Font.Size = 10;
                                            ws.Cells[count1, n].Style.Font.Name = "Verdana";
                                            ws.Cells[count1, n].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                            ws.Cells[count1, n].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);

                                        }
                                        else
                                        {
                                            //ws3.Cells[count2, n].Formula = "VLOOKUP(C" + count2 + ",'Res Dump-6th Aug''19'!$Q:Q,1,0)";
                                            ws.Cells[count1, n].Formula = "VLOOKUP(Q" + count1 + ",'" + ws.Name + "'!$Q:Q,1,0)";
                                        }

                                    }

                                    if (j == 141)
                                    {
                                        if (count1 == 1)
                                        {
                                            ws.Cells[count1, n].Value = "Status";
                                            ws.Cells[count1, n].Style.Font.Bold = true;
                                            ws.Cells[count1, n].Style.Font.Size = 10;
                                            ws.Cells[count1, n].Style.Font.Name = "Verdana";
                                            ws.Cells[count1, n].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                            ws.Cells[count1, n].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);

                                        }
                                        else
                                        {
                                            //ws3.Cells[count2, n].Formula = "VLOOKUP(C" + count2 + ",'Res Dump-6th Aug''19'!$Q:Q,1,0)";
                                            ws.Cells[count1, n].Formula = "VLOOKUP(R" + count1 + ",'" + ws.Name + "'!$R:R,1,0)";
                                        }

                                    }



                                }
                                }
                            }
                        #endregion

                        #region Rov Base  
                        if (Dtvalue[1].TableName == "ROV Base")
                        {
                            foreach (DataRow dr in Dtvalue[1].Rows.Cast<DataRow>().Where(
  row => row.ItemArray.Any(field => !(field is System.DBNull))))
                            {
                             
                                count = count + 1;
                                int n = 0;

                                for (int j = 0; j <= 23; j++)
                                {
                                   
                                    n = n + 1;
                                    int result1;
                                    var isNumeric = int.TryParse(dr.ItemArray[j].ToString(), out result1);
                                    if (isNumeric == true)
                                    {
                                        ws2.Cells[count, n].Value = Convert.ToInt32(dr.ItemArray[j]);
                                        ws2.Cells[count, n].Style.Numberformat.Format = "0";
                                    }
                                    else
                                    {
                                        ws2.Cells[count, n].Value = dr.ItemArray[j].ToString();
                                    }
                                    if (count == 1)
                                    {

                                        ws2.Cells[count, n].Style.Font.Bold = true;
                                        ws2.Cells[count, n].Style.Font.Size = 10;
                                        ws2.Cells[count, n].Style.Font.Name = "Verdana";

                                    }


                                    if (dr.ItemArray[j] == null)
                                    {
                                        break;
                                    }


                                }
                            }
                        }
                        #endregion

                        #region  Travelers diversity
                    
                        if (Dtvalue[0].TableName == "Travelers diversity")
                        {
                            foreach (DataRow dr in Dtvalue[0].Rows)
                            {
                                count2 = count2 + 1;
                                int n = 0;

                                for (int j = 0; j <= 49; j++)
                                {

                                    n = n + 1;

                                    if (j <= 44)
                                    {
                                        int result2;
                                        var isNumeric = int.TryParse(dr.ItemArray[j].ToString(), out result2);
                                        if (isNumeric == true)
                                        {
                                            ws3.Cells[count2, n].Value = Convert.ToInt32(dr.ItemArray[j]);
                                            ws3.Cells[count2, n].Style.Numberformat.Format = "0";
                                        }
                                        else
                                        {
                                            ws3.Cells[count2, n].Value = dr.ItemArray[j].ToString();
                                        }
                                        if (count2 == 1)
                                        {

                                            ws3.Cells[count2, n].Style.Font.Bold = true;
                                            ws3.Cells[count2, n].Style.Font.Size = 10;
                                            ws3.Cells[count2, n].Style.Font.Name = "Verdana";

                                        }
                                    }
                                    if (j == 45)
                                    {

                                        if (count2 == 1)
                                        {
                                            ws3.Cells[count2, n].Value = "Resource Dump_Abacus";
                                            ws3.Cells[count2, n].Style.Font.Bold = true;
                                            ws3.Cells[count2, n].Style.Font.Size = 10;
                                            ws3.Cells[count2, n].Style.Font.Name = "Verdana";
                                            ws3.Cells[count2, n].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                            ws3.Cells[count2, n].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);

                                        }
                                        else {
                                            //ws3.Cells[count2, n].Formula = "VLOOKUP(C" + count2 + ",'Res Dump-6th Aug''19'!$Q:Q,1,0)";
                                            ws3.Cells[count2, n].Formula = "VLOOKUP(C" + count2 + ",'" + ws.Name + "'!$Q:Q,1,0)";
                                        }
                                    }
                                    if (j == 46)
                                    {

                                        if (count2 == 1)
                                        {
                                            ws3.Cells[count2, n].Value = ws2.Name;
                                            ws3.Cells[count2, n].Style.Font.Bold = true;
                                            ws3.Cells[count2, n].Style.Font.Size = 10;
                                            ws3.Cells[count2, n].Style.Font.Name = "Verdana";
                                            ws3.Cells[count2, n].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                            ws3.Cells[count2, n].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);

                                        }
                                        else
                                        {
                                            //ws3.Cells[count2, n].Formula = "VLOOKUP(C" + count2 + ",'ROV-6th Aug''19'!B:Q,16,0)";

                                            ws3.Cells[count2, n].Formula = "VLOOKUP(C" + count2 + ",'" + ws2.Name + "'!B:Q,16,0)";
                                        }
                                    }
                                    if (j == 47)
                                    {

                                        if (count2 == 1)
                                        {
                                            ws3.Cells[count2, n].Value = "ROV Date";
                                            ws3.Cells[count2, n].Style.Font.Bold = true;
                                            ws3.Cells[count2, n].Style.Font.Size = 10;
                                            ws3.Cells[count2, n].Style.Font.Name = "Verdana";
                                            ws3.Cells[count2, n].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                            ws3.Cells[count2, n].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);
                                        }
                                        else
                                        {
                                            //ws3.Cells[count2, n].Formula = "VLOOKUP(C" + count2 + ",'ROV-6th Aug''19'!B:M,12,0)";
                                            ws3.Cells[count2, n].Formula = "VLOOKUP(C" + count2 + ",'" + ws2.Name + "'!B:M,12,0)";

                                        }
                                    }
                                    if (j == 48)
                                    {

                                        if (count2 == 1)
                                        {
                                            ws3.Cells[count2, n].Value = "ROV Month";
                                            ws3.Cells[count2, n].Style.Font.Bold = true;
                                            ws3.Cells[count2, n].Style.Font.Size = 10;
                                            ws3.Cells[count2, n].Style.Font.Name = "Verdana";
                                            ws3.Cells[count2, n].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                            ws3.Cells[count2, n].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);
                                        }
                                        else
                                        {
                                            ws3.Cells[count2, n].Formula = "TEXT(AV" + count2 + ", \"mmm-yy\")";

                                        }
                                    }
                                    if (j == 49)
                                    {
                                        if (count2 == 1)
                                        {
                                            ws3.Cells[count2, n].Value = "Personnel No";
                                            ws3.Cells[count2, n].Style.Font.Bold = true;
                                            ws3.Cells[count2, n].Style.Font.Size = 10;
                                            ws3.Cells[count2, n].Style.Font.Name = "Verdana";
                                            ws3.Cells[count2, n].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                            ws3.Cells[count2, n].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);
                                        }
                                        else
                                        {
                                            ws3.Cells[count2, n].Formula = "VLOOKUP(C" + count2 + ",'" + ws3.Name + "'!$C:C,1,0)";

                                        }
                                    }



                                }

                            }
                        }
                        #endregion


                        excel.SaveAs(finame);

                    }
                }


            }

            catch (Exception ex)
            {
                eventLog.WriteEntry(ex.InnerException.Message, EventLogEntryType.Error, 1004);
                eventLog.WriteEntry(ex.Message, EventLogEntryType.Error, 1005);
            }

        }

        //public void generateExcel(DataTableCollection Dtvalue)
        //{
        //    try {

        //        String timeStamp = GetTimestamp(DateTime.Now);

        //        if (!Directory.Exists(@"C:\RE__Diversity_report"))
        //            Directory.CreateDirectory(@"C:\RE__Diversity_report");

        //        excelpath = @"C:\RE__Diversity_report\test_" + timeStamp + ".xlsx";


        //        FileInfo finame = new FileInfo(excelpath);

        //        if (!System.IO.File.Exists(excelpath))
        //        {

        //            using (ExcelPackage excel = new ExcelPackage())
        //            {

        //                ExcelWorksheet ws = excel.Workbook.Worksheets.Add("Demand -Diversity");
        //                ExcelWorksheet ws2 = excel.Workbook.Worksheets.Add("Abacus Demand Dump -6th Aug'19");

        //                int count = 0;
        //                int count1 = 0;

        //                foreach (DataRow dr in Dtvalue[1].Rows)
        //                {
        //                    count1 = count1 + 1;
        //                    int n = 0;
        //                    for (int i = 0; i <= 120; i++)
        //                    {

        //                        n = n + 1;
        //                        ws2.Cells[count1, n].Value = dr.ItemArray[i].ToString();
        //                        if (count1 == 1)
        //                        {

        //                            ws2.Cells[count1, n].Style.Font.Bold = true;
        //                            ws2.Cells[count1, n].Style.Font.Size = 10;
        //                            ws2.Cells[count1, n].Style.Font.Name = "Verdana";

        //                        }


        //                        if (dr.ItemArray[i] == null)
        //                        {
        //                            break;
        //                        }


        //                    }
        //                }


        //                foreach (DataRow dr in Dtvalue[0].Rows)
        //                {
        //                    count = count + 1;
        //                    int n = 0;
        //                    for (int i = 15; i <= 25; i++)
        //                    {
        //                        n = n + 1;

        //                        if (count != 1)
        //                        {
        //                            if (n < 11)
        //                                ws.Cells[count, n].Value = dr.ItemArray[i].ToString();
        //                            if (n == 11)
        //                                ws.Cells[count, n].Formula = "VLOOKUP(A" + count + ",'Abacus Demand Dump -6th Aug''19'!A:D,4,0)";


        //                        }
        //                        else
        //                        {

        //                            ws.Cells[count, n].Value = dr.ItemArray[i].ToString();
        //                            ws.Cells[count, n].Style.Font.Bold = true;
        //                            ws.Cells[count, n].Style.Font.Size = 10;
        //                            ws.Cells[count, n].Style.Font.Name = "Verdana";

        //                        }



        //                    }

        //                }


        //                excel.SaveAs(finame);
        //            }
        //        }
        //        Console.WriteLine("Excel file created , you can find the file : " + excelpath);
        //        Console.ReadLine();


        //    }

        //    catch (Exception ex)
        //    {
        //        eventLog.WriteEntry(ex.InnerException.Message, EventLogEntryType.Error, 1004);
        //        eventLog.WriteEntry(ex.Message, EventLogEntryType.Error, 1005);
        //    }

        //}

        public String GetTimestamp(DateTime value)
        {
            return value.ToString("yyyyMMddHHmmss");
        }
    }
}
