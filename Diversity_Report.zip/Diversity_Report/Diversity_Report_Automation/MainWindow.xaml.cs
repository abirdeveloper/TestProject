﻿using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WPFNotification.Model;
using WPFNotification.Services;

namespace Diversity_Report_Automation
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public string excelpath ;
        public MainWindow()
        {
            InitializeComponent();
            excelpath = "";
        }

        private void BrowseButton_Click(object sender, RoutedEventArgs e)
        {
            // Create OpenFileDialog
            Microsoft.Win32.OpenFileDialog openFileDlg = new Microsoft.Win32.OpenFileDialog();

            // Launch OpenFileDialog by calling ShowDialog method
            Nullable<bool> result = openFileDlg.ShowDialog();
            // Get the selected file name and display in a TextBox.
            // Load content of file in a TextBlock
            if (result == true)
            {
                FileNameTextBox.Text = openFileDlg.FileName;             
            }
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
                    string con =
           @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + FileNameTextBox.Text + " ;" +
           @"Extended Properties='Excel 12.0;HDR=No;IMEX=1'";

            using (OleDbConnection connection = new OleDbConnection(con))
                        {
                            connection.Open();
                            OleDbCommand command = new OleDbCommand("select * from [Demand-Diversity$]", connection);
                            OleDbDataAdapter myDataAdaptor = new OleDbDataAdapter(command);
                            DataSet ds = new DataSet();
                            myDataAdaptor.Fill(ds, "Demand-Diversity");
                            DataTable dt = ds.Tables[0];
                            generateExcel(dt);
                        }

            INotificationDialogService _dailogService = new NotificationDialogService();
            var newNotification = new Notification()
            {
                Title = "Excel Created",
                Message = "Excel file created , you can find the file : " + excelpath
            };
            _dailogService.ShowNotificationWindow(newNotification);

        }

        public void generateExcel(DataTable Dtvalue)
        {
            String timeStamp = GetTimestamp(DateTime.Now);
        
            if (!Directory.Exists(@"D:\RE__Diversity_report"))
                Directory.CreateDirectory(@"D:\RE__Diversity_report");

            excelpath = @"D:\RE__Diversity_report\test_" + timeStamp + ".xlsx";


            FileInfo finame = new FileInfo(excelpath);

            if (!System.IO.File.Exists(excelpath))
            {

                using (ExcelPackage excel = new ExcelPackage())
                {

                    ExcelWorksheet ws = excel.Workbook.Worksheets.Add("Demand -Diversity");
                    int count = 0;
                    foreach (DataRow dr in Dtvalue.Rows)
                    {
                        count = count + 1;
                        int n = 0;
                        for (int i = 15; i <= 25; i++)
                        {
                            n = n + 1;
                            ws.Cells[count, n].Value = dr.ItemArray[i].ToString();
                            if (count == 1)
                            {

                                ws.Cells[count, n].Style.Font.Bold = true;
                                ws.Cells[count, n].Style.Font.Size = 10;
                                ws.Cells[count, n].Style.Font.Name = "Verdana";

                            }


                        }

                    }

                    excel.SaveAs(finame);
                }
            }
            Console.WriteLine("Excel file created , you can find the file : " + excelpath);
            Console.ReadLine();

        }

        public String GetTimestamp(DateTime value)
        {
            return value.ToString("yyyyMMddHHmmss");
        }
    }
}
