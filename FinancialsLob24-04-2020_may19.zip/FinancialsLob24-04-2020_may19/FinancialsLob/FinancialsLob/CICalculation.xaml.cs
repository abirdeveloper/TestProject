﻿using Aspose.Cells;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;


namespace FinancialsLob
{
    /// <summary>
    /// Interaction logic for CICalculation.xaml
    /// </summary>
    public partial class CICalculation : Window
    {
        List<FiltersCI> Filter = new List<FiltersCI>();
        DataTable tr = new DataTable();
        Popup pop = new Popup();
        PopupExcell popexcell = new PopupExcell();
        private BackgroundWorker bw = new BackgroundWorker();
        List<DetailsCCI> gridcci = new List<DetailsCCI>();
        List<DetailsCCI> gridccinew = new List<DetailsCCI>();
        feildsCFM fc = new feildsCFM();
        public string gsobillrate = string.Empty;
        public string newgsobillrate = string.Empty;
        public CICalculation()
        {
            InitializeComponent();

            duname.ItemsSource = fc.duName;
            duname.SelectedValue = "1";

            typeofplan.ItemsSource = fc.Category;
            typeofplan.SelectedValue = "1";

            //planresource.ItemsSource = fc.Category;
            //planresource.SelectedValue = "1";

            mmeupdate.ItemsSource = fc.MMEUpdate;
            mmeupdate.SelectedValue = "1";

            location.ItemsSource = fc.Location;
            location.SelectedValue = "1";

            gsorole.ItemsSource = fc.GsoRole;
            gsorole.SelectedValue = "1";

            newgsorole.ItemsSource = fc.GsoRole;
            newgsorole.SelectedValue = "1";

            dp1.DisplayDate = DateTime.Now;
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            //pop.Show();
            getData(@"C:\Financial_LOB");
            //pop.Close();
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            //pop.Show();
            getNewCCIData(@"C:\Financial_LOB");
            //pop.Close();
        }

        public void getData(string path)
        {
            DirectoryInfo di = new DirectoryInfo(path);
            FileInfo[] FileReport1 = di.GetFiles("*.xlsb");          

            getdataCI(FileReport1);
            //LoadGrid(dt, FileReport);


        }
        public static DateTime FromExcelSerialDate(int SerialDate)
        {
            if (SerialDate > 59) SerialDate -= 1; //Excel/Lotus 2/29/1900 bug   
            return new DateTime(1899, 12, 31).AddDays(SerialDate);
        }

        public void getNewCCIData(string path)
        {

            DirectoryInfo di = new DirectoryInfo(path);
            FileInfo[] FileReport = di.GetFiles("*.xlsb");

            string con2 =
@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + FileReport[0].FullName + " ;" +
@"Extended Properties='Excel 12.0;HDR=YES;IMEX=1'";


            FileInfo file = new FileInfo(FileReport[0].FullName);

            AddFsig(con2, Filter, file);

        }

        public void getdataCI(FileInfo[] filreprt1)
        {
            Filter.Clear();
            Filter.Add(new FiltersCI
            {
                category = planresource.SelectedValue.ToString(),
                typeOfPlan = typeofplan.SelectedValue.ToString(),
                woname = woname.SelectedValue.ToString(),
                name = resourcename.Text,
                effectivedate = Convert.ToDateTime(dp1.SelectedDate),
                location = location.SelectedValue.ToString(),
                gsorole = gsorole.SelectedValue.ToString(),
                mmeupdate = mmeupdate.SelectedValue.ToString(),
                empnumber = empnumber.Text,
                newgsorole = newgsorole.SelectedValue == null ? "" : newgsorole.SelectedValue.ToString()
            });

            string con2 =
           @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filreprt1[0].FullName + " ;" +
           @"Extended Properties='Excel 12.0;HDR=Yes;IMEX=1'";


            DataSet ds = new DataSet();
            DataSet ds1 = new DataSet();

            DataTableCollection dtn = ds.Tables;

            using (OleDbConnection connection = new OleDbConnection(con2))
            {
                connection.Open();

                OleDbCommand commandAD = connection.CreateCommand();
                commandAD.CommandType = CommandType.Text;
                string tableName1 = String.Format("[{0}$JD:ME]", "LOBwise Qtr Summary_ DU split");
                string tableName = String.Format("[{0}$D:E]", "LOBwise Qtr Summary_ DU split");
                commandAD.CommandText = String.Format("SELECT * FROM {0}", tableName);
                //commandAD.CommandText = String.Format("SELECT F3, F5, F6, F7, F9 , {2} FROM {0} where F6 = '{1}'", tableName, filt, ccicount);

                commandAD.CommandType = CommandType.Text;
                OleDbDataAdapter myDataAdaptorAD = new OleDbDataAdapter(commandAD);
                myDataAdaptorAD.Fill(ds, "DUsplit");
                //dtn = ds.Tables;

                OleDbCommand commandADM = connection.CreateCommand();
                commandADM.CommandType = CommandType.Text;
                commandADM.CommandText = String.Format("SELECT * FROM {0}", tableName1);
                commandADM.CommandType = CommandType.Text;
                OleDbDataAdapter myDataAdaptorADM = new OleDbDataAdapter(commandADM);
                myDataAdaptorADM.Fill(ds1, "DUsplit2");


                DataTable dtMerged = MergeTables(ds1.Tables[0], ds.Tables[0]);

                var result = dtMerged
                    .AsEnumerable()
                    .Where(myRow => myRow.Field<string>(81) == Filter[0].woname);

                gridcci.Clear();

                foreach (var item in result)
                {

                    gridcci.Add(new DetailsCCI
                    {
                        FY1 = item.ItemArray[15].ToString(),
                        FY2 = item.ItemArray[31].ToString(),
                        FY3 = item.ItemArray[47].ToString(),
                        FY4 = item.ItemArray[63].ToString(),
                        FYall = item.ItemArray[79].ToString(),
                        FYRevenue = item.ItemArray[69].ToString(),

                    }

                         );
                    


                }

                dgUsers.ItemsSource = gridcci;

            }



        }

        public static DataTable MergeTables(DataTable baseTable, params DataTable[] additionalTables)
        {
            // Build combined table columns
            DataTable merged = baseTable;
            foreach (DataTable dt in additionalTables)
            {
                merged = AddTable(merged, dt);
            }
            return merged;
        }
        /// <summary>
        /// Merge two tables into a single table with more columns.
        /// </summary>
        /// <param name="baseTable"></param>
        /// <param name="additionalTable"></param>
        /// <returns></returns>
        public static DataTable AddTable(DataTable baseTable, DataTable additionalTable)
        {
            // Build combined table columns
            
            DataTable merged = baseTable.Clone();                  // Include all columns from t1 in result.
            foreach (DataColumn col in additionalTable.Columns)
            {
                int columns = baseTable.Columns.Count;
                string newColumnName = col.ColumnName;
                string[] words = newColumnName.Split('F');
                int wd = Convert.ToInt32(words[1]) + columns;

                newColumnName = "F" + wd;
                merged.Columns.Add(newColumnName, col.DataType);
                
            }
            // Add all rows from both tables
            var bt = baseTable.AsEnumerable();
            var at = additionalTable.AsEnumerable();
            var mergedRows = bt.Zip(at, (r1, r2) => r1.ItemArray.Concat(r2.ItemArray).ToArray());
            foreach (object[] rowFields in mergedRows)
            {
                merged.Rows.Add(rowFields);
            }
            return merged;
        }

        public  void getccinewUpdate(FileInfo fullpath)
       {

            string con2 =
           @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + fullpath.FullName + " ;" +
           @"Extended Properties='Excel 12.0;HDR=Yes;IMEX=1'";


            DataSet ds = new DataSet();
            DataSet ds1 = new DataSet();

            DataTableCollection dtn = ds.Tables;

            using (OleDbConnection connection = new OleDbConnection(con2))
            {
                connection.Open();

                OleDbCommand commandAD = connection.CreateCommand();
                commandAD.CommandType = CommandType.Text;
                string tableName1 = String.Format("[{0}$JD:ME]", "LOBwise Qtr Summary_ DU split");
                string tableName = String.Format("[{0}$D:E]", "LOBwise Qtr Summary_ DU split");
                commandAD.CommandText = String.Format("SELECT * FROM {0}", tableName);
                //commandAD.CommandText = String.Format("SELECT F3, F5, F6, F7, F9 , {2} FROM {0} where F6 = '{1}'", tableName, filt, ccicount);

                commandAD.CommandType = CommandType.Text;
                OleDbDataAdapter myDataAdaptorAD = new OleDbDataAdapter(commandAD);
                myDataAdaptorAD.Fill(ds, "DUsplit");
                //dtn = ds.Tables;

                OleDbCommand commandADM = connection.CreateCommand();
                commandADM.CommandType = CommandType.Text;
                commandADM.CommandText = String.Format("SELECT * FROM {0}", tableName1);
                commandADM.CommandType = CommandType.Text;
                OleDbDataAdapter myDataAdaptorADM = new OleDbDataAdapter(commandADM);
                myDataAdaptorADM.Fill(ds1, "DUsplit2");


                DataTable dtMerged = MergeTables(ds1.Tables[0], ds.Tables[0]);

                var result = dtMerged
                    .AsEnumerable()
                    .Where(myRow => myRow.Field<string>(81) == Filter[0].woname);

                gridccinew.Clear();
                foreach (var item in result)
                {

                    gridccinew.Add(new DetailsCCI
                    {
                        FY1 = item.ItemArray[15].ToString(),
                        FY2 = item.ItemArray[31].ToString(),
                        FY3 = item.ItemArray[47].ToString(),
                        FY4 = item.ItemArray[63].ToString(),
                        FYall = item.ItemArray[79].ToString(),
                        FYRevenue = item.ItemArray[69].ToString()
                    }

                  );



                }

                dgUsersNew.ItemsSource = gridccinew;

                //string[] fy1 = gridcci[0].FY1.Split('%');
                //string[] fy2 = gridcci[0].FY2.Split('%');
                //string[] fy3 = gridcci[0].FY3.Split('%');
                //string[] fy4 = gridcci[0].FY4.Split('%');
                 string[] fyall = gridcci[0].FYall.Split('%');

                //string[] fy11 = gridccinew[0].FY1.Split('%');
                //string[] fy21 = gridccinew[0].FY2.Split('%');
                //string[] fy31 = gridccinew[0].FY3.Split('%');
                //string[] fy41 = gridccinew[0].FY4.Split('%');
                string[] fyall1 = gridccinew[0].FYall.Split('%');


                //fy1var.Text = Convert.ToString(Math.Round(Convert.ToDouble(fy11[0])- Convert.ToDouble(fy1[0]),2)) + "%";
                //fy2var.Text = Convert.ToString(Math.Round(Convert.ToDouble(fy21[0])- Convert.ToDouble(fy2[0]), 2)) + "%";
                //fy3var.Text = Convert.ToString(Math.Round(Convert.ToDouble(fy31[0]) - Convert.ToDouble(fy3[0]), 2)) + "%";
                //fy4var.Text = Convert.ToString(Math.Round(Convert.ToDouble(fy41[0]) - Convert.ToDouble(fy4[0]), 2)) + "%";
                 fy5var.Text = Convert.ToString(Math.Round(Convert.ToDouble(fyall1[0]) - Convert.ToDouble(fyall[0]), 2)) + "%";

            }



        }
        private void AddFsig(string con2 , List<FiltersCI> Filter , FileInfo fullpath)
        {
            DataSet ds = new DataSet();
            DataTableCollection dtn = ds.Tables;
            string tbname = Filter[0].woname.Remove(Filter[0].woname.IndexOf(')')).Substring(Filter[0].woname.IndexOf('(') + 1);
            using (OleDbConnection connection = new OleDbConnection(con2))
            {
                connection.Open();

                OleDbCommand commandAD = connection.CreateCommand();
                commandAD.CommandType = CommandType.Text;
                string tableName = String.Format("[{0}$]", tbname);

                commandAD.CommandText = String.Format("SELECT F1 FROM {0}", tableName);
                commandAD.CommandType = CommandType.Text;
                OleDbDataAdapter myDataAdaptorAD = new OleDbDataAdapter(commandAD);
                myDataAdaptorAD.Fill(ds, tbname);
                dtn = ds.Tables;

            }

            DirectoryInfo di = new DirectoryInfo(@"C:\Financial_LOB");
            FileInfo[] FileReport = di.GetFiles("*.xlsx");

            DataSet dss = new DataSet();
            DataTableCollection dtnn = ds.Tables;

            string conLCR =
          @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + FileReport[0].FullName + " ;" +
          @"Extended Properties='Excel 12.0;HDR=Yes;IMEX=1'";

            Workbook wbb = new Workbook(FileReport[0].FullName);
            Worksheet wss = wbb.Worksheets[2];


            using (OleDbConnection connection = new OleDbConnection(conLCR))
            {
                connection.Open();

                OleDbCommand commandAD = connection.CreateCommand();
                commandAD.CommandType = CommandType.Text;
                string tableName = String.Format("[{0}$]", wss.Name);

                commandAD.CommandText = String.Format("SELECT * FROM {0}", tableName);
                commandAD.CommandType = CommandType.Text;
                OleDbDataAdapter myDataAdaptorADD = new OleDbDataAdapter(commandAD);
                myDataAdaptorADD.Fill(dss, tableName);
                dtnn = dss.Tables;

            }

            var result = dtnn[0]
                    .AsEnumerable()
                    .Where(myRow => myRow.Field<string>(8) == Filter[0].name.ToString());

            string lcr = string.Empty;

            foreach (var item in result)
            {
                lcr = item.ItemArray[22].ToString();
                string[] ab = lcr.Split('$');
                lcr = ab[1];
                break;
            }

                int count2 = 0;

            foreach (DataRow dr in dtn[0].Rows.Cast<DataRow>().Skip(3))
            {
                bool found = false;
                count2 = count2 + 1;
                int n = 0;

                LoadOptions opt = new LoadOptions();
                //Set the memory preferences
                opt.MemorySetting = MemorySetting.MemoryPreference;

                for (int j = 0; j < dr.ItemArray.Count(); j++)
                {
                    n = n + 1;
                    if (dr.ItemArray[0].ToString() == "")
                    {
                        Workbook wb = new Workbook(fullpath.FullName, opt);
                        Worksheet ws = wb.Worksheets[tbname];

                        int newrow = count2 + 4;

                        // (wb.Worksheets[tbname].Cells[newrow, 1]).Value= Filter[0].woname.ToString();
                        //( wb.Worksheets[tbname].Cells[newrow, 5]).Value = Filter[0].category.ToString();
                        // (wb.Worksheets[tbname].Cells[newrow, 6]).Value = Filter[0].category.ToString();
                        //( wb.Worksheets[tbname].Cells[newrow, 7]).Value = Filter[0].mmeupdate.ToString();
                        //( wb.Worksheets[tbname].Cells[newrow, 10]).Value = Filter[0].name.ToString();
                        //( wb.Worksheets[tbname].Cells[newrow, 11]).Value = Filter[0].effectivedate.ToString("dd-MMM-yy");
                        //( wb.Worksheets[tbname].Cells[newrow, 12]).Value = Filter[0].location.ToString();
                        //( wb.Worksheets[tbname].Cells[newrow, 13]).Value = Filter[0].location.ToString();
                        //( wb.Worksheets[tbname].Cells[newrow, 15]).Value = Filter[0].gsorole.ToString();
                        //( wb.Worksheets[tbname].Cells[newrow, 17]).Value = Filter[0].newgsorole.ToString();

                        //ws.Cells.DeleteRow(newrow);

                        Aspose.Cells.Cell cell = ws.Cells["A" + newrow];
                        Aspose.Cells.Cell cell01 = ws.Cells["D" + newrow];
                        Aspose.Cells.Cell cell1 = ws.Cells["E" + newrow];
                        Aspose.Cells.Cell cell2 = ws.Cells["F" + newrow];
                        Aspose.Cells.Cell cell3 = ws.Cells["G" + newrow];
                        Aspose.Cells.Cell cell4 = ws.Cells["J" + newrow];
                        Aspose.Cells.Cell cell5 = ws.Cells["K" + newrow];
                        Aspose.Cells.Cell cell6 = ws.Cells["L" + newrow];
                        Aspose.Cells.Cell cell7 = ws.Cells["O" + newrow];
                        Aspose.Cells.Cell cell8 = ws.Cells["Q" + newrow];
                        Aspose.Cells.Cell cell9 = ws.Cells["R" + newrow];
                        Aspose.Cells.Cell cell10 = ws.Cells["T" + newrow];
                        Aspose.Cells.Cell cell11 = ws.Cells["V" + newrow];
                        Aspose.Cells.Cell cell12 = ws.Cells["W" + newrow];
                        Aspose.Cells.Cell cell13 = ws.Cells["Z" + newrow];
                        Aspose.Cells.Cell cell14 = ws.Cells["AB" + newrow];
                        Aspose.Cells.Cell cell15 = ws.Cells["AD" + newrow];
                        Aspose.Cells.Cell cell16 = ws.Cells["AE" + newrow];

                        Aspose.Cells.Cell cell17 = ws.Cells["AG" + newrow];
                        Aspose.Cells.Cell cell18 = ws.Cells["AH" + newrow];
                        Aspose.Cells.Cell cell19 = ws.Cells["AI" + newrow];
                        Aspose.Cells.Cell cell20 = ws.Cells["AJ" + newrow];
                        Aspose.Cells.Cell cell21 = ws.Cells["AK" + newrow];
                        Aspose.Cells.Cell cell22 = ws.Cells["AL" + newrow];
                        Aspose.Cells.Cell cell23 = ws.Cells["AM" + newrow];
                        Aspose.Cells.Cell cell24 = ws.Cells["AN" + newrow];
                        Aspose.Cells.Cell cell25 = ws.Cells["AO" + newrow];

                        Aspose.Cells.Cell cell26 = ws.Cells["AQ" + newrow];
                        Aspose.Cells.Cell cell27 = ws.Cells["AR" + newrow];
                        Aspose.Cells.Cell cell28 = ws.Cells["AS" + newrow];
                        Aspose.Cells.Cell cell29 = ws.Cells["AT" + newrow];
                        Aspose.Cells.Cell cell30 = ws.Cells["AU" + newrow];
                        Aspose.Cells.Cell cell31 = ws.Cells["AV" + newrow];
                        Aspose.Cells.Cell cell32 = ws.Cells["AW" + newrow];
                        Aspose.Cells.Cell cell33 = ws.Cells["AX" + newrow];
                        Aspose.Cells.Cell cell34 = ws.Cells["AY" + newrow];

                        Aspose.Cells.Cell cell35 = ws.Cells["BA" + newrow];
                        Aspose.Cells.Cell cell36 = ws.Cells["BB" + newrow];
                        Aspose.Cells.Cell cell37 = ws.Cells["BC" + newrow];
                        Aspose.Cells.Cell cell38 = ws.Cells["BD" + newrow];
                        Aspose.Cells.Cell cell39 = ws.Cells["BE" + newrow];
                        Aspose.Cells.Cell cell40 = ws.Cells["BF" + newrow];
                        Aspose.Cells.Cell cell41 = ws.Cells["BG" + newrow];
                        Aspose.Cells.Cell cell42 = ws.Cells["BH" + newrow];
                        Aspose.Cells.Cell cell43 = ws.Cells["BI" + newrow];

                        Aspose.Cells.Cell cell44 = ws.Cells["BK" + newrow];
                        Aspose.Cells.Cell cell45 = ws.Cells["BL" + newrow];
                        Aspose.Cells.Cell cell46 = ws.Cells["BM" + newrow];
                        Aspose.Cells.Cell cell47 = ws.Cells["BN" + newrow];
                        Aspose.Cells.Cell cell48 = ws.Cells["BO" + newrow];
                        Aspose.Cells.Cell cell49 = ws.Cells["BP" + newrow];
                        Aspose.Cells.Cell cell50 = ws.Cells["BQ" + newrow];
                        Aspose.Cells.Cell cell51 = ws.Cells["BR" + newrow];
                        Aspose.Cells.Cell cell52 = ws.Cells["BS" + newrow];

                        Aspose.Cells.Cell cell53 = ws.Cells["BU" + newrow];
                        Aspose.Cells.Cell cell54 = ws.Cells["BV" + newrow];
                        Aspose.Cells.Cell cell55 = ws.Cells["BW" + newrow];
                        Aspose.Cells.Cell cell56 = ws.Cells["BX" + newrow];
                        Aspose.Cells.Cell cell57 = ws.Cells["BY" + newrow];
                        Aspose.Cells.Cell cell58 = ws.Cells["BZ" + newrow];
                        Aspose.Cells.Cell cell59 = ws.Cells["CA" + newrow];
                        Aspose.Cells.Cell cell60 = ws.Cells["CB" + newrow];
                        Aspose.Cells.Cell cell61 = ws.Cells["CC" + newrow];

                        Aspose.Cells.Cell cell62 = ws.Cells["CF" + newrow];
                        Aspose.Cells.Cell cell63 = ws.Cells["CG" + newrow];
                        Aspose.Cells.Cell cell64 = ws.Cells["CH" + newrow];
                        Aspose.Cells.Cell cell65 = ws.Cells["CI" + newrow];
                        Aspose.Cells.Cell cell66 = ws.Cells["CJ" + newrow];
                        Aspose.Cells.Cell cell67 = ws.Cells["CK" + newrow];
                        Aspose.Cells.Cell cell68 = ws.Cells["CL" + newrow];
                        Aspose.Cells.Cell cell69 = ws.Cells["CM" + newrow];
                        Aspose.Cells.Cell cell70 = ws.Cells["CN" + newrow];

                        Aspose.Cells.Cell cell71 = ws.Cells["S" + newrow];
                        Aspose.Cells.Cell cell72 = ws.Cells["U" + newrow];

                        //Abir
                        Aspose.Cells.Cell cell73 = ws.Cells["AA" + newrow];
                        Aspose.Cells.Cell cell74 = ws.Cells["AC" + newrow];


                        cell.PutValue(Filter[0].woname.ToString());
                        cell01.PutValue(duname.SelectedItem.ToString());
                        cell1.PutValue(Filter[0].typeOfPlan.ToString());
                        cell2.PutValue(planresource.SelectedValue.ToString());
                        cell3.PutValue(Filter[0].mmeupdate.ToString());
                        cell4.PutValue(Filter[0].name.ToString());
                        cell5.PutValue(Filter[0].effectivedate.ToString());
                        cell6.PutValue(Filter[0].location.ToString());
                        cell7.PutValue(Filter[0].gsorole.ToString());
                        cell8.PutValue(Filter[0].newgsorole.ToString());
                        cell9.PutValue(Convert.ToDouble(gsobillrate));

                        //Double newBillRate;
                        //Double.TryParse(newgsobillrate, out newBillRate);
                        //cell10.PutValue(newBillRate);
                        //cell10.PutValue(Convert.ToDouble(newgsobillrate));

                        cell10.Formula = "=IFERROR(IF($F" + newrow + "='Input Sheet'!$J$12,VLOOKUP(" + duname.SelectedValue.ToString() + "!$Q" + newrow + ",'Input Sheet'!$B$4:$C$61,2,0),IF($F" + newrow + "='Input Sheet'!$J$13,VLOOKUP(" + duname.SelectedValue.ToString() + "!$Q" + newrow + ",'Input Sheet'!$B$4:$C$61,2,0),VLOOKUP(" + duname.SelectedValue.ToString() + "!$O" + newrow + ",'Input Sheet'!$B$4:$C$61,2,0))),0)";
                        
                        if (Filter[0].location.ToString() == "Onshore")
                        {
                            cell11.PutValue(Convert.ToInt32("8"));
                            cell12.PutValue(Convert.ToInt32("8"));

                        }
                        if (Filter[0].location.ToString() == "Offshore")
                        {
                            cell11.PutValue(Convert.ToInt32("8"));
                            cell12.PutValue(Convert.ToInt32("9"));

                        }

                        //cell13.PutValue(Convert.ToDouble(gsobillrate));
                        //cell14.PutValue(Convert.ToDouble(newBillRate)); 
                        //cell14.PutValue(Convert.ToDouble(newgsobillrate));
                        cell13.Formula = "=IFERROR(IF($G" + newrow + "='Input Sheet'!$G$10,VLOOKUP($F" + newrow + ",'Input Sheet'!$J$4:$O$18,'Input Sheet'!M$2,0)*R" + newrow + ",0),0)";
                        cell14.Formula = "=IFERROR(IF($G" + newrow + "='Input Sheet'!$G$10,VLOOKUP($F" + newrow + ",'Input Sheet'!$J$4:$O$18,'Input Sheet'!O$2,0)*T" + newrow + ",0),0)";

                        cell15.Formula = "=AB" + newrow + "-Z" + newrow;
                        cell16.Formula = "=AC" + newrow + "-AA" + newrow;

                        cell17.Formula = "=IF(($AG$3-$K" + newrow + ")>0,IF($K" + newrow + ">0,NETWORKDAYS($K" + newrow + ",$AG$3),0),0)";
                        cell18.Formula = "=AG" + newrow + "*$V" + newrow + "*$AD" + newrow;
                        cell19.Formula = "=AH" + newrow + "*AI$3";
                        cell20.Formula = "=AH" + newrow + "-AI" + newrow ;
                        cell21.Formula = "= IF($L" + newrow + "= \"onshore\" ,AG" + newrow + "*$W" + newrow + "*$AE" + newrow + ",$AE" + newrow + "*$W" + newrow + "* AG" + newrow + ")";
                        cell22.Formula = "=AK" + newrow + "*AL$3";
                        cell23.Formula = "=AK" + newrow + "*AM$3";
                        cell24.Formula = "=AM" + newrow+ "+AL" + newrow + "+AK" + newrow ;
                        cell25.Formula = "=AJ" + newrow +  "-AN" + newrow;

                        cell26.Formula = "=IF(($AQ$3-$K" + newrow + ")>0,IF($K" + newrow + ">0,NETWORKDAYS($K" + newrow + ",$AQ$3),0),0) - AG" + newrow;
                        cell27.Formula = "=AQ" + newrow + "*$V" + newrow + "*$AD" + newrow;
                        cell28.Formula = "=AR" + newrow + "*AS$3";
                        cell29.Formula = "=AR" + newrow + "-AS" + newrow;
                        cell30.Formula = "= IF($L" + newrow + "= \"onshore\" ,AQ" + newrow + "*$W" + newrow + "*$AE" + newrow + ",$AE" + newrow + "*$W" + newrow + "* AQ" + newrow + ")";
                        cell31.Formula = "=AU" + newrow + "*AV$3";
                        cell32.Formula = "=AU" + newrow + "*AW$3";
                        cell33.Formula = "=AW" + newrow + "+AV" + newrow + "+AU" + newrow;
                        cell34.Formula = "=AT" + newrow + "-AX" + newrow;

                        cell35.Formula = "=IF(($BA$3-$K" + newrow + ")>0,IF($K" + newrow + ">0,NETWORKDAYS($K" + newrow + ",$BA$3),0),0) - AQ" + newrow + "-AG" + newrow;
                        cell36.Formula = "=BA" + newrow + "*$V" + newrow + "*$AD" + newrow;
                        cell37.Formula = "=BB" + newrow + "*BC$3";
                        cell38.Formula = "=BB" + newrow + "-BC" + newrow;
                        cell39.Formula = "= IF($L" + newrow + "= \"onshore\" ,BA" + newrow + "*$W" + newrow + "*$AE" + newrow + ",$AE" + newrow + "*$W" + newrow + "* BA" + newrow + ")";
                        cell40.Formula = "=BE" + newrow + "*BF$3";
                        cell41.Formula = "=BE" + newrow + "*BG$3";
                        cell42.Formula = "=BG" + newrow + "+BF" + newrow + "+BE" + newrow;
                        cell43.Formula = "=BD" + newrow + "-BH" + newrow;

                        cell44.Formula = "=IF($K" + newrow + ">0,NETWORKDAYS($K" + newrow + ",$BK$3),0) - AG" + newrow + "-AQ" + newrow + "-BA" + newrow;
                        cell45.Formula = "=BK" + newrow + "*$V" + newrow + "*$AD" + newrow;
                        cell46.Formula = "=BL" + newrow + "*BM$3";
                        cell47.Formula = "=BL" + newrow + "-BM" + newrow;
                        cell48.Formula = "= IF($L" + newrow + "= \"onshore\" ,BK" + newrow + "*$W" + newrow + "*$AE" + newrow + ",$AE" + newrow + "*$W" + newrow + "* BK" + newrow + ")";
                        cell49.Formula = "=BO" + newrow + "*BP$3";
                        cell50.Formula = "=BO" + newrow + "*BQ$3";
                        cell51.Formula = "=BQ" + newrow + "+BP" + newrow + "+BO" + newrow;
                        cell52.Formula = "=BN" + newrow + "-BR" + newrow;

                        cell53.Formula = "=BK" + newrow + "+BA" + newrow + "+AQ" + newrow  + "+AG" + newrow;
                        cell54.Formula = "=BL" + newrow + "+BB" + newrow + "+AR" + newrow + "+AH" + newrow;
                        cell55.Formula = "=BM" + newrow + "+BC" + newrow + "+AS" + newrow + "+AI" + newrow;
                        cell56.Formula = "=BN" + newrow + "+BD" + newrow + "+AT" + newrow + "+AJ" + newrow;
                        cell57.Formula = "=BO" + newrow + "+BE" + newrow + "+AU" + newrow + "+AK" + newrow;
                        cell58.Formula = "=BP" + newrow + "+BF" + newrow + "+AV" + newrow + "+AL" + newrow;
                        cell59.Formula = "=BQ" + newrow + "+BG" + newrow + "+AW" + newrow + "+AM" + newrow;
                        cell60.Formula = "=BR" + newrow + "+BH" + newrow + "+AX" + newrow + "+AN" + newrow;
                        cell61.Formula = "=BX" + newrow + "-CB" + newrow;

                        cell62.Formula = "=IF($K" + newrow + ">0,NETWORKDAYS($K" + newrow + ",$CF$3),0)";
                        cell63.Formula = "=CF" + newrow + "*$CT" + newrow + "*$V" + newrow;
                        cell64.Formula = "=CG" + newrow + "*CH$3";
                        cell65.Formula = "CG" + newrow + "-CH" + newrow;
                        cell66.Formula = "= IF($L" + newrow + "= \"onshore\" ,CF" + newrow + "*$W" + newrow + "*$CU" + newrow + ",$CU" + newrow + "*$W" + newrow + "* CF" + newrow + ")";
                        cell67.Formula = "=CJ" + newrow + "*CK$3";
                        cell68.Formula = "=CJ" + newrow + "*CL$3";
                        cell69.Formula = "=CL" + newrow + "+CK" + newrow + "+CJ" + newrow;
                        cell70.Formula = "=CI" + newrow + "-CM" + newrow;

                        cell71.PutValue(lcr);
                        cell72.PutValue(lcr);
                        //Abir
                        cell73.Formula = "=IFERROR(IF($G" + newrow + "= 'Input Sheet'!$G$10,VLOOKUP($F" + newrow + ",'Input Sheet'!$J$4:$O$18,'Input Sheet'!L$2,0)*S" + newrow + ",0),0)";
                        cell74.Formula = "=IFERROR(IF($G" + newrow + "='Input Sheet'!$G$10,VLOOKUP($F" + newrow + ",'Input Sheet'!$J$4:$O$18,'Input Sheet'!N$2,0)*U" + newrow + ",0),0)";


                        wb.CalculateFormula();

                        //Autofit columns
                        ws.AutoFitColumns();

                        wb.Save(fullpath.FullName, SaveFormat.Xlsb);

                        //wb.Save(@"D:\Financial_LOB\LOB Financials FY20 based on Jan'20 Forecast-V1_24th Feb20.xlsx", SaveFormat.Xlsx);

                        //Microsoft.Office.Interop.Excel.Application excelApp = new Microsoft.Office.Interop.Excel.Application();

                        // open book in any format
                        //Microsoft.Office.Interop.Excel.Workbook workbooks = excelApp.Workbooks.Open(@"D:\Financial_LOB\LOB Financials FY20 based on Jan'20 Forecast-V1_24th Feb20.xlsx", Microsoft.Office.Interop.Excel.XlUpdateLinks.xlUpdateLinksNever, true, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                       
                       // workbooks.Worksheets["Evaluation Warning"].Delete();
                        // save in XlFileFormat.xlExcel12 format which is XLSB
                        //workbooks.SaveAs(fullpath.FullName, Microsoft.Office.Interop.Excel.XlFileFormat.xlExcel12, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                        // close workbook
                        //workbooks.Close(false, Type.Missing, Type.Missing);

                        // shutdown excel
                       // excelApp.Quit();

                      // File.Delete(@"D:\Financial_LOB\LOB Financials FY20 based on Jan'20 Forecast-V1_24th Feb20.xlsx");

                        getccinewUpdate(fullpath);

                        found = true;
                    }
                    break;
                }

                if (found == true)
                {
                    
                    break; // get out of the loop
                }
            }



        }

        private void duname_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (duname.SelectedValue.ToString() == "FSIG47")
            {
                woname.ItemsSource = fc.woNumber3;
                woname.SelectedIndex = 1;
            }
            else if (duname.SelectedValue.ToString() == "FSIG99")
            {
                woname.ItemsSource = fc.woNumber;
                woname.SelectedIndex = 1;
            }
            else if (duname.SelectedValue.ToString() == "FSIG49")
            {
                woname.ItemsSource = fc.woNumber4;
                woname.SelectedIndex = 1;
            }
            else if (duname.SelectedValue.ToString() == "FSIG40")
            {
                woname.ItemsSource = fc.woNumber2;
                woname.SelectedIndex = 1;
            }
            else if (duname.SelectedValue.ToString() == "FSIG09")
            {
                woname.ItemsSource = fc.woNumber1;
                woname.SelectedIndex = 1;
            }
        }

        private void gsorole_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
             gsobillrate = fc.gsoroleBill[gsorole.SelectedIndex];
        }

        private void newgsorole_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            newgsobillrate = fc.gsoroleBill[newgsorole.SelectedIndex];

        }

        private void typeofplan_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (typeofplan.SelectedValue.ToString() == "Billable to Non Billable")
            {
                planresource.ItemsSource = fc.SubCategory1;
                planresource.SelectedValue = 1;
            }
            else if (typeofplan.SelectedValue.ToString() == "Location change - Same Resource")
            {
                planresource.ItemsSource = fc.SubCategory2;
                planresource.SelectedValue = 1;
            }
            else if (typeofplan.SelectedValue.ToString() == "Non Billable to Billable")
            {
                planresource.ItemsSource = fc.SubCategor3;
                planresource.SelectedValue = 1;
            }
            else if (typeofplan.SelectedValue.ToString() == "Role Bump")
            {
                planresource.ItemsSource = fc.SubCategor4;
                planresource.SelectedValue = 1;
            }
            else if (typeofplan.SelectedValue.ToString() == "Roll Off")
            {
                planresource.ItemsSource = fc.SubCategor5;
                planresource.SelectedValue = 1;
            }
            else if (typeofplan.SelectedValue.ToString() == "WO Movement")
            {
                planresource.ItemsSource = fc.SubCategor6;
                planresource.SelectedValue = 1;
            }
            else {
                planresource.ItemsSource = fc.SubCategory;
                planresource.SelectedValue= 1;
            }
        }
    }
}
