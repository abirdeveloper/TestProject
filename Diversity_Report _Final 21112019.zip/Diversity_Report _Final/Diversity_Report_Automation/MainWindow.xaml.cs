﻿using Microsoft.Office.Interop.Excel;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using OfficeOpenXml.Table.PivotTable;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Windows;
using WPFNotification.Model;
using WPFNotification.Services;
using System.Collections;
using System.ComponentModel;

namespace Diversity_Report_Automation
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : System.Windows.Window
    {
        public string excelpath;
        public List<int> cellIndex = new List<int>() { 4, 6, 7, 13, 14, 15, 16 };
        public int result;
        public string AbacusWorksheet;
        public string ResourceDump;
        public string FHLWorksheet;
        private BackgroundWorker bw = new BackgroundWorker();
        Popup pop = new Popup();
        public int totalASECount;
        public int totalFulfilledASECount;
        public int totalFulfilledFemaleASECount;
        public int totalRHYLCount;
        public int openDemandCount;
        public int totalLockCount;
        public int totalFemaleLockCount;
        public int totalFemaleJoinersCount;
        public int totalJoinersCount;

        public MainWindow()
        {
            InitializeComponent();
            excelpath = "";
        }


        private void BrowseButton_Click(object sender, RoutedEventArgs e)
        {
            // Create OpenFileDialog
            Microsoft.Win32.OpenFileDialog openFileDlg = new Microsoft.Win32.OpenFileDialog();
            openFileDlg.Multiselect = true;
            openFileDlg.Filter = "All files (*.*)|*.*";
            // Launch OpenFileDialog by calling ShowDialog method
            Nullable<bool> result = openFileDlg.ShowDialog();
            // Get the selected file name and display in a TextBox.
            // Load content of file in a TextBlock
            if (result == true)
            {
                if (openFileDlg.FileNames.Count() > 0)
                {
                    string fname = "";
                    foreach (var item in openFileDlg.FileNames)
                    {
                        fname = item + ";" + fname;
                    }

                    FileNameTextBox.Text = fname.TrimEnd(';');
                    TextBlock1.Visibility = Visibility.Visible;
                }
                else
                    FileNameTextBox.Text = openFileDlg.FileName;
                TextBlock1.Visibility = Visibility.Visible;


            }
        }


        private void button_Click(object sender, RoutedEventArgs e)
        {
  
            bw.WorkerReportsProgress = true;
            bw.DoWork += bw_DoWork;           
            bw.RunWorkerCompleted += bw_RunWorkerCompleted;
            bw.RunWorkerAsync();

            //Progress Bar Window
            pop.Show();
            //getData(filename);
        }
        private void bw_DoWork(object sender, DoWorkEventArgs e)
        {
            this.Dispatcher.Invoke(() =>
            {
                string[] filename = FileNameTextBox.Text.Split(';');
                getData(filename);

            });
            
        }
        private void bw_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            //Progress Bar Window close
            pop.Close();
        }

        
        public void getData(string[] filename)
        {
            try
            {
                INotificationDialogService _dailogService = new NotificationDialogService();
                string con = "";
                DataSet ds = new DataSet();
                DataTableCollection dt = ds.Tables;

                for (int i = 0; i < filename.Length; i++)
                {
                    con =
      @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filename[i] + " ;" +
      @"Extended Properties='Excel 12.0;HDR=NO;IMEX=1'";


                                        
                    if (filename[i].Contains("ROV_Report"))
                    {
                        using (OleDbConnection connection = new OleDbConnection(con))
                        {
                            connection.Open();

                            OleDbCommand commandAD = new OleDbCommand("select * from [ROV Base$]", connection);
                            commandAD.CommandType = CommandType.Text;
                            OleDbDataAdapter myDataAdaptorAD = new OleDbDataAdapter(commandAD);
                            myDataAdaptorAD.Fill(ds, "ROV Base");
                            dt = ds.Tables;

                            //var currentMonth = string.Format("{0:MMM-yy}", DateTime.Now);
                            //string query1 = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F49 = '{0}'";
                            //string dataReader5 = string.Format(query1, currentMonth);
                            //OleDbCommand command5 = new OleDbCommand(dataReader5, connection);
                            //int cnt1 = (int)command5.ExecuteScalar();
                        }
                    }
                    if (filename[i].Contains("Resource dump"))
                    {
                        using (OleDbConnection connection = new OleDbConnection(con))
                        {
                            connection.Open();
                            OleDbCommand commandBD = new OleDbCommand("select * from [Sheet 1$]", connection);
                            OleDbDataAdapter myDataAdaptorBD = new OleDbDataAdapter(commandBD);
                            myDataAdaptorBD.Fill(ds, "Resource dump");
                            dt = ds.Tables;
                        }
                    }
                    if (filename[i].Contains("Travelers diversity"))

                    {
                        using (OleDbConnection connection = new OleDbConnection(con))
                        {
                            connection.Open();
                            OleDbCommand commandCD = new OleDbCommand("select * from [Sheet1$]", connection);
                            OleDbDataAdapter myDataAdaptorCD = new OleDbDataAdapter(commandCD);
                            myDataAdaptorCD.Fill(ds, "Travelers diversity");
                            dt = ds.Tables;
                        }
                    }
                    if (filename[i].Contains("Demand dump"))
                    {
                        using (OleDbConnection connection = new OleDbConnection(con))
                        {
                            connection.Open();
                            OleDbCommand commandDD = new OleDbCommand("select * from [Sheet 1$]", connection);
                            OleDbDataAdapter myDataAdaptorDD = new OleDbDataAdapter(commandDD);
                            myDataAdaptorDD.Fill(ds, "Demand dump");
                            dt = ds.Tables;
                        }
                    }

                    if (filename[i].Contains("FHL Dump"))
                    {
                        using (OleDbConnection connection = new OleDbConnection(con))
                        {
                            connection.Open();
                            OleDbCommand commandDE = new OleDbCommand("select * from [Sheet 1$]", connection);
                            OleDbDataAdapter myDataAdaptorDE = new OleDbDataAdapter(commandDE);
                            myDataAdaptorDE.Fill(ds, "FHL dump");
                            dt = ds.Tables;
                        }
                    }
                }
                

                #region Ase-Status Copy
                string startupPath = System.AppDomain.CurrentDomain.BaseDirectory + "ASE Status.xlsx";

                con = 
                    @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + startupPath + " ;" +
                    @"Extended Properties='Excel 12.0;HDR=NO;IMEX=1'";

                using (OleDbConnection connection = new OleDbConnection(con))
                {
                    connection.Open();
                    OleDbCommand commandDF = new OleDbCommand("select * from [Sheet1$]", connection);
                    OleDbDataAdapter myDataAdaptorDF = new OleDbDataAdapter(commandDF);
                    myDataAdaptorDF.Fill(ds, "ASE Status");
                    dt = ds.Tables;
                }
                #endregion

                #region Demand-Diversity Copy

                string startupPathDemandDiversity = System.AppDomain.CurrentDomain.BaseDirectory + "Demand-Diversity.xlsx";

                con = 
                    @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + startupPathDemandDiversity + " ;" +
                    @"Extended Properties='Excel 12.0;HDR=NO;IMEX=1'";

                using (OleDbConnection connection = new OleDbConnection(con))
                {
                    connection.Open();
                    OleDbCommand commandDF = new OleDbCommand("select * from [Sheet1$]", connection);
                    OleDbDataAdapter myDataAdaptorDF = new OleDbDataAdapter(commandDF);
                    myDataAdaptorDF.Fill(ds, "Demand-Diversity");
                    dt = ds.Tables;
                }

                #endregion

               
                //#region Details

                //string startupPathDetails = System.AppDomain.CurrentDomain.BaseDirectory + "Details.xlsx";

                //con =
                //    @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + startupPathDetails + " ;" +
                //    @"Extended Properties='Excel 12.0;HDR=NO;IMEX=1'";

                //using (OleDbConnection connection = new OleDbConnection(con))
                //{
                //    connection.Open();
                //    OleDbCommand commandDF = new OleDbCommand("select * from [Sheet1$]", connection);
                //    OleDbDataAdapter myDataAdaptorDF = new OleDbDataAdapter(commandDF);
                //    myDataAdaptorDF.Fill(ds, "Details");
                //    dt = ds.Tables;
                //}


                //#endregion

                generateExcel(dt);

                
                TextBlock1.Text = "Completed";

                var newNotification = new Notification()
                {
                    Title = "Excel Created",
                    Message = "Excel file created , you can find the file : " + excelpath
                };

                _dailogService.ShowNotificationWindow(newNotification);
            }
            catch (Exception ex)
            {
                MessageBox.Show("A handled exception just occurred: " + ex.Message, "Exception : ", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        public void generateExcel(DataTableCollection Dtvalue)
        {
            try
            {
                String timeStamp = GetTimestamp(DateTime.Now);

                if (!Directory.Exists(@"C:\RE__Diversity_report"))
                    Directory.CreateDirectory(@"C:\RE__Diversity_report");

                excelpath = @"C:\RE__Diversity_report\Diversity Calculation_" + timeStamp + ".xlsx";

                DateTime date = DateTime.Now;
                string dateFormat = string.Format("{0:dd MMM yy}", date);

                FileInfo finame = new FileInfo(excelpath);
                string ROV = "ROV-" + dateFormat;
                string RES = "Res Dump-" + dateFormat;
                ResourceDump = RES;
                string Abacus = "Abacus Demand Dump -" + dateFormat;
                AbacusWorksheet = Abacus;
                string FHL = "FHL Dump -" + dateFormat;
                FHLWorksheet = FHL;
                string DemandDiversity = "Demand-Diversity -" + dateFormat;

                if (!System.IO.File.Exists(excelpath))
                {
                    using (ExcelPackage excel = new ExcelPackage())
                    {
                        ExcelWorksheet ws = excel.Workbook.Worksheets.Add(RES);
                        ExcelWorksheet ws2 = excel.Workbook.Worksheets.Add(ROV);
                        ExcelWorksheet ws3 = excel.Workbook.Worksheets.Add("Base");
                        ExcelWorksheet ws4 = excel.Workbook.Worksheets.Add(Abacus);
                        ExcelWorksheet ws5 = excel.Workbook.Worksheets.Add(FHL);
                        ExcelWorksheet ws6 = excel.Workbook.Worksheets.Add("ASE Status");
                        ExcelWorksheet wsPivot = excel.Workbook.Worksheets.Add("Pivot-Base");
                        ExcelWorksheet wsPivot1 = excel.Workbook.Worksheets.Add("Abacus-Pivot");
                        ExcelWorksheet ws7 = excel.Workbook.Worksheets.Add("Demand-Diversity");


                        int count = 0;
                        int count1 = 0;
                        int count2 = 0;
                        int count3 = 0;
                        int count4 = 0;
                        int count5 = 0;
                        int count6 = 0;

                        for (int y = 0; y < Dtvalue.Count; y++)
                        {
                            #region FHL Dump

                            if (Dtvalue[y].TableName == "FHL dump")
                            {
                                foreach (DataRow dr in Dtvalue[y].Rows)//.Cast<DataRow>().Skip(3)
                                {
                                    count4 = count4 + 1;
                                    int n = 0;
                                    for (int j = 8; j <= 127; j++)
                                    {
                                        n = n + 1;
                                        int result4;
                                        var isNumeric = int.TryParse(dr.ItemArray[j].ToString(), out result4);
                                        if (isNumeric == true)
                                        {
                                            ws5.Cells[count4, n].Value = Convert.ToInt32(dr.ItemArray[j]);
                                            ws5.Cells[count4, n].Style.Numberformat.Format = "0";
                                        }
                                        else
                                        {
                                            ws5.Cells[count4, n].Value = dr.ItemArray[j].ToString();
                                        }

                                        if (count4 == 1)
                                        {

                                            ws5.Cells[count4, n].Style.Font.Bold = true;
                                            ws5.Cells[count4, n].Style.Font.Size = 10;
                                            ws5.Cells[count4, n].Style.Font.Name = "Verdana";

                                        }

                                        if (dr.ItemArray[j] == null)
                                        {
                                            break;
                                        }
                                    }
                                }
                            }
                            #endregion

                            #region Abacus Demand Dump

                            if (Dtvalue[y].TableName == "Demand dump")
                            {
                                var colCount = Dtvalue[y].Columns.Count;
                                foreach (DataRow dr in Dtvalue[y].Rows) //Cast<DataRow>().Skip(3)
                                {
                                    count3 = count3 + 1;
                                    int n = 0;

                                    for (int j = 0; j < colCount; j++) //8
                                    {
                                        n = n + 1;
                                        int result3;
                                        var isNumeric = int.TryParse(dr.ItemArray[j].ToString(), out result3);
                                        if (isNumeric == true)
                                        {
                                            ws4.Cells[count3, n].Value = Convert.ToInt32(dr.ItemArray[j]);
                                            ws4.Cells[count3, n].Style.Numberformat.Format = "0";
                                        }
                                        else
                                        {

                                            ws4.Cells[count3, n].Value = dr.ItemArray[j].ToString();
                                        }

                                        if (count3 == 1)
                                        {
                                            ws4.Cells[count3, n].Style.Font.Bold = true;
                                            ws4.Cells[count3, n].Style.Font.Size = 10;
                                            ws4.Cells[count3, n].Style.Font.Name = "Verdana";
                                        }

                                        if (dr.ItemArray[j] == null)
                                        {
                                            break;
                                        }
                                    }
                                }
                            }

                            #endregion

                            #region Resource Dump
                            if (Dtvalue[y].TableName == "Resource dump")
                            {
                                var colCount = Dtvalue[y].Columns.Count;
                                foreach (DataRow dr in Dtvalue[y].Rows) //.Cast<DataRow>().Skip(3)
                                {
                                    count1 = count1 + 1;
                                    int n = 0;
                                    for (int j = 0; j <= 142; j++)
                                    {
                                        n = n + 1;
                                        if (j <= 138)
                                        {
                                            int result;
                                            var isNumeric = int.TryParse(dr.ItemArray[j].ToString(), out result);
                                            if (isNumeric == true)
                                            {
                                                ws.Cells[count1, n].Value = Convert.ToInt32(dr.ItemArray[j]);
                                                ws.Cells[count1, n].Style.Numberformat.Format = "0";
                                            }
                                            else
                                            {
                                                ws.Cells[count1, n].Value = dr.ItemArray[j].ToString();
                                            }

                                            if (count1 == 1)
                                            {
                                                ws.Cells[count1, n].Style.Font.Bold = true;
                                                ws.Cells[count1, n].Style.Font.Size = 10;
                                                ws.Cells[count1, n].Style.Font.Name = "Verdana";
                                            }
                                        }

                                        if (j == 139)
                                        {
                                            if (count1 == 1)
                                            {
                                                ws.Cells[count1, n].Value = "Lock Start Month";
                                                ws.Cells[count1, n].Style.Font.Bold = true;
                                                ws.Cells[count1, n].Style.Font.Size = 10;
                                                ws.Cells[count1, n].Style.Font.Name = "Verdana";
                                                ws.Cells[count1, n].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                                ws.Cells[count1, n].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);
                                            }
                                            else
                                            {
                                                ws.Cells[count1, n].Formula = "TEXT(AE" + count1 + ",\"mmm-yy\")";
                                            }
                                        }

                                        if (j == 140)
                                        {
                                            if (count1 == 1)
                                            {
                                                ws.Cells[count1, n].Value = "Base Data";
                                                ws.Cells[count1, n].Style.Font.Bold = true;
                                                ws.Cells[count1, n].Style.Font.Size = 10;
                                                ws.Cells[count1, n].Style.Font.Name = "Verdana";
                                                ws.Cells[count1, n].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                                ws.Cells[count1, n].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);
                                            }
                                            else
                                            {
                                                ws.Cells[count1, n].Formula = "VLOOKUP(Q" + count1 + ",'Base'!$C:C,1,0)";
                                            }
                                        }

                                        if (j == 141)
                                        {
                                            if (count1 == 1)
                                            {
                                                ws.Cells[count1, n].Value = "Personnel No.";
                                                ws.Cells[count1, n].Style.Font.Bold = true;
                                                ws.Cells[count1, n].Style.Font.Size = 10;
                                                ws.Cells[count1, n].Style.Font.Name = "Verdana";
                                                ws.Cells[count1, n].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                                ws.Cells[count1, n].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);
                                            }
                                            else
                                            {
                                                ws.Cells[count1, n].Formula = "VLOOKUP(Q" + count1 + ",'" + ws.Name + "'!$Q:Q,1,0)";
                                            }
                                        }

                                        if (j == 142)
                                        {
                                            if (count1 == 1)
                                            {
                                                ws.Cells[count1, n].Value = "Status";
                                                ws.Cells[count1, n].Style.Font.Bold = true;
                                                ws.Cells[count1, n].Style.Font.Size = 10;
                                                ws.Cells[count1, n].Style.Font.Name = "Verdana";
                                                ws.Cells[count1, n].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                                ws.Cells[count1, n].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);
                                            }
                                            else
                                            {
                                                ws.Cells[count1, n].Formula = "VLOOKUP(R" + count1 + ",'" + ws.Name + "'!$R:R,1,0)";
                                            }
                                        }
                                    }
                                }
                            }
                            #endregion

                            #region Rov Base  
                            if (Dtvalue[y].TableName == "ROV Base")
                            {
                                foreach (DataRow dr in Dtvalue[y].Rows.Cast<DataRow>().Where(
                                    row => row.ItemArray.Any(field => !(field is System.DBNull))))
                                {
                                    count = count + 1;
                                    int n = 0;

                                    for (int j = 0; j <= 23; j++)
                                    {
                                        n = n + 1;
                                        int result1;
                                        var isNumeric = int.TryParse(dr.ItemArray[j].ToString(), out result1);
                                        if (isNumeric == true)
                                        {
                                            ws2.Cells[count, n].Value = Convert.ToInt32(dr.ItemArray[j]);
                                            ws2.Cells[count, n].Style.Numberformat.Format = "0";
                                        }
                                        else
                                        {
                                            ws2.Cells[count, n].Value = dr.ItemArray[j].ToString();
                                        }
                                        if (count == 1)
                                        {
                                            ws2.Cells[count, n].Style.Font.Bold = true;
                                            ws2.Cells[count, n].Style.Font.Size = 10;
                                            ws2.Cells[count, n].Style.Font.Name = "Verdana";
                                        }

                                        if (dr.ItemArray[j] == null)
                                        {
                                            break;
                                        }
                                    }
                                }
                            }
                            #endregion

                            #region  Travelers diversity

                            if (Dtvalue[y].TableName == "Travelers diversity")
                            {
                                foreach (DataRow dr in Dtvalue[y].Rows)
                                {
                                    count2 = count2 + 1;
                                    int n = 0;

                                    #region ToDelete        
                                    //for (int j = 0; j <= 49; j++)
                                    //{
                                    //    n = n + 1;

                                    //    if (j <= 44)
                                    //    {
                                    //        int result2;
                                    //        var isNumeric = int.TryParse(dr.ItemArray[j].ToString(), out result2);
                                    //        if (isNumeric == true)
                                    //        {
                                    //            ws3.Cells[count2, n].Value = Convert.ToInt32(dr.ItemArray[j]);
                                    //            ws3.Cells[count2, n].Style.Numberformat.Format = "0";
                                    //        }
                                    //        else
                                    //        {
                                    //            ws3.Cells[count2, n].Value = dr.ItemArray[j].ToString();
                                    //        }
                                    //        if (count2 == 1)
                                    //        {
                                    //            ws3.Cells[count2, n].Style.Font.Bold = true;
                                    //            ws3.Cells[count2, n].Style.Font.Size = 10;
                                    //            ws3.Cells[count2, n].Style.Font.Name = "Verdana";
                                    //        }
                                    //    }

                                    //    if (j == 45)
                                    //    {
                                    //        if (count2 == 1)
                                    //        {
                                    //            ws3.Cells[count2, n].Value = "Resource Dump_Abacus";
                                    //            ws3.Cells[count2, n].Style.Font.Bold = true;
                                    //            ws3.Cells[count2, n].Style.Font.Size = 10;
                                    //            ws3.Cells[count2, n].Style.Font.Name = "Verdana";
                                    //            ws3.Cells[count2, n].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                    //            ws3.Cells[count2, n].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);
                                    //        }
                                    //        else
                                    //        {
                                    //            ws3.Cells[count2, n].Formula = "VLOOKUP(C" + count2 + ",'" + ws.Name + "'!$Q:Q,1,0)";
                                    //        }
                                    //    }

                                    //    if (j == 46)
                                    //    {
                                    //        if (count2 == 1)
                                    //        {
                                    //            ws3.Cells[count2, n].Value = ws2.Name;
                                    //            ws3.Cells[count2, n].Style.Font.Bold = true;
                                    //            ws3.Cells[count2, n].Style.Font.Size = 10;
                                    //            ws3.Cells[count2, n].Style.Font.Name = "Verdana";
                                    //            ws3.Cells[count2, n].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                    //            ws3.Cells[count2, n].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);
                                    //        }
                                    //        else
                                    //        {
                                    //            ws3.Cells[count2, n].Formula = "VLOOKUP(C" + count2 + ",'" + ws2.Name + "'!B:Q,16,0)";
                                    //        }
                                    //    }

                                    //    if (j == 47)
                                    //    {
                                    //        if (count2 == 1)
                                    //        {
                                    //            ws3.Cells[count2, n].Value = "ROV Date";
                                    //            ws3.Cells[count2, n].Style.Font.Bold = true;
                                    //            ws3.Cells[count2, n].Style.Font.Size = 10;
                                    //            ws3.Cells[count2, n].Style.Font.Name = "Verdana";
                                    //            ws3.Cells[count2, n].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                    //            ws3.Cells[count2, n].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);
                                    //        }
                                    //        else
                                    //        {
                                    //           ws3.Cells[count2, n].Formula = "VLOOKUP(C" + count2 + ",'" + ws2.Name + "'!B:M,12,0)";
                                    //        }
                                    //    }

                                    //    if (j == 48)
                                    //    {
                                    //        if (count2 == 1)
                                    //        {
                                    //            ws3.Cells[count2, n].Value = "ROV Month";
                                    //            ws3.Cells[count2, n].Style.Font.Bold = true;
                                    //            ws3.Cells[count2, n].Style.Font.Size = 10;
                                    //            ws3.Cells[count2, n].Style.Font.Name = "Verdana";
                                    //            ws3.Cells[count2, n].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                    //            ws3.Cells[count2, n].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);
                                    //        }
                                    //        else
                                    //        {
                                    //            ws3.Cells[count2, n].Formula = "TEXT(AV" + count2 + ", \"mmm-yy\")";
                                    //        }
                                    //    }

                                    //    if (j == 49)
                                    //    {
                                    //        if (count2 == 1)
                                    //        {
                                    //            ws3.Cells[count2, n].Value = "Personnel No";
                                    //            ws3.Cells[count2, n].Style.Font.Bold = true;
                                    //            ws3.Cells[count2, n].Style.Font.Size = 10;
                                    //            ws3.Cells[count2, n].Style.Font.Name = "Verdana";
                                    //            ws3.Cells[count2, n].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                    //            ws3.Cells[count2, n].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);
                                    //        }
                                    //        else
                                    //        {
                                    //            ws3.Cells[count2, n].Formula = "VLOOKUP(C" + count2 + ",'" + ws3.Name + "'!$C:C,1,0)";
                                    //        }
                                    //    }
                                    //}
                                    #endregion

                                    for (int j = 0; j < dr.ItemArray.Count(); j++)
                                    {
                                        n = n + 1;

                                        int result6;
                                        var isNumeric = int.TryParse(dr.ItemArray[j].ToString(), out result6);
                                        if (isNumeric == true)
                                        {
                                            ws3.Cells[count2, n].Value = Convert.ToInt32(dr.ItemArray[j]);
                                            ws3.Cells[count2, n].Style.Numberformat.Format = "0";
                                        }
                                        else
                                        {
                                            ws3.Cells[count2, n].Value = dr.ItemArray[j].ToString();
                                        }
                                    }
                                }

                                int cntt = 0;
                                int colCnt = ws3.Dimension.Columns;
                                int newColumn1 = colCnt + 1;
                                int newColumn2 = colCnt + 2;
                                int newColumn3 = colCnt + 3;
                                int newColumn4 = colCnt + 4;
                                int newColumn5 = colCnt + 5;
                                foreach (DataRow dr in Dtvalue[y].Rows)
                                {
                                    cntt = cntt + 1;                                    

                                    if (cntt == 1)
                                    {
                                        ws3.Cells[cntt, newColumn1].Value = "Resource Dump_Abacus";
                                        ws3.Cells[cntt, newColumn1].Style.Font.Bold = true;
                                        ws3.Cells[cntt, newColumn1].Style.Font.Size = 10;
                                        ws3.Cells[cntt, newColumn1].Style.Font.Name = "Verdana";
                                        ws3.Cells[cntt, newColumn1].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                        ws3.Cells[cntt, newColumn1].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);

                                        ws3.Cells[cntt, newColumn2].Value = ws2.Name;
                                        ws3.Cells[cntt, newColumn2].Style.Font.Bold = true;
                                        ws3.Cells[cntt, newColumn2].Style.Font.Size = 10;
                                        ws3.Cells[cntt, newColumn2].Style.Font.Name = "Verdana";
                                        ws3.Cells[cntt, newColumn2].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                        ws3.Cells[cntt, newColumn2].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);

                                        ws3.Cells[cntt, newColumn3].Value = "ROV Date";
                                        ws3.Cells[cntt, newColumn3].Style.Font.Bold = true;
                                        ws3.Cells[cntt, newColumn3].Style.Font.Size = 10;
                                        ws3.Cells[cntt, newColumn3].Style.Font.Name = "Verdana";
                                        ws3.Cells[cntt, newColumn3].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                        ws3.Cells[cntt, newColumn3].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);

                                        ws3.Cells[cntt, newColumn4].Value = "ROV Month";
                                        ws3.Cells[cntt, newColumn4].Style.Font.Bold = true;
                                        ws3.Cells[cntt, newColumn4].Style.Font.Size = 10;
                                        ws3.Cells[cntt, newColumn4].Style.Font.Name = "Verdana";
                                        ws3.Cells[cntt, newColumn4].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                        ws3.Cells[cntt, newColumn4].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);

                                        ws3.Cells[cntt, newColumn5].Value = "Personnel No";
                                        ws3.Cells[cntt, newColumn5].Style.Font.Bold = true;
                                        ws3.Cells[cntt, newColumn5].Style.Font.Size = 10;
                                        ws3.Cells[cntt, newColumn5].Style.Font.Name = "Verdana";
                                        ws3.Cells[cntt, newColumn5].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                        ws3.Cells[cntt, newColumn5].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);
                                    }
                                    else
                                    {
                                        ws3.Cells[cntt, newColumn1].Formula = "VLOOKUP(C" + cntt + ",'" + ws.Name + "'!$Q:Q,1,0)";
                                        ws3.Cells[cntt, newColumn2].Formula = "VLOOKUP(C" + cntt + ",'" + ws2.Name + "'!B:Q,16,0)";
                                        ws3.Cells[cntt, newColumn3].Formula = "VLOOKUP(C" + cntt + ",'" + ws2.Name + "'!B:M,12,0)";
                                        ws3.Cells[cntt, newColumn4].Formula = "TEXT(FD" + cntt + ", \"mmm-yy\")";
                                        ws3.Cells[cntt, newColumn5].Formula = "VLOOKUP(C" + cntt + ",'" + ws3.Name + "'!$C:C,1,0)";
                                    }
                                }


                                }
                            #endregion

                            #region ASE Status
                            if (Dtvalue[y].TableName == "ASE Status")
                            {
                                foreach (DataRow dr in Dtvalue[y].Rows)
                                {
                                    count5 = count5 + 1;
                                    int n = 0;

                                    for (int j = 0; j <= 13; j++)
                                    {
                                        n = n + 1;

                                        if (j <= 7)
                                        {
                                            int result6;
                                            var isNumeric = int.TryParse(dr.ItemArray[j].ToString(), out result6);
                                            if (isNumeric == true)
                                            {
                                                ws6.Cells[count5, n].Value = Convert.ToInt32(dr.ItemArray[j]);
                                                ws6.Cells[count5, n].Style.Numberformat.Format = "0";
                                            }
                                            else
                                            {
                                                ws6.Cells[count5, n].Value = dr.ItemArray[j].ToString();
                                            }
                                            if (count5 == 1)
                                            {
                                                ws6.Cells[count5, n].Style.Font.Bold = true;
                                                ws6.Cells[count5, n].Style.Font.Size = 10;
                                                ws6.Cells[count5, n].Style.Font.Name = "Verdana";
                                            }
                                        }

                                        if (j == 8)
                                        {
                                            if (count5 == 1)
                                            {
                                                ws6.Cells[count5, n].Value = "Emp Id";
                                                ws6.Cells[count5, n].Style.Font.Bold = true;
                                                ws6.Cells[count5, n].Style.Font.Size = 10;
                                                ws6.Cells[count5, n].Style.Font.Name = "Verdana";
                                                ws6.Cells[count5, n].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                                ws6.Cells[count5, n].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);
                                            }
                                            else
                                            {
                                                ws6.Cells[count5, n].Formula = "VLOOKUP(B" + count5 + ",'" + ws.Name + "'!Y:EL,118,0)";
                                            }
                                        }

                                        if (j == 9)
                                        {
                                            if (count5 == 1)
                                            {
                                                ws6.Cells[count5, n].Value = "Lock Start Date";
                                                ws6.Cells[count5, n].Style.Font.Bold = true;
                                                ws6.Cells[count5, n].Style.Font.Size = 10;
                                                ws6.Cells[count5, n].Style.Font.Name = "Verdana";
                                                ws6.Cells[count5, n].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                                ws6.Cells[count5, n].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);
                                            }
                                            else
                                            {
                                                ws6.Cells[count5, n].Formula = "VLOOKUP(B" + count5 + ",'" + ws.Name + "'!Y:AE,7,0)";
                                            }
                                        }

                                        if (j == 10)
                                        {
                                            if (count5 == 1)
                                            {
                                                ws6.Cells[count5, n].Value = "Demand";
                                                ws6.Cells[count5, n].Style.Font.Bold = true;
                                                ws6.Cells[count5, n].Style.Font.Size = 10;
                                                ws6.Cells[count5, n].Style.Font.Name = "Verdana";
                                                ws6.Cells[count5, n].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                                ws6.Cells[count5, n].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);
                                            }
                                            else
                                            {
                                                ws6.Cells[count5, n].Formula = "VLOOKUP(B" + count5 + ",'" + ws4.Name + "'!A:D,4,0)";
                                            }
                                        }

                                        if (j == 11)
                                        {
                                            if (count5 == 1)
                                            {
                                                ws6.Cells[count5, n].Value = "PMO Status";
                                                ws6.Cells[count5, n].Style.Font.Bold = true;
                                                ws6.Cells[count5, n].Style.Font.Size = 10;
                                                ws6.Cells[count5, n].Style.Font.Name = "Verdana";
                                                ws6.Cells[count5, n].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                                ws6.Cells[count5, n].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);
                                            }
                                            else
                                            {
                                                ws6.Cells[count5, n].Formula = "IF(I" + count5 + " > 0, \"Fulfilled\" , \"Open Demand\" )";
                                            }
                                        }

                                        if (j == 12)
                                        {
                                            if (count5 == 1)
                                            {
                                                ws6.Cells[count5, n].Value = "Gender";
                                                ws6.Cells[count5, n].Style.Font.Bold = true;
                                                ws6.Cells[count5, n].Style.Font.Size = 10;
                                                ws6.Cells[count5, n].Style.Font.Name = "Verdana";
                                                ws6.Cells[count5, n].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                                ws6.Cells[count5, n].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);
                                            }
                                            else
                                            {
                                                ws6.Cells[count5, n].Formula = "VLOOKUP(B" + count5 + ",'" + ws.Name + "'!Y:CF,60,0)";
                                            }
                                        }
                                    }
                                }
                            }
                            #endregion

                            #region Demand Diversity
                            if (Dtvalue[y].TableName == "Demand-Diversity")
                            {
                                foreach (DataRow dr in Dtvalue[y].Rows)
                                {
                                    count6 = count6 + 1;
                                    int n = 0;

                                    for (int j = 0; j < dr.ItemArray.Count(); j++)
                                    {
                                        n = n + 1;

                                        int result6;
                                        var isNumeric = int.TryParse(dr.ItemArray[j].ToString(), out result6);
                                        if (isNumeric == true)
                                        {
                                            ws7.Cells[count6, n].Value = Convert.ToInt32(dr.ItemArray[j]);
                                            ws7.Cells[count6, n].Style.Numberformat.Format = "0";
                                        }
                                        else
                                        {
                                            ws7.Cells[count6, n].Value = dr.ItemArray[j].ToString();
                                        }
                                    }
                                }
                            }
                            #endregion                            
                        }

                        #region Pivot logic for Base

                        var dataRangeBase = ws3.Cells[ws3.Dimension.Address.ToString()];
                        dataRangeBase.AutoFitColumns();

                        #region Block-1
                        var pivotTableBase = wsPivot.PivotTables.Add(wsPivot.Cells[3, 1], dataRangeBase, "Pivot Base");
                        pivotTableBase.MultipleFieldFilters = true;
                        pivotTableBase.RowGrandTotals = true;
                        pivotTableBase.ColumnGrandTotals = true;
                        pivotTableBase.Compact = true;
                        pivotTableBase.CompactData = true;
                        pivotTableBase.GridDropZones = false;
                        pivotTableBase.Outline = false;
                        pivotTableBase.OutlineData = false;
                        pivotTableBase.ShowError = true;
                        pivotTableBase.ErrorCaption = "[error]";
                        pivotTableBase.ShowHeaders = true;
                        pivotTableBase.UseAutoFormatting = true;
                        pivotTableBase.ApplyWidthHeightFormats = true;
                        pivotTableBase.ShowDrill = true;
                        pivotTableBase.FirstDataCol = 3;
                        pivotTableBase.RowHeaderCaption = "GW Excluded";


                        var NameField = pivotTableBase.Fields["Name"];
                        pivotTableBase.DataFields.Add(NameField);
                        pivotTableBase.DataFields[0].Function = DataFieldFunctions.Count;

                        var careerField = pivotTableBase.Fields["Career Level"];
                        pivotTableBase.ColumnFields.Add(careerField);

                        var DUField = pivotTableBase.Fields["DU"];
                        pivotTableBase.RowFields.Add(DUField);


                        #endregion

                        #region Block-2
                        var pivotTableBase_1 = wsPivot.PivotTables.Add(wsPivot.Cells[3, 16], dataRangeBase, "Pivot Base -1");
                        pivotTableBase_1.MultipleFieldFilters = true;
                        pivotTableBase_1.RowGrandTotals = true;
                        pivotTableBase_1.ColumnGrandTotals = true;
                        pivotTableBase_1.Compact = true;
                        pivotTableBase_1.CompactData = true;
                        pivotTableBase_1.GridDropZones = false;
                        pivotTableBase_1.Outline = false;
                        pivotTableBase_1.OutlineData = false;
                        pivotTableBase_1.ShowError = true;
                        pivotTableBase_1.ErrorCaption = "[error]";
                        pivotTableBase_1.ShowHeaders = true;
                        pivotTableBase_1.UseAutoFormatting = true;
                        pivotTableBase_1.ApplyWidthHeightFormats = true;
                        pivotTableBase_1.ShowDrill = true;
                        pivotTableBase_1.FirstDataCol = 3;

                        var GenderBaseField_1 = pivotTableBase_1.Fields["Gender"];
                        pivotTableBase_1.PageFields.Add(GenderBaseField_1);

                        var ROVField_1 = pivotTableBase_1.Fields[ROV];
                        pivotTableBase_1.PageFields.Add(ROVField_1);

                        var ROVMonthField_1 = pivotTableBase_1.Fields["ROV Month"];
                        pivotTableBase_1.PageFields.Add(ROVMonthField_1);

                        var ResAbacusField_1 = pivotTableBase_1.Fields["Resource Dump_Abacus"];
                        pivotTableBase_1.PageFields.Add(ResAbacusField_1);

                        var NameField_1 = pivotTableBase_1.Fields["Name"];
                        pivotTableBase_1.DataFields.Add(NameField_1);
                        pivotTableBase_1.DataFields[0].Function = DataFieldFunctions.Count;

                        var careerField_1 = pivotTableBase_1.Fields["Career Level"];
                        pivotTableBase_1.ColumnFields.Add(careerField_1);

                        var DUField_1 = pivotTableBase_1.Fields["DU"];
                        pivotTableBase_1.RowFields.Add(DUField_1);
                        #endregion

                        #region Block-3
                        var pivotTableBase_2 = wsPivot.PivotTables.Add(wsPivot.Cells[18, 1], dataRangeBase, "Pivot Base -2");
                        pivotTableBase_2.MultipleFieldFilters = true;
                        pivotTableBase_2.RowGrandTotals = true;
                        pivotTableBase_2.ColumnGrandTotals = true;
                        pivotTableBase_2.Compact = true;
                        pivotTableBase_2.CompactData = true;
                        pivotTableBase_2.GridDropZones = false;
                        pivotTableBase_2.Outline = false;
                        pivotTableBase_2.OutlineData = false;
                        pivotTableBase_2.ShowError = true;
                        pivotTableBase_2.ErrorCaption = "[error]";
                        pivotTableBase_2.ShowHeaders = true;
                        pivotTableBase_2.UseAutoFormatting = true;
                        pivotTableBase_2.ApplyWidthHeightFormats = true;
                        pivotTableBase_2.ShowDrill = true;
                        pivotTableBase_2.FirstDataCol = 3;

                        var GenderBaseField_2 = pivotTableBase_2.Fields["Gender"];
                        pivotTableBase_2.PageFields.Add(GenderBaseField_2);

                        var NameField_2 = pivotTableBase_2.Fields["Name"];
                        pivotTableBase_2.DataFields.Add(NameField_2);
                        pivotTableBase_2.DataFields[0].Function = DataFieldFunctions.Count;

                        var careerField_2 = pivotTableBase_2.Fields["Career Level"];
                        pivotTableBase_2.ColumnFields.Add(careerField_2);

                        var DUField_2 = pivotTableBase_2.Fields["DU"];
                        pivotTableBase_2.RowFields.Add(DUField_2);
                        #endregion

                        #region Block-4
                        var pivotTableBase_3 = wsPivot.PivotTables.Add(wsPivot.Cells[24, 16], dataRangeBase, "Pivot Base -3");
                        pivotTableBase_3.MultipleFieldFilters = true;
                        pivotTableBase_3.RowGrandTotals = true;
                        pivotTableBase_3.ColumnGrandTotals = true;
                        pivotTableBase_3.Compact = true;
                        pivotTableBase_3.CompactData = true;
                        pivotTableBase_3.GridDropZones = false;
                        pivotTableBase_3.Outline = false;
                        pivotTableBase_3.OutlineData = false;
                        pivotTableBase_3.ShowError = true;
                        pivotTableBase_3.ErrorCaption = "[error]";
                        pivotTableBase_3.ShowHeaders = true;
                        pivotTableBase_3.UseAutoFormatting = true;
                        pivotTableBase_3.ApplyWidthHeightFormats = true;
                        pivotTableBase_3.ShowDrill = true;
                        pivotTableBase_3.FirstDataCol = 3;

                        var GenderBaseField_3 = pivotTableBase_3.Fields["Gender"];
                        pivotTableBase_3.PageFields.Add(GenderBaseField_3);

                        var ROVField_3 = pivotTableBase_3.Fields[ROV];
                        pivotTableBase_3.PageFields.Add(ROVField_3);

                        var ROVMonthField_3 = pivotTableBase_3.Fields["ROV Month"];
                        pivotTableBase_3.PageFields.Add(ROVMonthField_3);

                        var ResAbacusField_3 = pivotTableBase_3.Fields["Resource Dump_Abacus"];
                        pivotTableBase_3.PageFields.Add(ResAbacusField_3);

                        var NameField_3 = pivotTableBase_3.Fields["Name"];
                        pivotTableBase_3.DataFields.Add(NameField_3);
                        pivotTableBase_3.DataFields[0].Function = DataFieldFunctions.Count;

                        var careerField_3 = pivotTableBase_3.Fields["Career Level"];
                        pivotTableBase_3.ColumnFields.Add(careerField_3);

                        var DUField_3 = pivotTableBase_3.Fields["DU"];
                        pivotTableBase_3.RowFields.Add(DUField_3);


                        #endregion


                        #endregion

                        #region Pivot logic for Resource Dump

                        var dataRangeResourcedump = ws.Cells[ws.Dimension.Address.ToString()];
                        dataRangeResourcedump.AutoFitColumns();


                        #region Block-1
                        var pivotTableResource = wsPivot1.PivotTables.Add(wsPivot1.Cells[3, 1], dataRangeResourcedump, "Abacus Pivot");
                        pivotTableResource.MultipleFieldFilters = true;
                        pivotTableResource.RowGrandTotals = true;
                        pivotTableResource.ColumnGrandTotals = true;
                        pivotTableResource.Compact = true;
                        pivotTableResource.CompactData = true;
                        pivotTableResource.GridDropZones = false;
                        pivotTableResource.Outline = false;
                        pivotTableResource.OutlineData = false;
                        pivotTableResource.ShowError = true;
                        pivotTableResource.ErrorCaption = "[error]";
                        pivotTableResource.ShowHeaders = true;
                        pivotTableResource.UseAutoFormatting = true;
                        pivotTableResource.ApplyWidthHeightFormats = true;
                        pivotTableResource.ShowDrill = true;
                        pivotTableResource.FirstDataCol = 3;

                        var LOCField = pivotTableResource.Fields["Lock Start Month"];
                        pivotTableResource.PageFields.Add(LOCField);

                        var BasedtField = pivotTableResource.Fields["Base Data"];
                        pivotTableResource.PageFields.Add(BasedtField);

                        var CRField = pivotTableResource.Fields["Career Level"];
                        pivotTableResource.DataFields.Add(CRField);
                        pivotTableResource.DataFields[0].Function = DataFieldFunctions.Count;

                        var CRField1 = pivotTableResource.Fields["Career Level"];
                        pivotTableResource.ColumnFields.Add(CRField1);

                        var DUFieldRES = pivotTableResource.Fields["DU"];
                        pivotTableResource.RowFields.Add(DUFieldRES);

                        #endregion

                        #region Block-2
                        var pivotTableResource_1 = wsPivot1.PivotTables.Add(wsPivot1.Cells[3, 12], dataRangeResourcedump, "Abacus Pivot-1");
                        pivotTableResource_1.MultipleFieldFilters = true;
                        pivotTableResource_1.RowGrandTotals = true;
                        pivotTableResource_1.ColumnGrandTotals = true;
                        pivotTableResource_1.Compact = true;
                        pivotTableResource_1.CompactData = true;
                        pivotTableResource_1.GridDropZones = false;
                        pivotTableResource_1.Outline = false;
                        pivotTableResource_1.OutlineData = false;
                        pivotTableResource_1.ShowError = true;
                        pivotTableResource_1.ErrorCaption = "[error]";
                        pivotTableResource_1.ShowHeaders = true;
                        pivotTableResource_1.UseAutoFormatting = true;
                        pivotTableResource_1.ApplyWidthHeightFormats = true;
                        pivotTableResource_1.ShowDrill = true;
                        pivotTableResource_1.FirstDataCol = 3;

                        var BasedtField_1 = pivotTableResource_1.Fields["Base Data"];
                        pivotTableResource_1.PageFields.Add(BasedtField_1);

                        var StatustField_1 = pivotTableResource_1.Fields["Status"];
                        pivotTableResource_1.PageFields.Add(StatustField_1);

                        var JoindateField_1 = pivotTableResource_1.Fields["Join Date"];
                        pivotTableResource_1.PageFields.Add(JoindateField_1);

                        var GenderField_1 = pivotTableResource_1.Fields["Gender"];
                        pivotTableResource_1.PageFields.Add(GenderField_1);

                        var CRField_1 = pivotTableResource_1.Fields["Career Level"];
                        pivotTableResource_1.DataFields.Add(CRField_1);
                        pivotTableResource_1.DataFields[0].Function = DataFieldFunctions.Count;

                        var CRField_2 = pivotTableResource_1.Fields["Career Level"];
                        pivotTableResource_1.ColumnFields.Add(CRField_2);

                        var DUFieldRES_1 = pivotTableResource_1.Fields["DU"];
                        pivotTableResource_1.RowFields.Add(DUFieldRES_1);

                        #endregion

                        #region Block-3
                        var pivotTableResource_2 = wsPivot1.PivotTables.Add(wsPivot1.Cells[18, 1], dataRangeResourcedump, "Abacus Pivot -2");
                        pivotTableResource_2.MultipleFieldFilters = true;
                        pivotTableResource_2.RowGrandTotals = true;
                        pivotTableResource_2.ColumnGrandTotals = true;
                        pivotTableResource_2.Compact = true;
                        pivotTableResource_2.CompactData = true;
                        pivotTableResource_2.GridDropZones = false;
                        pivotTableResource_2.Outline = false;
                        pivotTableResource_2.OutlineData = false;
                        pivotTableResource_2.ShowError = true;
                        pivotTableResource_2.ErrorCaption = "[error]";
                        pivotTableResource_2.ShowHeaders = true;
                        pivotTableResource_2.UseAutoFormatting = true;
                        pivotTableResource_2.ApplyWidthHeightFormats = true;
                        pivotTableResource_2.ShowDrill = true;
                        pivotTableResource_2.FirstDataCol = 3;

                        var RSLOCField2 = pivotTableResource_2.Fields["Lock Start Month"];
                        pivotTableResource_2.PageFields.Add(RSLOCField2);

                        var RSBasedtField2 = pivotTableResource_2.Fields["Base Data"];
                        pivotTableResource_2.PageFields.Add(RSBasedtField2);

                        var RSGenderField2 = pivotTableResource_2.Fields["Gender"];
                        pivotTableResource_2.PageFields.Add(RSGenderField2);

                        var CRField22 = pivotTableResource_2.Fields["Career Level"];
                        pivotTableResource_2.DataFields.Add(CRField22);
                        pivotTableResource_2.DataFields[0].Function = DataFieldFunctions.Count;

                        var CRField12 = pivotTableResource_2.Fields["Career Level"];
                        pivotTableResource_2.ColumnFields.Add(CRField12);

                        var DUFieldRES2 = pivotTableResource_2.Fields["DU"];
                        pivotTableResource_2.RowFields.Add(DUFieldRES2);

                        #endregion

                        #region Block-4
                        var pivotTableResource_3 = wsPivot1.PivotTables.Add(wsPivot1.Cells[24, 12], dataRangeResourcedump, "Abacus Pivot-3");
                        pivotTableResource_3.MultipleFieldFilters = true;
                        pivotTableResource_3.RowGrandTotals = true;
                        pivotTableResource_3.ColumnGrandTotals = true;
                        pivotTableResource_3.Compact = true;
                        pivotTableResource_3.CompactData = true;
                        pivotTableResource_3.GridDropZones = false;
                        pivotTableResource_3.Outline = false;
                        pivotTableResource_3.OutlineData = false;
                        pivotTableResource_3.ShowError = true;
                        pivotTableResource_3.ErrorCaption = "[error]";
                        pivotTableResource_3.ShowHeaders = true;
                        pivotTableResource_3.UseAutoFormatting = true;
                        pivotTableResource_3.ApplyWidthHeightFormats = true;
                        pivotTableResource_3.ShowDrill = true;
                        pivotTableResource_3.FirstDataCol = 3;

                        var BasedtField_31 = pivotTableResource_3.Fields["Base Data"];
                        pivotTableResource_3.PageFields.Add(BasedtField_31);

                        var StatustField_31 = pivotTableResource_3.Fields["Status"];
                        pivotTableResource_3.PageFields.Add(StatustField_31);

                        var JoindateField_31 = pivotTableResource_3.Fields["Join Date"];
                        pivotTableResource_3.PageFields.Add(JoindateField_31);

                        var GenderField_31 = pivotTableResource_3.Fields["Gender"];
                        pivotTableResource_3.PageFields.Add(GenderField_31);

                        var CRField_31 = pivotTableResource_3.Fields["Career Level"];
                        pivotTableResource_3.DataFields.Add(CRField_31);
                        pivotTableResource_3.DataFields[0].Function = DataFieldFunctions.Count;

                        var CRField_32 = pivotTableResource_3.Fields["Career Level"];
                        pivotTableResource_3.ColumnFields.Add(CRField_32);

                        var DUFieldRES_31 = pivotTableResource_3.Fields["DU"];
                        pivotTableResource_3.RowFields.Add(DUFieldRES_31);

                        #endregion


                        #endregion

                        excel.SaveAs(finame);
                    }


                    using (var pck = new ExcelPackage(finame))
                    {
                        string ab = string.Empty;
                        string bc = string.Empty;
                        string demand = string.Empty;
                        string empid = string.Empty;

                        var worksheet = pck.Workbook.Worksheets[1];
                        var worksheet2 = pck.Workbook.Worksheets[6];
                        var worksheet3 = pck.Workbook.Worksheets[4];
                        var worksheet5 = pck.Workbook.Worksheets[5];

                        int colCount = worksheet.Dimension.End.Column;
                        int rowCount = worksheet.Dimension.End.Row;

                        int colCount2 = worksheet2.Dimension.End.Column;
                        int rowCount2 = worksheet2.Dimension.End.Row;

                        int colCount3 = worksheet3.Dimension.End.Column;
                        int rowCount3 = worksheet3.Dimension.End.Row;

                        int colCount5 = worksheet5.Dimension.End.Column;
                        int rowCount5 = worksheet5.Dimension.End.Row;

                        for (int row = 1; row <= rowCount; row++)
                        {
                            if (row != 1)
                            {
                                for (int col = 1; col <= colCount; col++)
                                {
                                    if (col == 143)
                                    {
                                        worksheet.Cells[row, col].Calculate();

                                        if (worksheet.Cells[row, col].Value != null)
                                            ab = worksheet.Cells[row, col].Value.ToString().Trim();

                                        if (ab == "Onboard" && (bc == null || bc == string.Empty || bc == "#N/A"))
                                        {
                                            worksheet.Cells[row, 141].Value = "New Joinee";
                                        }
                                    }

                                    if (col == 141)
                                    {
                                        worksheet.Cells[row, col].Calculate();

                                        if (worksheet.Cells[row, col].Value != null)
                                            bc = worksheet.Cells[row, col].Value.ToString().Trim();
                                    }
                                }
                            }
                        }

                        for (int row = 1; row <= rowCount2; row++)
                        {
                            if (row != 1)
                            {
                                for (int col = 1; col <= colCount2; col++)
                                {
                                    if (col == 11)
                                    {
                                        worksheet2.Cells[row, col].Calculate();

                                        if (worksheet2.Cells[row, col].Value != null)
                                            demand = worksheet2.Cells[row, col].Value.ToString().Trim();

                                        if (demand.ToUpper() == "YES")
                                        {
                                            worksheet2.Cells[row, 12].Value = "Open demand";
                                        }
                                        if (demand == "#N/A" && empid == "#N/A")
                                        {
                                            worksheet2.Cells[row, 12].Value = "FHL";
                                        }
                                    }
                                    if (col == 9)
                                    {
                                        worksheet2.Cells[row, col].Calculate();

                                        if (worksheet2.Cells[row, col].Value != null)
                                            empid = worksheet2.Cells[row, col].Value.ToString().Trim();
                                    }
                                }
                            }
                        }

                        int cnt = 1;
                        for (int row = 1; row <= rowCount3; row++)
                        {
                            if (row != 1)
                            {
                                for (int col = 1; col <= colCount3; col++)
                                {
                                    if (col == 2)
                                    {
                                        cnt = cnt + 1;
                                        worksheet3.Cells[row, col].Formula = "VLOOKUP(A" + cnt + ",'Demand-Diversity'!A:A,1,0)";
                                    }
                                }
                            }
                        }

                        int cnt5 = 1;
                        for (int row = 1; row <= rowCount5; row++)
                        {
                            if (row != 1)
                            {
                                for (int col = 1; col <= colCount5; col++)
                                {
                                    if (col == 2)
                                    {
                                        cnt5 = cnt5 + 1;
                                        worksheet5.Cells[row, col].Formula = "VLOOKUP(A" + cnt5 + ",'Demand-Diversity'!A:A,1,0)";
                                    }
                                }
                            }
                        }

                        pck.Workbook.Worksheets[4].Calculate();
                        pck.Workbook.Worksheets[5].Calculate();

                        pck.Save();
                    }

                   
                    using (var pckval = new ExcelPackage(finame))
                    {
                        //int count = 0;
                        var pckDemand = pckval.Workbook.Worksheets[9];
                        //var ASE = pckval.Workbook.Worksheets["ASE Status"];
                        //ASE.Calculate();
                        //var b = ASE.Cells[2, 12].Text;

                        #region filter abacus

                        DataSet ds1 = new DataSet();
                        DataTableCollection dt1 = ds1.Tables;
                        DataTableCollection dtt2 = ds1.Tables;

                        var con1 = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + finame + " ;" +
                            @"Extended Properties='Excel 12.0;HDR=NO;IMEX=1'";

                        using (OleDbConnection connection = new OleDbConnection(con1))
                        {
                            connection.Open();
                            OleDbCommand commandAD = connection.CreateCommand();
                            commandAD.CommandType = CommandType.Text;
                            string tableName = String.Format("[{0}$]", AbacusWorksheet);
                            commandAD.CommandText = String.Format("SELECT F1, F4, F8, F9, F30, F44, F46, F51 FROM {0} where F4 = 'Yes' and F2='#N/A'", tableName);

                            OleDbCommand commandAD1 = connection.CreateCommand();
                            commandAD1.CommandType = CommandType.Text;
                            string tableName1 = String.Format("[{0}$]", FHLWorksheet);
                            commandAD1.CommandText = String.Format("SELECT F1, F4, F8, F9, F30, F44, F46, F51 FROM {0} where F2='#N/A'", tableName1);


                            OleDbDataAdapter myDataAdaptorAD = new OleDbDataAdapter(commandAD);
                            myDataAdaptorAD.Fill(ds1, "Temp Abacus Demand Dump");
                            dt1 = ds1.Tables;

                            OleDbDataAdapter myDataAdaptorAD1 = new OleDbDataAdapter(commandAD1);
                            myDataAdaptorAD1.Fill(ds1, "Temp FHL Demand Dump");
                            dtt2 = ds1.Tables;

                            //Total rows
                            string dataReader = "SELECT count(*) from [Demand-Diversity$]";
                            OleDbCommand command_reader = new OleDbCommand(dataReader, connection);
                            result = (int)command_reader.ExecuteScalar();
                        }

                        #endregion

                        #region write demand-diversity
                        //Writing to demand-diversity from Abacus demand dump
                        int countRow = result;

                        foreach (DataRow dr in dt1[0].Rows)
                        {
                            countRow = countRow + 1;
                            int c = 0;
                            for (int j = 0; j < dr.ItemArray.Count(); j++)
                            {
                                int result6;
                                c = c + 1;
                                var isNumeric = int.TryParse(dr.ItemArray[j].ToString(), out result6);
                                if (isNumeric == true)
                                {
                                    pckDemand.Cells[countRow, c].Value = Convert.ToInt32(dr.ItemArray[j]);
                                    pckDemand.Cells[countRow, c].Style.Numberformat.Format = "0";
                                }
                                else
                                {
                                    pckDemand.Cells[countRow, c].Value = dr.ItemArray[j].ToString();
                                }
                            }
                        }

                        foreach (DataRow dr in dt1[1].Rows)
                        {
                            countRow = countRow + 1;
                            int c = 0;
                            for (int j = 0; j < dr.ItemArray.Count(); j++)
                            {
                                int result6;
                                c = c + 1;
                                var isNumeric = int.TryParse(dr.ItemArray[j].ToString(), out result6);
                                if (isNumeric == true)
                                {
                                    pckDemand.Cells[countRow, c].Value = Convert.ToInt32(dr.ItemArray[j]);
                                    pckDemand.Cells[countRow, c].Style.Numberformat.Format = "0";
                                }
                                else
                                {
                                    pckDemand.Cells[countRow, c].Value = dr.ItemArray[j].ToString();
                                }
                            }
                        }
                        #endregion

                        pckval.Save();

                        var dt2 = RemoveDuplicates(finame);

                        pckval.Workbook.Worksheets.Add("Demand-Diversity-Final");
                        var w10 = pckval.Workbook.Worksheets[10];

                        int countRow1 = 1;

                        var columns = dt2.Columns.Count;
                        int occurrence = 1;
                        foreach(DataColumn dc in dt2.Columns)
                        {
                            w10.Cells[1, occurrence].Value = dc.ColumnName;
                            occurrence = occurrence + 1;
                        }

                        w10.Cells[1, 10].Value = "RRD in Demand Base";
                        w10.Cells[1, 11].Value = "RRD in res Base";
                        w10.Cells[1, 12].Value = "Res Lock start date";
                        w10.Cells[1, 13].Value = "Lock start month";
                        w10.Cells[1, 14].Value = "Gender";
                        w10.Cells[1, 15].Value = "Status";
                        w10.Cells[1, 16].Value = "Res EMP ID";
                        w10.Cells[1, 17].Value = "Res EMP ID - Base sheet";
                        w10.Cells[1, 18].Value = "SE Refresh";
                        w10.Cells[1, 19].Value = "RRD in FHL dump";
                        w10.Cells[1, 20].Value = "PMO Comments";

                        foreach (DataRow dr in dt2.Rows)
                        {
                            countRow1 = countRow1 + 1;
                            int c = 0;
                            int columnNumber = 1;
                            for (int j = 0; j < 20; j++)
                            {
                                if (j < 9)
                                {
                                    int result6;
                                    c = c + 1;
                                    
                                    var isNumeric = int.TryParse(dr.ItemArray[j].ToString(), out result6);
                                    if (isNumeric == true)
                                    {
                                        w10.Cells[countRow1, c].Value = Convert.ToInt32(dr.ItemArray[j]);
                                        w10.Cells[countRow1, c].Style.Numberformat.Format = "0";
                                    }
                                    else
                                    {
                                        w10.Cells[countRow1, c].Value = dr.ItemArray[j].ToString();
                                    }
                                    columnNumber = columnNumber + 1;
                                }


                                if (j == 9) // RRD in Demand Base
                                {
                                    w10.Cells[countRow1, 10].Formula = "VLOOKUP(A" + countRow1 + ",'" + AbacusWorksheet + "'!$A:D,4,0)";
                                    w10.Cells[countRow1, 10].Calculate();                                    
                                }
                                if (j == 10) //RRD in res Base
                                {
                                    w10.Cells[countRow1, 11].Formula = "VLOOKUP(A" + countRow1 + ",'" + ResourceDump + "'!$Y:Y,1,0)";
                                    w10.Cells[countRow1, 11].Calculate();
                                }
                                if (j == 11) //Res Lock start date
                                {
                                    w10.Cells[countRow1, 12].Formula = "VLOOKUP(A" + countRow1 + ",'" + ResourceDump + "'!$Y:AI,11,0)";
                                    w10.Cells[countRow1, 12].Calculate();
                                }
                                if (j == 12) //Lock start month - issue
                                {
                                    w10.Cells[countRow1, 13].Formula = "TEXT(L" + countRow1 + ", \"mmm-yy\")";
                                    w10.Cells[countRow1, 13].Calculate();
                                }
                                if (j == 13) //Gender
                                {
                                    w10.Cells[countRow1, 14].Formula = "VLOOKUP(A" + countRow1 + ",'" + ResourceDump + "'!$Y:CF,60,0)";
                                    w10.Cells[countRow1, 14].Calculate();
                                }
                                if (j == 14) //Status
                                {
                                    w10.Cells[countRow1, 15].Formula = "VLOOKUP(A" + countRow1 + ",'" + ResourceDump + "'!$Y:EM,119,0)";
                                    w10.Cells[countRow1, 15].Calculate();
                                }
                                if (j == 15) //Res EMP ID
                                {
                                    w10.Cells[countRow1, 16].Formula = "VLOOKUP(A" + countRow1 + ",'" + ResourceDump + "'!$Y:EL,118,0)";
                                    w10.Cells[countRow1, 16].Calculate();
                                }
                                if (j == 16) //Res EMP ID - Base sheet
                                {
                                    w10.Cells[countRow1, 17].Formula = "VLOOKUP(A" + countRow1 + ",'Base'!$K:K,1,0)";
                                    w10.Cells[countRow1, 17].Calculate();
                                }
                                //if (j == 17) //SE Refresh
                                //{
                                //    //Not required
                                //}
                                if (j == 18) //RRD in FHL dump
                                {
                                    w10.Cells[countRow1, 19].Formula = "VLOOKUP(A" + countRow1 + ",'" + FHLWorksheet + "'!$A:A,1,0)";
                                    w10.Cells[countRow1, 19].Calculate();
                                }
                                if(j == 19) //PMO Comments
                                {
                                    if(w10.Cells[countRow1, 6].Text == "Internal Organizational Movement")
                                    {
                                        w10.Cells[countRow1, 20].Value = "IOM";
                                        break;
                                    }
                                    if (w10.Cells[countRow1, 19].Text != "#N/A")
                                    {
                                        if(w10.Cells[countRow1, 5].Text == "Client Onsite - Out of India")
                                        {
                                            w10.Cells[countRow1, 20].Value = "GCP-FHL";
                                        }
                                        else
                                        {
                                            w10.Cells[countRow1, 20].Value = "FHL";
                                        }                                        
                                    }
                                    if (w10.Cells[countRow1, 10].Text == "Yes")
                                    {
                                        w10.Cells[countRow1, 20].Value = "Open Demand";
                                    }
                                    if (w10.Cells[countRow1, 11].Text != "#N/A")
                                    {
                                        w10.Cells[countRow1, 20].Value = "Fulfilled Joiner";
                                    }
                                }
                            }                            
                        }

                        pckval.Save();

                        int rowCount = w10.Dimension.End.Row;
                        int colCount = w10.Dimension.End.Column;
                        

                        List<int> rowsToBeDeleted = new List<int> { };
                        for (int row = 1; row <= rowCount; row++)
                        {
                            string ab = "";
                            string cd = "";
                            string res = "";
                            string cell12 = "";
                            string cell14 = "";
                            string cell16 = "";
                            string cell17 = "";
                            string cell19 = "";
                            object cell20 = null;

                            if (row != 1)
                            {
                                for (int col = 1; col <= colCount; col++)
                                {
                                    if(col == 10)
                                    {
                                        w10.Cells[row, col].Calculate();
                                        if (w10.Cells[row, col].Value != null)
                                        {
                                            res = w10.Cells[row, col].Value.ToString().Trim().ToLower();
                                            if (res == "no")
                                            {
                                                rowsToBeDeleted.Add(row);
                                                break;
                                            }
                                        }
                                            
                                    }
                                    if (col == 11)
                                    {
                                        w10.Cells[row, col].Calculate();

                                        if (w10.Cells[row, col].Value != null)
                                            ab = w10.Cells[row, col].Value.ToString().Trim().ToLower();

                                        //// TODO Column O = Onboard
                                        //if (ab != "#N/A")
                                        //{
                                        //    rowsToBeDeleted.Add(row);
                                        //    //w10.DeleteRow(row, 1, true);
                                        //    //break;
                                        //}
                                        //break;
                                    }

                                    if(col == 15)
                                    {
                                        w10.Cells[row, col].Calculate();

                                        if (w10.Cells[row, col].Value != null)
                                            cd = w10.Cells[row, col].Value.ToString().Trim().ToLower();

                                        if (ab != "#n/a" & cd == "onboard")
                                        {
                                            rowsToBeDeleted.Add(row);
                                            break;
                                        }
                                        
                                    }

                                    if(col == 12)
                                    {
                                        w10.Cells[row, col].Calculate();

                                        if (w10.Cells[row, col].Value != null)
                                            cell12 = w10.Cells[row, col].Value.ToString().Trim().ToLower();
                                    }
                                    //if (col == 13)
                                    //{
                                    //    w10.Cells[row, col].Calculate();

                                    //    if (w10.Cells[row, col].Value != null)
                                    //        cell13 = w10.Cells[row, col].Value.ToString().Trim().ToLower();
                                    //}
                                    if (col == 14)
                                    {
                                        w10.Cells[row, col].Calculate();

                                        if (w10.Cells[row, col].Value != null)
                                            cell14 = w10.Cells[row, col].Value.ToString().Trim().ToLower();
                                    }
                                    if (col == 16)
                                    {
                                        w10.Cells[row, col].Calculate();

                                        if (w10.Cells[row, col].Value != null)
                                            cell16 = w10.Cells[row, col].Value.ToString().Trim().ToLower();
                                    }
                                    if (col == 17)
                                    {
                                        w10.Cells[row, col].Calculate();

                                        if (w10.Cells[row, col].Value != null)
                                            cell17 = w10.Cells[row, col].Value.ToString().Trim().ToLower();
                                    }
                                    if (col == 19)
                                    {
                                        w10.Cells[row, col].Calculate();

                                        if (w10.Cells[row, col].Value != null)
                                            cell19 = w10.Cells[row, col].Value.ToString().Trim().ToLower();
                                    }
                                    if (col == 20)
                                    {
                                        w10.Cells[row, col].Calculate();

                                        cell20 = w10.Cells[row, col].Value;
                                    }

                                    if(cell20 == null & res == "#n/a" && ab == "#n/a" && cell12 == "#n/a" & cell14 == "#n/a" & cd == "#n/a" && cell16 == "#n/a" && cell17 == "#n/a" && cell19 == "#n/a")
                                    {
                                        rowsToBeDeleted.Add(row);
                                        break;
                                    }
                                }                                
                            }
                        }
                        int deletionOccurrence = 0;
                        int newValue;
                        foreach (var rowToBeDeleted in rowsToBeDeleted)
                        {
                            newValue = rowToBeDeleted - deletionOccurrence;
                            w10.DeleteRow(newValue, 1, true);
                            deletionOccurrence++;
                        }

                        pckval.Workbook.Worksheets["ASE Status"].Calculate();
                        pckval.Workbook.Worksheets["Base"].Calculate();
                        pckval.Save();

                        using (OleDbConnection connection = new OleDbConnection(con1))
                        {
                            connection.Open();

                            //Total ASEs
                            string ASEDataReader = "SELECT count(*) from [ASE Status$]";
                            OleDbCommand ASECommandReader = new OleDbCommand(ASEDataReader, connection);
                            totalASECount = (int)ASECommandReader.ExecuteScalar();

                            //Total RHYL
                            string RHYLASEDataReader = "SELECT count(*) from [ASE Status$] where F12 = 'Open demand'";
                            OleDbCommand RHYLASECommandReader = new OleDbCommand(RHYLASEDataReader, connection);
                            totalRHYLCount = (int)RHYLASECommandReader.ExecuteScalar();

                            //Total FulfilledASEs
                            string fulfilledASEDataReader = "SELECT count(*) from [ASE Status$] where F12 = 'Fulfilled' or F12 = 'FHL'"; //OR F12 = 'FHL'
                            OleDbCommand fulfilledASECommandReader = new OleDbCommand(fulfilledASEDataReader, connection);
                            totalFulfilledASECount = (int)fulfilledASECommandReader.ExecuteScalar();
                            
                            //Total FemaleFulfilledASEs
                            string femaleFulfilledASEDataReader = "SELECT count(*) from [ASE Status$] where (F12 = 'Fulfilled' or F12 = 'FHL') and F13 = 'F'";
                            OleDbCommand femaleFulfilledASECommandReader = new OleDbCommand(femaleFulfilledASEDataReader, connection);
                            totalFulfilledFemaleASECount = (int)femaleFulfilledASECommandReader.ExecuteScalar();

                            string dataReader = "SELECT count(*) from [Demand-Diversity-Final$] where F20 = 'Open Demand'";
                            OleDbCommand command_reader = new OleDbCommand(dataReader, connection);
                            openDemandCount = (int)command_reader.ExecuteScalar();

                            string dataReader1 = "SELECT count(*) from [Demand-Diversity-Final$] where F20 = 'FHL'";
                            OleDbCommand command1 = new OleDbCommand(dataReader1, connection);
                            totalLockCount = (int)command1.ExecuteScalar();

                            string dataReader2 = "SELECT count(*) from [Demand-Diversity-Final$] where F20 = 'FHL' and F14 = 'F'";
                            OleDbCommand command2 = new OleDbCommand(dataReader2, connection);
                            totalFemaleLockCount = (int)command2.ExecuteScalar();

                            string dataReader3 = "SELECT count(*) from [Demand-Diversity-Final$] where F20 = 'Fulfilled Joiner'";
                            OleDbCommand command3 = new OleDbCommand(dataReader3, connection);
                            totalJoinersCount = (int)command3.ExecuteScalar();

                            string dataReader4 = "SELECT count(*) from [Demand-Diversity-Final$] where F20 = 'Fulfilled Joiner' and F14 = 'F'";
                            OleDbCommand command4 = new OleDbCommand(dataReader4, connection);
                            totalFemaleJoinersCount = (int)command4.ExecuteScalar();                            
                        }

                        w10.Cells[2, 22].Value = "Data as on 6th Aug 2019";
                        w10.Cells[3, 22].Value = "Open Demands";
                        w10.Cells[3, 23].Value = openDemandCount;
                        w10.Cells[4, 22].Value = "Total Locks";
                        w10.Cells[4, 23].Value = totalLockCount;
                        w10.Cells[5, 22].Value = "Female Locks";
                        w10.Cells[5, 23].Value = totalFemaleLockCount;
                        w10.Cells[6, 22].Value = "Total Joiners Fulfilled";
                        w10.Cells[6, 23].Value = totalJoinersCount;
                        w10.Cells[7, 22].Value = "Female Joiners";
                        w10.Cells[7, 23].Value = totalFemaleJoinersCount;
                        w10.Cells[8, 22].Value = "SE Refresh ";
                        w10.Cells[9, 22].Value = "Total Female Joiners";

                        w10.Cells[9, 23].Formula = "=SUM(W5+W7+W8)";

                        w10.Cells[12, 22].Value = "Q4 ASE status as on 6th Aug 2019";
                        w10.Cells[13, 22].Value = "Total ASE committed Q4";
                        w10.Cells[13, 23].Value = totalASECount - 1;
                        w10.Cells[14, 22].Value = "Total RHYL";
                        w10.Cells[14, 23].Value = totalRHYLCount;
                        w10.Cells[15, 22].Value = "Total Locked (M + F)";
                        w10.Cells[15, 23].Value = totalFulfilledASECount;
                        w10.Cells[16, 22].Value = "Total Female Locked"; ;
                        w10.Cells[16, 23].Value = totalFulfilledFemaleASECount;

                        w10.Cells[18, 22].Value = "Total Locks";
                        w10.Cells[18, 23].Formula = "=SUM(W4+W6+W8)";
                        w10.Cells[19, 22].Value = "Total Female Locks";
                        w10.Cells[19, 23].Formula = "=SUM(W5+W7+W8)";

                        //Delete temp worksheet Demand Diversity
                        var worksheet = pckval.Workbook.Worksheets.SingleOrDefault(x => x.Name == "Demand-Diversity");
                        pckval.Workbook.Worksheets.Delete(worksheet);

                        


                        //var ws8 = pckval.Workbook.Worksheets.Add("Details");

                        string startupPathDetails = System.AppDomain.CurrentDomain.BaseDirectory + "Template.xlsx";
                        var detailsFile = new FileInfo(startupPathDetails);

                        var package2 = new ExcelPackage(detailsFile);
                        ExcelWorkbook workBook2 = package2.Workbook;
                        ExcelWorksheet workSheet2 = workBook2.Worksheets["Summary"];
                        ExcelWorksheet workSheet3 = workBook2.Worksheets["Details"];

                        pckval.Workbook.Worksheets.Add("Summary", workSheet2);
                        pckval.Workbook.Worksheets.Add("Details", workSheet3);

                        pckval.Workbook.Worksheets.MoveToStart("Summary");
                        pckval.Workbook.Worksheets.MoveAfter("Details", "Summary");

                        pckval.Workbook.Worksheets["Demand-Diversity-Final"].Name = "Demand-Diversity";

                        #region Pivot table for Demand Diversity

                        var dataRangeDemand = pckval.Workbook.Worksheets[11].Cells["A1:T303"];
                        dataRangeDemand.AutoFitColumns();

                        ExcelWorksheet DDPivot = pckval.Workbook.Worksheets[11];

                        #region Block-1
                        var pivotTableDeamad_1 = DDPivot.PivotTables.Add(DDPivot.Cells[25, 22], dataRangeDemand, "Demand Diversity -1");
                        pivotTableDeamad_1.MultipleFieldFilters = true;
                        pivotTableDeamad_1.RowGrandTotals = true;
                        pivotTableDeamad_1.ColumnGrandTotals = true;
                        pivotTableDeamad_1.Compact = true;
                        pivotTableDeamad_1.CompactData = true;
                        pivotTableDeamad_1.GridDropZones = false;
                        pivotTableDeamad_1.Outline = false;
                        pivotTableDeamad_1.OutlineData = false;
                        pivotTableDeamad_1.ShowError = true;
                        pivotTableDeamad_1.ErrorCaption = "[error]";
                        pivotTableDeamad_1.ShowHeaders = true;
                        pivotTableDeamad_1.UseAutoFormatting = true;
                        pivotTableDeamad_1.ApplyWidthHeightFormats = true;
                        pivotTableDeamad_1.ShowDrill = true;
                        pivotTableDeamad_1.FirstDataCol = 3;

                        var GenderField_1 = pivotTableDeamad_1.Fields["Gender"];
                        pivotTableDeamad_1.PageFields.Add(GenderField_1);

                        var PMOField_1 = pivotTableDeamad_1.Fields["PMO Comments"];
                        pivotTableDeamad_1.PageFields.Add(PMOField_1);

                        var LockField_1 = pivotTableDeamad_1.Fields["Lock start month"];
                        pivotTableDeamad_1.PageFields.Add(LockField_1);

                        var RRDField_1 = pivotTableDeamad_1.Fields["RRD No"];
                        pivotTableDeamad_1.DataFields.Add(RRDField_1);
                        pivotTableDeamad_1.DataFields[0].Function = DataFieldFunctions.Count;

                        var careerField_1 = pivotTableDeamad_1.Fields["Career Level"];
                        pivotTableDeamad_1.ColumnFields.Add(careerField_1);

                        var DUField_1 = pivotTableDeamad_1.Fields["DU"];
                        pivotTableDeamad_1.RowFields.Add(DUField_1);

                        #endregion

                        #region Block-2

                        var pivotTableDeamad_2 = DDPivot.PivotTables.Add(DDPivot.Cells[42, 22], dataRangeDemand, "Demand Diversity -2");
                        pivotTableDeamad_2.MultipleFieldFilters = true;
                        pivotTableDeamad_2.RowGrandTotals = true;
                        pivotTableDeamad_2.ColumnGrandTotals = true;
                        pivotTableDeamad_2.Compact = true;
                        pivotTableDeamad_2.CompactData = true;
                        pivotTableDeamad_2.GridDropZones = false;
                        pivotTableDeamad_2.Outline = false;
                        pivotTableDeamad_2.OutlineData = false;
                        pivotTableDeamad_2.ShowError = true;
                        pivotTableDeamad_2.ErrorCaption = "[error]";
                        pivotTableDeamad_2.ShowHeaders = true;
                        pivotTableDeamad_2.UseAutoFormatting = true;
                        pivotTableDeamad_2.ApplyWidthHeightFormats = true;
                        pivotTableDeamad_2.ShowDrill = true;
                        pivotTableDeamad_2.FirstDataCol = 3;

                        var GenderField_2 = pivotTableDeamad_2.Fields["Gender"];
                        pivotTableDeamad_2.PageFields.Add(GenderField_2);

                        var LockField_2 = pivotTableDeamad_2.Fields["Lock start month"];
                        pivotTableDeamad_2.PageFields.Add(LockField_2);


                        var PMOField_2 = pivotTableDeamad_2.Fields["PMO Comments"];
                        pivotTableDeamad_2.PageFields.Add(PMOField_2);


                        var RRDField_2 = pivotTableDeamad_2.Fields["RRD No"];
                        pivotTableDeamad_2.DataFields.Add(RRDField_2);
                        pivotTableDeamad_2.DataFields[0].Function = DataFieldFunctions.Count;

                        var careerField_2 = pivotTableDeamad_2.Fields["Career Level"];
                        pivotTableDeamad_2.ColumnFields.Add(careerField_2);

                        var DUField_2 = pivotTableDeamad_2.Fields["DU"];
                        pivotTableDeamad_2.RowFields.Add(DUField_2);

                        #endregion

                        #endregion

                        pckval.Save();

                        //Fill Details ROV

                        var sheetDetails = pckval.Workbook.Worksheets["Details"];

                        using (OleDbConnection connection = new OleDbConnection(con1))
                        {
                            connection.Open();

                            var currentMonth = string.Format("{0:MMM-yy}", DateTime.Now);
                            var nextMonth = string.Format("{0:MMM-yy}", DateTime.Now.AddMonths(1));
                            var secondMonth = string.Format("{0:MMM-yy}", DateTime.Now.AddMonths(2));
                            var thirdMonth = string.Format("{0:MMM-yy}", DateTime.Now.AddMonths(3));

                            string query;
                            string formattedQuery;
                            OleDbCommand command;

                            #region currentMonth
                            #region FSIG09
                            //FSIG09
                            // ASE
                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[3, 18].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[3, 19].Value = (int)command.ExecuteScalar();

                            //SE
                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[3, 20].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[3, 21].Value = (int)command.ExecuteScalar();

                            //SSE
                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[3, 22].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[3, 23].Value = (int)command.ExecuteScalar();

                            //TL
                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[3, 24].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[3, 25].Value = (int)command.ExecuteScalar();

                            //AM
                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[3, 26].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[3, 27].Value = (int)command.ExecuteScalar();

                            //M
                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[3, 28].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[3, 29].Value = (int)command.ExecuteScalar();

                            #endregion

                            #region FSIG40
                            //FSIG40
                            // ASE
                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[4, 18].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[4, 19].Value = (int)command.ExecuteScalar();

                            //SE
                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[4, 20].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[4, 21].Value = (int)command.ExecuteScalar();

                            //SSE
                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[4, 22].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[4, 23].Value = (int)command.ExecuteScalar();

                            //TL
                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[4, 24].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[4, 25].Value = (int)command.ExecuteScalar();

                            //AM
                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[4, 26].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[4, 27].Value = (int)command.ExecuteScalar();

                            //M
                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[4, 28].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[4, 29].Value = (int)command.ExecuteScalar();


                            #endregion

                            #region FSIG47
                            //FSIG47
                            // ASE
                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[5, 18].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[5, 19].Value = (int)command.ExecuteScalar();

                            //SE
                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[5, 20].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[5, 21].Value = (int)command.ExecuteScalar();

                            //SSE
                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[5, 22].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[5, 23].Value = (int)command.ExecuteScalar();

                            //TL
                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[5, 24].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[5, 25].Value = (int)command.ExecuteScalar();

                            //AM
                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[5, 26].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[5, 27].Value = (int)command.ExecuteScalar();

                            //M
                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[5, 28].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[5, 29].Value = (int)command.ExecuteScalar();
                            #endregion

                            #region FSIG49
                            //FSIG49
                            // ASE
                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[6, 18].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[6, 19].Value = (int)command.ExecuteScalar();

                            //SE
                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[6, 20].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[6, 21].Value = (int)command.ExecuteScalar();

                            //SSE
                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[6, 22].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[6, 23].Value = (int)command.ExecuteScalar();

                            //TL
                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[6, 24].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[6, 25].Value = (int)command.ExecuteScalar();

                            //AM
                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[6, 26].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[6, 27].Value = (int)command.ExecuteScalar();

                            //M
                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[6, 28].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[6, 29].Value = (int)command.ExecuteScalar();
                            #endregion

                            #region FSIG99
                            //FSIG99
                            // ASE
                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[7, 18].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[7, 19].Value = (int)command.ExecuteScalar();

                            //SE
                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[7, 20].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[7, 21].Value = (int)command.ExecuteScalar();

                            //SSE
                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[7, 22].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[7, 23].Value = (int)command.ExecuteScalar();

                            //TL
                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[7, 24].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[7, 25].Value = (int)command.ExecuteScalar();

                            //AM
                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[7, 26].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[7, 27].Value = (int)command.ExecuteScalar();

                            //M
                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[7, 28].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[7, 29].Value = (int)command.ExecuteScalar();
                            #endregion
                            #endregion

                            #region nextMonth
                            #region FSIG09
                            //FSIG09
                            // ASE
                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[12, 18].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[12, 19].Value = (int)command.ExecuteScalar();

                            //SE
                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[12, 20].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[12, 21].Value = (int)command.ExecuteScalar();

                            //SSE
                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[12, 22].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[12, 23].Value = (int)command.ExecuteScalar();

                            //TL
                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[12, 24].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[12, 25].Value = (int)command.ExecuteScalar();

                            //AM
                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[12, 26].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[12, 27].Value = (int)command.ExecuteScalar();

                            //M
                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[12, 28].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[12, 29].Value = (int)command.ExecuteScalar();

                            #endregion

                            #region FSIG40
                            //FSIG40
                            // ASE
                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[13, 18].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[13, 19].Value = (int)command.ExecuteScalar();

                            //SE
                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[13, 20].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[13, 21].Value = (int)command.ExecuteScalar();

                            //SSE
                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[13, 22].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[13, 23].Value = (int)command.ExecuteScalar();

                            //TL
                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[13, 24].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[13, 25].Value = (int)command.ExecuteScalar();

                            //AM
                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[13, 26].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[13, 27].Value = (int)command.ExecuteScalar();

                            //M
                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[13, 28].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[13, 29].Value = (int)command.ExecuteScalar();


                            #endregion

                            #region FSIG47
                            //FSIG47
                            // ASE
                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[14, 18].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[14, 19].Value = (int)command.ExecuteScalar();

                            //SE
                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[14, 20].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[14, 21].Value = (int)command.ExecuteScalar();

                            //SSE
                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[14, 22].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + currentMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[14, 23].Value = (int)command.ExecuteScalar();

                            //TL
                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[14, 24].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[14, 25].Value = (int)command.ExecuteScalar();

                            //AM
                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[14, 26].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[14, 27].Value = (int)command.ExecuteScalar();

                            //M
                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[14, 28].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[14, 29].Value = (int)command.ExecuteScalar();
                            #endregion

                            #region FSIG49
                            //FSIG49
                            // ASE
                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[15, 18].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[15, 19].Value = (int)command.ExecuteScalar();

                            //SE
                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[15, 20].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[15, 21].Value = (int)command.ExecuteScalar();

                            //SSE
                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[15, 22].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[15, 23].Value = (int)command.ExecuteScalar();

                            //TL
                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[15, 24].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[15, 25].Value = (int)command.ExecuteScalar();

                            //AM
                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[15, 26].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[15, 27].Value = (int)command.ExecuteScalar();

                            //M
                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[15, 28].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[15, 29].Value = (int)command.ExecuteScalar();
                            #endregion

                            #region FSIG99
                            //FSIG99
                            // ASE
                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[16, 18].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[16, 19].Value = (int)command.ExecuteScalar();

                            //SE
                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[16, 20].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[16, 21].Value = (int)command.ExecuteScalar();

                            //SSE
                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[16, 22].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[16, 23].Value = (int)command.ExecuteScalar();

                            //TL
                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[16, 24].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[16, 25].Value = (int)command.ExecuteScalar();

                            //AM
                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[16, 26].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[16, 27].Value = (int)command.ExecuteScalar();

                            //M
                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[16, 28].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + nextMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[16, 29].Value = (int)command.ExecuteScalar();
                            #endregion

                            #endregion

                            #region secondMonth
                            #region FSIG09
                            //FSIG09
                            // ASE
                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[21, 18].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[21, 19].Value = (int)command.ExecuteScalar();

                            //SE
                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[21, 20].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[21, 21].Value = (int)command.ExecuteScalar();

                            //SSE
                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[21, 22].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[21, 23].Value = (int)command.ExecuteScalar();

                            //TL
                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[21, 24].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[21, 25].Value = (int)command.ExecuteScalar();

                            //AM
                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[21, 26].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[21, 27].Value = (int)command.ExecuteScalar();

                            //M
                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[21, 28].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[21, 29].Value = (int)command.ExecuteScalar();

                            #endregion

                            #region FSIG40
                            //FSIG40
                            // ASE
                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[22, 18].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[22, 19].Value = (int)command.ExecuteScalar();

                            //SE
                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[22, 20].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[22, 21].Value = (int)command.ExecuteScalar();

                            //SSE
                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[22, 22].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[22, 23].Value = (int)command.ExecuteScalar();

                            //TL
                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[22, 24].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[22, 25].Value = (int)command.ExecuteScalar();

                            //AM
                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[22, 26].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[22, 27].Value = (int)command.ExecuteScalar();

                            //M
                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[22, 28].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[22, 29].Value = (int)command.ExecuteScalar();


                            #endregion

                            #region FSIG47
                            //FSIG47
                            // ASE
                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[23, 18].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[23, 19].Value = (int)command.ExecuteScalar();

                            //SE
                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[23, 20].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[23, 21].Value = (int)command.ExecuteScalar();

                            //SSE
                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[23, 22].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[23, 23].Value = (int)command.ExecuteScalar();

                            //TL
                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[23, 24].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[23, 25].Value = (int)command.ExecuteScalar();

                            //AM
                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[23, 26].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[23, 27].Value = (int)command.ExecuteScalar();

                            //M
                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[23, 28].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[23, 29].Value = (int)command.ExecuteScalar();
                            #endregion

                            #region FSIG49
                            //FSIG49
                            // ASE
                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[24, 18].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[24, 19].Value = (int)command.ExecuteScalar();

                            //SE
                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[24, 20].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[24, 21].Value = (int)command.ExecuteScalar();

                            //SSE
                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[24, 22].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[24, 23].Value = (int)command.ExecuteScalar();

                            //TL
                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[24, 24].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[24, 25].Value = (int)command.ExecuteScalar();

                            //AM
                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[24, 26].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[24, 27].Value = (int)command.ExecuteScalar();

                            //M
                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[24, 28].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[24, 29].Value = (int)command.ExecuteScalar();
                            #endregion

                            #region FSIG99
                            //FSIG99
                            // ASE
                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[25, 18].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[25, 19].Value = (int)command.ExecuteScalar();

                            //SE
                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[25, 20].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[25, 21].Value = (int)command.ExecuteScalar();

                            //SSE
                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[25, 22].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[25, 23].Value = (int)command.ExecuteScalar();

                            //TL
                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[25, 24].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[25, 25].Value = (int)command.ExecuteScalar();

                            //AM
                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[25, 26].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[25, 27].Value = (int)command.ExecuteScalar();

                            //M
                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[25, 28].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + secondMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[25, 29].Value = (int)command.ExecuteScalar();
                            #endregion

                            #endregion

                            #region thirdMonth
                            #region FSIG09
                            //FSIG09
                            // ASE
                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[30, 18].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[30, 19].Value = (int)command.ExecuteScalar();

                            //SE
                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[30, 20].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[30, 21].Value = (int)command.ExecuteScalar();

                            //SSE
                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[30, 22].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[30, 23].Value = (int)command.ExecuteScalar();

                            //TL
                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[30, 24].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[30, 25].Value = (int)command.ExecuteScalar();

                            //AM
                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[30, 26].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[30, 27].Value = (int)command.ExecuteScalar();

                            //M
                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[30, 28].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG09' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[30, 29].Value = (int)command.ExecuteScalar();

                            #endregion

                            #region FSIG40
                            //FSIG40
                            // ASE
                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[31, 18].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[31, 19].Value = (int)command.ExecuteScalar();

                            //SE
                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[31, 20].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[31, 21].Value = (int)command.ExecuteScalar();

                            //SSE
                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[31, 22].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[31, 23].Value = (int)command.ExecuteScalar();

                            //TL
                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[31, 24].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[31, 25].Value = (int)command.ExecuteScalar();

                            //AM
                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[31, 26].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[31, 27].Value = (int)command.ExecuteScalar();

                            //M
                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[31, 28].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG40' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[31, 29].Value = (int)command.ExecuteScalar();


                            #endregion

                            #region FSIG47
                            //FSIG47
                            // ASE
                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[32, 18].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[32, 19].Value = (int)command.ExecuteScalar();

                            //SE
                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[32, 20].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[32, 21].Value = (int)command.ExecuteScalar();

                            //SSE
                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[32, 22].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[32, 23].Value = (int)command.ExecuteScalar();

                            //TL
                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[32, 24].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[32, 25].Value = (int)command.ExecuteScalar();

                            //AM
                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[32, 26].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[32, 27].Value = (int)command.ExecuteScalar();

                            //M
                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[32, 28].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG47' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[32, 29].Value = (int)command.ExecuteScalar();
                            #endregion

                            #region FSIG49
                            //FSIG49
                            // ASE
                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[33, 18].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[33, 19].Value = (int)command.ExecuteScalar();

                            //SE
                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[33, 20].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[33, 21].Value = (int)command.ExecuteScalar();

                            //SSE
                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[33, 22].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[33, 23].Value = (int)command.ExecuteScalar();

                            //TL
                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[33, 24].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[33, 25].Value = (int)command.ExecuteScalar();

                            //AM
                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[33, 26].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[33, 27].Value = (int)command.ExecuteScalar();

                            //M
                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[33, 28].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG49' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[33, 29].Value = (int)command.ExecuteScalar();
                            #endregion

                            #region FSIG99
                            //FSIG99
                            // ASE
                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[34, 18].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '12' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[34, 19].Value = (int)command.ExecuteScalar();

                            //SE
                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[34, 20].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '11' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[34, 21].Value = (int)command.ExecuteScalar();

                            //SSE
                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[34, 22].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '10' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[34, 23].Value = (int)command.ExecuteScalar();

                            //TL
                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[34, 24].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '9' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[34, 25].Value = (int)command.ExecuteScalar();

                            //AM
                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[34, 26].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '8' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[34, 27].Value = (int)command.ExecuteScalar();

                            //M
                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[34, 28].Value = (int)command.ExecuteScalar();

                            query = "SELECT count(*) from [Base$] where F8 = '7' and F13 = 'FSIG99' and (F47 = 'Resignation Case' or F47 = 'Confirmed RO') and F29 = 'F' and F48 LIKE '{0}'";
                            formattedQuery = string.Format(query, '%' + thirdMonth);
                            command = new OleDbCommand(formattedQuery, connection);
                            sheetDetails.Cells[34, 29].Value = (int)command.ExecuteScalar();
                            #endregion

                            #endregion
                        }

                        pckval.Save();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("A handled exception just occurred: " + ex.Message, "Exception : ", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        public System.Data.DataTable RemoveDuplicates(FileInfo fileName)
        {
            var excelPackage = new ExcelPackage(fileName);
            System.Data.DataTable dt = new System.Data.DataTable();
            excelPackage.Workbook.CalcMode = ExcelCalcMode.Automatic;
            ExcelWorksheet worksht = excelPackage.Workbook.Worksheets[9];

            //create a list to hold the column names
            List<string> columnNames = new List<string>();

            //needed to keep track of empty column headers
            int currentColumn = 1;

            //loop all columns in the sheet and add them to the datatable
            foreach (var cell in worksht.Cells[1, 1, 1, worksht.Dimension.End.Column])
            {
                string columnName = cell.Text.Trim();

                //check if the previous header was empty and add it if it was
                if (cell.Start.Column != currentColumn)
                {
                    columnNames.Add("Header_" + currentColumn);
                    dt.Columns.Add("Header_" + currentColumn);
                    currentColumn++;
                }

                //add the column name to the list to count the duplicates
                columnNames.Add(columnName);

                //count the duplicate column names and make them unique to avoid the exception
                //A column named 'Name' already belongs to this DataTable
                int occurrences = columnNames.Count(x => x.Equals(columnName));
                if (occurrences > 1)
                {
                    columnName = columnName + "_" + occurrences;
                }

                //add the column to the datatable
                dt.Columns.Add(columnName);

                currentColumn++;
            }

            //start adding the contents of the excel file to the datatable
            for (int i = 2; i <= worksht.Dimension.End.Row; i++)
            {
                var row = worksht.Cells[i, 1, i, worksht.Dimension.End.Column];
                DataRow newRow = dt.NewRow();

                //loop all cells in the row
                foreach (var cell in row)
                {
                    newRow[cell.Start.Column - 1] = cell.Text;
                }
                dt.Rows.Add(newRow);
            }

            Hashtable hTable = new Hashtable();
            ArrayList duplicateList = new ArrayList();

            //Add list of all the unique item value to hashtable, which stores combination of key, value pair.
            //And add duplicate item value in arraylist.
            foreach (DataRow drow in dt.Rows)
            {
                if (hTable.Contains(drow[0]))
                    duplicateList.Add(drow);
                else
                    hTable.Add(drow[0], string.Empty);
            }

            //Removing a list of duplicate items from datatable.
            foreach (DataRow dRow in duplicateList)
                dt.Rows.Remove(dRow);

            //Datatable which contains unique records will be return as output.
            return dt;
        }

        public String GetTimestamp(DateTime value)
        {
            return value.ToString("yyyyMMddHHmmss");
        }
    }
}
