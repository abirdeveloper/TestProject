const bookAdaptor = require('./lib/books-adaptor')

const getAll = () => {
    const books = bookAdaptor.getAll();
    return books
}

const getOne = (code) => {
    const book = bookAdaptor.getOne(code);
    return book
}

const add = (book) => {
    const books = bookAdaptor.add(book)
    return books
}
// const getOne = async(code) => {
//     const book = await bookAdaptor.getOne(code);
//     return book
// }

module.exports = {getAll, getOne, add}