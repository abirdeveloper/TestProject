module.exports = {
    MongoUri: 'mongodb+srv://<username>:<encodedPassword>@cluster0.r09m9.mongodb.net/myFirstDatabase?retryWrites=true&w=majority',
    dbName: 'my-mongo-db',
    collectionName: 'library'
}