const express = require('express')
const router = express.Router()
const controller = require('../controller')

router.get('/', (req, res) => {  
    res.send('Welcome to Book Store')
})

router.get('/books', async(req, res) => {
    const data = await controller.getAll()
    res.send(data)
})

router.get('/book/:code', async(req,res) => {
    const { code } = req.params
    const data = await controller.getOne(code)
    res.send(data)
})

router.post('/book', (req, res) => {
    const book = req.body
    const books = controller.add(book)
    res.send(books)
})

// router.get('/book/:code', async(req,res) => {
//     const { code } = req.params
//     const data = await controller.getOne(code)
//     res.send(data)
// })

module.exports = router