﻿using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FinancialsLob
{
    /// <summary>
    /// Interaction logic for CICalculation.xaml
    /// </summary>
    public partial class CICalculation : Window
    {
        List<FiltersCI> Filter = new List<FiltersCI>();
        DataTable tr = new DataTable();
        Popup pop = new Popup();
        PopupExcell popexcell = new PopupExcell();
        private BackgroundWorker bw = new BackgroundWorker();

        public CICalculation()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            //pop.Show();
            getData(@"C:\Financial_LOB");
            //pop.Close();
        }
        private void buttonExcell_Click(object sender, RoutedEventArgs e)
        {

        }

        public void getData(string path)
        {
            DirectoryInfo di = new DirectoryInfo(path);
            FileInfo[] FileReport = di.GetFiles("*.xlsb");
            FileInfo[] FileTemplate = di.GetFiles("*.xlsx");

            string con1 = "";
            DataSet ds = new DataSet();
            DataTableCollection dt = ds.Tables;


            con1 =
@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + FileTemplate[1].FullName + " ;" +
@"Extended Properties='Excel 12.0;HDR=NO;IMEX=1,FMT=Delimited'";



            if (FileTemplate[1].Name.Contains("Template1"))
            {
                using (OleDbConnection connection = new OleDbConnection(con1))
                {
                    connection.Open();

                    OleDbCommand commandAD = new OleDbCommand("select * from [Refresh$]", connection);
                    commandAD.CommandType = CommandType.Text;
                    OleDbDataAdapter myDataAdaptorAD = new OleDbDataAdapter(commandAD);
                    myDataAdaptorAD.Fill(ds, "Template1");
                    dt = ds.Tables;

                }


            }



            LoadGrid(dt, FileReport);


        }

        public void LoadGrid(DataTableCollection dt, FileInfo[] FileReport)
        {
            int lvl = 0;
            foreach (DataRow row in dt[0].Rows.Cast<DataRow>().Skip(1))
            {

                if (row.ItemArray != null)
                    if (!row.ItemArray.All(x => x == null || (x != null && string.IsNullOrWhiteSpace(x.ToString()))))
                    {
                        Filter.Add(new FiltersCI
                        {
                            category = row.ItemArray[0].ToString(),
                            woname = row.ItemArray[1].ToString(),
                            name = row.ItemArray[2].ToString(),
                            effectivedate = row.ItemArray[6].ToString(),
                            location = row.ItemArray[4].ToString(),
                            gsorole = row.ItemArray[5].ToString(),
                            mmeupdate = row.ItemArray[6].ToString(),
                            empnumber = row.ItemArray[7].ToString()

                        }

                         );



                    }

            }

            string con2 =
            @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + FileReport[1].FullName + " ;" +
            @"Extended Properties='Excel 12.0;HDR=YES;IMEX=1'";

            AddFsig(con2, Filter);


        }

        private void AddFsig(string con2 , List<FiltersCI> Filter)
        {
            DataSet ds = new DataSet();
            DataTableCollection dtn = ds.Tables;
            string tbname = Filter[0].woname.Remove(Filter[0].woname.IndexOf(')')).Substring(Filter[0].woname.IndexOf('(') + 1);
            using (OleDbConnection connection = new OleDbConnection(con2))
            {
                connection.Open();

                OleDbCommand commandAD = connection.CreateCommand();
                commandAD.CommandType = CommandType.Text;
                string tableName = String.Format("[{0}$]", tbname);

                commandAD.CommandText = String.Format("SELECT * FROM {0}", tableName);
                commandAD.CommandType = CommandType.Text;
                OleDbDataAdapter myDataAdaptorAD = new OleDbDataAdapter(commandAD);
                myDataAdaptorAD.Fill(ds, tbname);
                dtn = ds.Tables;

            }
            
                    int count2 = 0;
                    foreach (DataRow dr in dtn[0].Rows.Cast<DataRow>().Skip(3))
                    {

                        count2 = count2 + 1;
                        int n = 0;

                        for (int j = 0; j < dr.ItemArray.Count(); j++)
                        {
                            n = n + 1;

                            
                        }
                    }
                
            

            }
        }
}
