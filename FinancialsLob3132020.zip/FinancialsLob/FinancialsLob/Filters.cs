﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinancialsLob
{
    class Filters
    {
        public string rolename { get; set; }
        public string level { get; set; }
        public string comparison { get; set; }
    }

    class FiltersCI
    {
        public string category { get; set; }
        public string woname { get; set; }
        public string name { get; set; }
        public string effectivedate { get; set; }
        public string location { get; set; }
        public string gsorole { get; set; }
        public string mmeupdate { get; set; }
        public string empnumber { get; set; }
    }

}
