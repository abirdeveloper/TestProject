﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinancialsLob
{
    class Filters
    {
        public string rolename { get; set; }
        public string level { get; set; }
        public string comparison { get; set; }
    }

    class FiltersCI
    {
        public string category { get; set; }

        public string typeOfPlan { get; set; }
        public string woname { get; set; }
        public string name { get; set; }
        public DateTime effectivedate { get; set; }
        public string location { get; set; }
        public string gsorole { get; set; }
        public string mmeupdate { get; set; }
        public string empnumber { get; set; }
        public string newgsorole { get; set; }
    }

    public class DetailsCCI
    {
        public string FY1 { get; set; }

        public string FY2 { get; set; }


        public string FY3 { get; set; }


        public string FY4 { get; set; }


        public string FYall { get; set; }

        
        public string FYRevenue { get; set; }


    }

    public class feildsCFM
    {

        public List<string> GsoRole = new List<string>() {
"IndiaGSO App Designer",
"IndiaGSO Architect",
"IndiaGSO Business Analyst",
"IndiaGSO Business Analyst Lead",
"IndiaGSO DBA",
"IndiaGSO DBA Lead",
"IndiaGSO Developer",
"IndiaGSO Infra Engineer",
"IndiaGSO Infra Sr Engineer",
"IndiaGSO IT Operations",
"IndiaGSO Project Manager",
"IndiaGSO QA Analyst",
"IndiaGSO QA Lead",
"IndiaGSO Sr Architect",
"IndiaGSO Sr IT Operations",
"IndiaGSO Sr Project Manager",
"IndiaGSO Lead Project Manager",
"IndiaGSO Domain Consultant",
"IndiaGSOSr Domain Consultant ",
"IndiaGSO Associate Domain Consultant",
"IndiaGSO Sr. Developer",
"IndiaGSO Infrastructure Engineer Specialist",
"USAGSO App Designer",
"USAGSO Architect",
"USAGSO Business Analyst",
"USAGSO Business Analyst Lead",
"USAGSO DBA",
"USAGSO DBA Lead",
"USAGSO Developer",
"USAGSO Infra Engineer",
"USAGSO Infra Sr Engineer",
"USAGSO IT Operations",
"USAGSO Project Manager",
"USAGSO QA Analyst",
"USAGSO QA Lead",
"USAGSO Sr Architect",
"USAGSO Sr IT Operations",
"USAGSO Sr Project Manager",
"USAGSO Lead Project Manager",
"USAGSO Domain Consultant",
"USAGSOSr Domain Consultant",
"USAGSO Associate Domain Consultant",
"USAGSO Sr. Developer",
"USAGSO Infrastructure Engineer Specialist",
"USAGSO App Designer(Non Core)",
"USAGSO Architect(Non Core)",
"USAGSO Developer(Non Core)",
"USAGSO Infra Engineer(Non Core)",
"USAGSO Infra Sr Engineer(Non Core)",
"USAGSO Sr Architect(Non Core)",
"USAGSO Sr. Developer(Non Core)",
"IndiaGSO App Designer(Non Core)",
"IndiaGSO Architect(Non Core)",
"IndiaGSO Developer(Non Core)",
"IndiaGSO Infra Engineer(Non Core)",
"IndiaGSO Infra Sr Engineer(Non Core)",
"IndiaGSO Sr Architect(Non Core)",
"IndiaGSO Sr. Developer(Non Core)"
};

        public List<string> woNumber1 = new List<string>()
        {
"GSO-ESS-119084(FSIG09)",
"GSO-ESS-143354(FSIG09)",
"GSO-ESS-143902(FSIG09)",
"GSO-ESS-279460(FSIG09)",
"GSO-ESS-317607(FSIG09)",
"GSO-ESS-320546(FSIG09)",
"GSO-ESS-335880(FSIG09)",
"GSO-ESS-339491(FSIG09)",
"GSO-ESS-395681(FSIG09)",
"GSO-ESS-410031(FSIG09)",
"GSO-ESS-421514(FSIG09)",
"GSO-ESS-542199(FSIG09)",
"GSO-ESS-553423(FSIG09)",
"GSO-ESS-555710(FSIG09)",
"GSO-ESS-556470(FSIG09)",
"GSO-ESS-557681(FSIG09)",
"GSO-ESS-593213(FSIG09)",
"GSO-ESS-594376(FSIG09)",
"GSO-ESS-625037(FSIG09)",
"GSO-ESS-626836(FSIG09)",
"GSO-ESS-631207(FSIG09)",
"GSO-ESS-634027(FSIG09)",
"GSO-ESS-640516(FSIG09)",
"GSO-ESS-645085(FSIG09)",
"GSO-ESS-651114(FSIG09)",
"GSO-ESS-651518(FSIG09)",
"GSO-ESS-652420(FSIG09)",
"GSO-ESS-685112(FSIG09)",
"GSO-ESS-691714(FSIG09)",
"GSO-ESS-721669(FSIG09)",
"GSO-ESS-733994(FSIG09)",
"GSO-ESS-733274(FSIG09)",
"GSO-ESS-729604(FSIG09)",
"GSO-ESS-732007(FSIG09)",
"GSO-ESS-731770(FSIG09)",
"GSO-ESS-736548(FSIG09)",
"GSO-ESS-735620(FSIG09)",
"GSO-ESS-750813(FSIG09)",
"GSO-ESS-744611(FSIG09)",
"GSO-ESS-761045(FSIG09)",
"GSO-ESS-761317(FSIG09)",
"GSO-ESS-761771(FSIG09)",
"GSO-ESS-761797(FSIG09)",
"GSO-ESS-761801(FSIG09)",
"GSO-ESS-760896(FSIG09)",
"GSO-ESS-772266(FSIG09)",
"GSO-ESS-771885(FSIG09)",
"GSO-ESS-771888(FSIG09)",
"GSO-ESS-773615(FSIG09)",
"GSO-ESS-777544(FSIG09)",
"GSO-ESS-777127(FSIG09)",
"GSO-ESS-782478(FSIG09)",
"GSO-ESS-786374(FSIG09)",
"GSO-ESS-786408(FSIG09)",
"GSO-ESS-788208(FSIG09)",
"GSO-ESS-788902(FSIG09)",
"GSO-ESS-788717(FSIG09)",
"GSO-ESS-789349(FSIG09)",
"GSO-ESS-789350(FSIG09)",
"GSO-ESS-789348(FSIG09)",
"GSO-ESS-791341(FSIG09)",
"GSO-ESS-792802(FSIG09)",
"GSO-ESS-792909(FSIG09)",
"GSO-ESS-793791(FSIG09)",
"GSO-ESS-801643(FSIG09)",
"GSO-ESS-802177(FSIG09)",
"GSO-ESS-805077(FSIG09)",
"GSO-ESS-807561(FSIG09)",
"GSO-ESS-807377(FSIG09)",
"GSO-ESS-807472(FSIG09)",
"GSO-ESS-807622(FSIG09)",
"GSO-ESS-807500(FSIG09)",
"GSO-ESS-807473(FSIG09)",
"GSO-ESS-810578(FSIG09)",
"GSO-ESS-786374(RPA)",
"GSO-ESS-736548(RPA)",
"GSO-ESS-732007(RPA)",
"Others"
};

        public List<string> woNumber2 = new List<string>()
        {

"GSO-ESS-119084(FSIG40)",
"GSO-ESS-143354(FSIG40)",
"GSO-ESS-143902(FSIG40)",
"GSO-ESS-279460(FSIG40)",
"GSO-ESS-317607(FSIG40)",
"GSO-ESS-320546(FSIG40)",
"GSO-ESS-335880(FSIG40)",
"GSO-ESS-339491(FSIG40)",
"GSO-ESS-395681(FSIG40)",
"GSO-ESS-410031(FSIG40)",
"GSO-ESS-421514(FSIG40)",
"GSO-ESS-542199(FSIG40)",
"GSO-ESS-553423(FSIG40)",
"GSO-ESS-555710(FSIG40)",
"GSO-ESS-556470(FSIG40)",
"GSO-ESS-557681(FSIG40)",
"GSO-ESS-593213(FSIG40)",
"GSO-ESS-594376(FSIG40)",
"GSO-ESS-625037(FSIG40)",
"GSO-ESS-626836(FSIG40)",
"GSO-ESS-631207(FSIG40)",
"GSO-ESS-634027(FSIG40)",
"GSO-ESS-640516(FSIG40)",
"GSO-ESS-645085(FSIG40)",
"GSO-ESS-651114(FSIG40)",
"GSO-ESS-651518(FSIG40)",
"GSO-ESS-652420(FSIG40)",
"GSO-ESS-685112(FSIG40)",
"GSO-ESS-691714(FSIG40)",
"GSO-ESS-721669(FSIG40)",
"GSO-ESS-733994(FSIG40)",
"GSO-ESS-733274(FSIG40)",
"GSO-ESS-729604(FSIG40)",
"GSO-ESS-732007(FSIG40)",
"GSO-ESS-731770(FSIG40)",
"GSO-ESS-736548(FSIG40)",
"GSO-ESS-735620(FSIG40)",
"GSO-ESS-750813(FSIG40)",
"GSO-ESS-744611(FSIG40)",
"GSO-ESS-761045(FSIG40)",
"GSO-ESS-761317(FSIG40)",
"GSO-ESS-761771(FSIG40)",
"GSO-ESS-761797(FSIG40)",
"GSO-ESS-761801(FSIG40)",
"GSO-ESS-760896(FSIG40)",
"GSO-ESS-772266(FSIG40)",
"GSO-ESS-771885(FSIG40)",
"GSO-ESS-771888(FSIG40)",
"GSO-ESS-773615(FSIG40)",
"GSO-ESS-777544(FSIG40)",
"GSO-ESS-777127(FSIG40)",
"GSO-ESS-782478(FSIG40)",
"GSO-ESS-786374(FSIG40)",
"GSO-ESS-786408(FSIG40)",
"GSO-ESS-788208(FSIG40)",
"GSO-ESS-788902(FSIG40)",
"GSO-ESS-788717(FSIG40)",
"GSO-ESS-789349(FSIG40)",
"GSO-ESS-789350(FSIG40)",
"GSO-ESS-789348(FSIG40)",
"GSO-ESS-791341(FSIG40)",
"GSO-ESS-792802(FSIG40)",
"GSO-ESS-792909(FSIG40)",
"GSO-ESS-793791(FSIG40)",
"GSO-ESS-801643(FSIG40)",
"GSO-ESS-802177(FSIG40)",
"GSO-ESS-805077(FSIG40)",
"GSO-ESS-807561(FSIG40)",
"GSO-ESS-807377(FSIG40)",
"GSO-ESS-807472(FSIG40)",
"GSO-ESS-807622(FSIG40)",
"GSO-ESS-807500(FSIG40)",
"GSO-ESS-807473(FSIG40)",
"GSO-ESS-810578(FSIG40)",
"Others"
};

        public  List<string> woNumber3 = new List<string>()
        {

"GSO-ESS-119084(FSIG47)",
"GSO-ESS-143354(FSIG47)",
"GSO-ESS-143902(FSIG47)",
"GSO-ESS-279460(FSIG47)",
"GSO-ESS-317607(FSIG47)",
"GSO-ESS-320546(FSIG47)",
"GSO-ESS-335880(FSIG47)",
"GSO-ESS-339491(FSIG47)",
"GSO-ESS-395681(FSIG47)",
"GSO-ESS-410031(FSIG47)",
"GSO-ESS-421514(FSIG47)",
"GSO-ESS-542199(FSIG47)",
"GSO-ESS-553423(FSIG47)",
"GSO-ESS-555710(FSIG47)",
"GSO-ESS-556470(FSIG47)",
"GSO-ESS-557681(FSIG47)",
"GSO-ESS-593213(FSIG47)",
"GSO-ESS-594376(FSIG47)",
"GSO-ESS-625037(FSIG47)",
"GSO-ESS-626836(FSIG47)",
"GSO-ESS-631207(FSIG47)",
"GSO-ESS-634027(FSIG47)",
"GSO-ESS-640516(FSIG47)",
"GSO-ESS-645085(FSIG47)",
"GSO-ESS-651114(FSIG47)",
"GSO-ESS-651518(FSIG47)",
"GSO-ESS-652420(FSIG47)",
"GSO-ESS-685112(FSIG47)",
"GSO-ESS-691714(FSIG47)",
"GSO-ESS-721669(FSIG47)",
"GSO-ESS-733994(FSIG47)",
"GSO-ESS-733274(FSIG47)",
"GSO-ESS-729604(FSIG47)",
"GSO-ESS-732007(FSIG47)",
"GSO-ESS-731770(FSIG47)",
"GSO-ESS-736548(FSIG47)",
"GSO-ESS-735620(FSIG47)",
"GSO-ESS-750813(FSIG47)",
"GSO-ESS-744611(FSIG47)",
"GSO-ESS-761045(FSIG47)",
"GSO-ESS-761317(FSIG47)",
"GSO-ESS-761771(FSIG47)",
"GSO-ESS-761797(FSIG47)",
"GSO-ESS-761801(FSIG47)",
"GSO-ESS-760896(FSIG47)",
"GSO-ESS-772266(FSIG47)",
"GSO-ESS-771885(FSIG47)",
"GSO-ESS-771888(FSIG47)",
"GSO-ESS-773615(FSIG47)",
"GSO-ESS-777544(FSIG47)",
"GSO-ESS-777127(FSIG47)",
"GSO-ESS-782478(FSIG47)",
"GSO-ESS-786374(FSIG47)",
"GSO-ESS-786408(FSIG47)",
"GSO-ESS-788208(FSIG47)",
"GSO-ESS-788902(FSIG47)",
"GSO-ESS-788717(FSIG47)",
"GSO-ESS-789349(FSIG47)",
"GSO-ESS-789350(FSIG47)",
"GSO-ESS-789348(FSIG47)",
"GSO-ESS-791341(FSIG47)",
"GSO-ESS-792802(FSIG47)",
"GSO-ESS-792909(FSIG47)",
"GSO-ESS-793791(FSIG47)",
"GSO-ESS-801643(FSIG47)",
"GSO-ESS-802177(FSIG47)",
"GSO-ESS-805077(FSIG47)",
"GSO-ESS-807561(FSIG47)",
"GSO-ESS-807377(FSIG47)",
"GSO-ESS-807472(FSIG47)",
"GSO-ESS-807622(FSIG47)",
"GSO-ESS-807500(FSIG47)",
"GSO-ESS-807473(FSIG47)",
"GSO-ESS-810578(FSIG47)",
"Others"


        };

        public List<string> woNumber4 = new List<string>()
        {
"GSO-ESS-119084(FSIG49)",
"GSO-ESS-143354(FSIG49)",
"GSO-ESS-143902(FSIG49)",
"GSO-ESS-279460(FSIG49)",
"GSO-ESS-317607(FSIG49)",
"GSO-ESS-320546(FSIG49)",
"GSO-ESS-335880(FSIG49)",
"GSO-ESS-339491(FSIG49)",
"GSO-ESS-395681(FSIG49)",
"GSO-ESS-410031(FSIG49)",
"GSO-ESS-421514(FSIG49)",
"GSO-ESS-542199(FSIG49)",
"GSO-ESS-553423(FSIG49)",
"GSO-ESS-555710(FSIG49)",
"GSO-ESS-556470(FSIG49)",
"GSO-ESS-557681(FSIG49)",
"GSO-ESS-593213(FSIG49)",
"GSO-ESS-594376(FSIG49)",
"GSO-ESS-625037(FSIG49)",
"GSO-ESS-626836(FSIG49)",
"GSO-ESS-631207(FSIG49)",
"GSO-ESS-634027(FSIG49)",
"GSO-ESS-640516(FSIG49)",
"GSO-ESS-645085(FSIG49)",
"GSO-ESS-651114(FSIG49)",
"GSO-ESS-651518(FSIG49)",
"GSO-ESS-652420(FSIG49)",
"GSO-ESS-685112(FSIG49)",
"GSO-ESS-691714(FSIG49)",
"GSO-ESS-721669(FSIG49)",
"GSO-ESS-733994(FSIG49)",
"GSO-ESS-733274(FSIG49)",
"GSO-ESS-729604(FSIG49)",
"GSO-ESS-732007(FSIG49)",
"GSO-ESS-731770(FSIG49)",
"GSO-ESS-736548(FSIG49)",
"GSO-ESS-735620(FSIG49)",
"GSO-ESS-750813(FSIG49)",
"GSO-ESS-744611(FSIG49)",
"GSO-ESS-761045(FSIG49)",
"GSO-ESS-761317(FSIG49)",
"GSO-ESS-761771(FSIG49)",
"GSO-ESS-761797(FSIG49)",
"GSO-ESS-761801(FSIG49)",
"GSO-ESS-760896(FSIG49)",
"GSO-ESS-772266(FSIG49)",
"GSO-ESS-771885(FSIG49)",
"GSO-ESS-771888(FSIG49)",
"GSO-ESS-773615(FSIG49)",
"GSO-ESS-777544(FSIG49)",
"GSO-ESS-777127(FSIG49)",
"GSO-ESS-782478(FSIG49)",
"GSO-ESS-786374(FSIG49)",
"GSO-ESS-786408(FSIG49)",
"GSO-ESS-788208(FSIG49)",
"GSO-ESS-788902(FSIG49)",
"GSO-ESS-788717(FSIG49)",
"GSO-ESS-789349(FSIG49)",
"GSO-ESS-789350(FSIG49)",
"GSO-ESS-789348(FSIG49)",
"GSO-ESS-791341(FSIG49)",
"GSO-ESS-792802(FSIG49)",
"GSO-ESS-792909(FSIG49)",
"GSO-ESS-793791(FSIG49)",
"GSO-ESS-801643(FSIG49)",
"GSO-ESS-802177(FSIG49)",
"GSO-ESS-805077(FSIG49)",
"GSO-ESS-807561(FSIG49)",
"GSO-ESS-807377(FSIG49)",
"GSO-ESS-807472(FSIG49)",
"GSO-ESS-807622(FSIG49)",
"GSO-ESS-807500(FSIG49)",
"GSO-ESS-807473(FSIG49)",
"GSO-ESS-810578(FSIG49)",
"Others"

        };


        public List<string> woNumber = new List<string>()
        {
"GSO-ESS-119084(FSIG99)",
"GSO-ESS-143354(FSIG99)",
"GSO-ESS-143902(FSIG99)",
"GSO-ESS-279460(FSIG99)",
"GSO-ESS-317607(FSIG99)",
"GSO-ESS-320546(FSIG99)",
"GSO-ESS-335880(FSIG99)",
"GSO-ESS-339491(FSIG99)",
"GSO-ESS-395681(FSIG99)",
"GSO-ESS-410031(FSIG99)",
"GSO-ESS-421514(FSIG99)",
"GSO-ESS-542199(FSIG99)",
"GSO-ESS-300",
"GSO-ESS-553423(FSIG99)",
"GSO-ESS-555710(FSIG99)",
"GSO-ESS-556470(FSIG99)",
"GSO-ESS-557681(FSIG99)",
"GSO-ESS-593213(FSIG99)",
"GSO-ESS-594376(FSIG99)",
"GSO-ESS-625037(FSIG99)",
"GSO-ESS-626836(FSIG99)",
"GSO-ESS-631207(FSIG99)",
"GSO-ESS-634027(FSIG99)",
"GSO-ESS-640516(FSIG99)",
"GSO-ESS-645085(FSIG99)",
"GSO-ESS-651114(FSIG99)",
"GSO-ESS-651518(FSIG99)",
"GSO-ESS-652420(FSIG99)",
"GSO-ESS-685112(FSIG99)",
"GSO-ESS-691714(FSIG99)",
"GSO-ESS-721669(FSIG99)",
"GSO-ESS-733994(FSIG99)",
"GSO-ESS-733274(FSIG99)",
"GSO-ESS-729604(FSIG99)",
"GSO-ESS-732007(FSIG99)",
"GSO-ESS-731770(FSIG99)",
"GSO-ESS-736548(FSIG99)",
"GSO-ESS-735620(FSIG99)",
"GSO-ESS-750813(FSIG99)",
"GSO-ESS-744611(FSIG99)",
"GSO-ESS-761045(FSIG99)",
"GSO-ESS-761317(FSIG99)",
"GSO-ESS-761771(FSIG99)",
"GSO-ESS-761797(FSIG99)",
"GSO-ESS-761801(FSIG99)",
"GSO-ESS-760896(FSIG99)",
"GSO-ESS-772266(FSIG99)",
"GSO-ESS-771885(FSIG99)",
"GSO-ESS-771888(FSIG99)",
"GSO-ESS-773615(FSIG99)",
"GSO-ESS-777544(FSIG99)",
"GSO-ESS-777127(FSIG99)",
"GSO-ESS-782478(FSIG99)",
"GSO-ESS-786374(FSIG99)",
"GSO-ESS-786408(FSIG99)",
"GSO-ESS-788208(FSIG99)",
"GSO-ESS-788902(FSIG99)",
"GSO-ESS-788717(FSIG99)",
"GSO-ESS-789349(FSIG99)",
"GSO-ESS-789350(FSIG99)",
"GSO-ESS-789348(FSIG99)",
"GSO-ESS-791341(FSIG99)",
"GSO-ESS-792802(FSIG99)",
"GSO-ESS-792909(FSIG99)",
"GSO-ESS-793791(FSIG99)",
"GSO-ESS-801643(FSIG99)",
"GSO-ESS-802177(FSIG99)",
"GSO-ESS-805077(FSIG99)",
"GSO-ESS-807561(FSIG99)",
"GSO-ESS-807377(FSIG99)",
"GSO-ESS-807472(FSIG99)",
"GSO-ESS-807622(FSIG99)",
"GSO-ESS-807500(FSIG99)",
"GSO-ESS-807473(FSIG99)",
"GSO-ESS-810578(FSIG99)",
"Others"
        };

        public List<string> duName = new List<string>()
        {
            "FSIG47","FSIG09","FSIG40","FSIG49","FSIG99"
        };

        public List<string> Category = new List<string>()
        {
"Role - On to Off",
"Replacement",
"Role Bump",
"Roll Off",
"Ramp up",
"Location change - Same Resource",
"Non Billable to Billable",
"Promotion",
"Role - Off to On",
"WO Movement",
"Role downgrade",
"Billable to Non Billable",
};

        public List<string> SubCategory = new List<string>()
        {
            "MME Correction",
            "Promotion",
            "Trigger Non-billable",
            "Ramp up",
            "No change",
            "Plan Withdrawn",
            "Trigger Billable",
            "Role Bump",
            "Resource Location change",
            "Roll Off"

        };
        public List<string> SubCategory1 = new List<string>()
        {

            "Trigger Non-billable",           
            "Trigger Billable"
          

        };
        public List<string> SubCategory2 = new List<string>()
        {

            "Resource Location change",
           "Plan Withdrawn"


        };
        public List<string> SubCategor3 = new List<string>()
        {

           "Plan Withdrawn",
            "Trigger Billable"

        };

        public List<string> SubCategor4 = new List<string>()
        {

           "Plan Withdrawn",

            "Role Bump"

        };
        public List<string> SubCategor5 = new List<string>()
        {

           "Plan Withdrawn",
            "Roll Off"
        };
        public List<string> SubCategor6 = new List<string>()
        {

           "Roll Off",

           "Ramp up"

        };

        public List<string> SubCategor7 = new List<string>()
        {

          

           "Ramp up",
           "Plan Withdrawn"

        };
        public List<string> SubCategor8 = new List<string>()
        {

           "Roll Off",

           "Ramp up"

        };



        public List <string> Location = new List<string>()
        {
            "Onshore",
            "Offshore"

        };

        public List<string> MMEUpdate = new List<string>()
        {
            "Yes",
            "No"

        };

        public List<int> clevel = new List<int>()
        {
            12,11,10,9,8,7,6,5
            

        };

        public List<string> gsoroleBill = new List<string>()
        {
 "26.4", 
 "29.12", 
 "23.67", 
 "31.85", 
 "23.67", 
 "31.85", 
 "21.38", 
 "23.67", 
 "29.12", 
 "17.77", 
 "29.12", 
 "20.5", 
 "25.52", 
 "39.16", 
 "21.82", 
 "35.99", 
 "32.56", 
 "43.12", 
 "46.64", 
 "32.0", 
 "27.5", 
 "31.0", 
 "69.34", 
 "80.87", 
 "69.34", 
 "81.31", 
 "69.34", 
 "86.85", 
 "59.13", 
 "63.8", 
 "79.9", 
 "55.44", 
 "80.87", 
 "57.28", 
 "66.52", 
 "101.64",
 "64.24",
 "115.54",
 "101.2",
 "111.76",
 "123.2", 
 "88.0",
 "74.5",
 "85.0",
 "76.27",
 "88.95",
 "65.04",
 "70.18",
 "87.89",
 "111.8",
 "81.95",
 "29.04",
 "32.04",
 "23.52",
 "26.03",
 "32.04",
 "43.07",
 "30.25",
};


    }
}

