﻿using OfficeOpenXml;
using OfficeOpenXml.Style;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FinancialsLob
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Filters> Filter = new List<Filters>();
        int cciFlag = 0;
        DataTable tr = new DataTable();
        Popup pop = new Popup();
        PopupExcell popexcell = new PopupExcell();
        private BackgroundWorker bw = new BackgroundWorker();

        public MainWindow()
        {
            InitializeComponent();
        }
        private void button_Click(object sender, RoutedEventArgs e)
        {
            pop.Show();
            getData(@"C:\Financial_LOB");
            pop.Close();
        }
        private void buttonExcell_Click(object sender, RoutedEventArgs e)
        {
            bw.WorkerReportsProgress = true;
            bw.DoWork += bw_DoWork;
            bw.RunWorkerCompleted += bw_RunWorkerCompleted;
            bw.RunWorkerAsync();

            //Progress Bar Window
            popexcell.Show();

        }

        private void bw_DoWork(object sender, DoWorkEventArgs e)
        {
            this.Dispatcher.Invoke(() =>
            {
                GenerateExcell();

            });

        }
        private void bw_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            //Progress Bar Window close
            popexcell.Close();
        }
        private void GenerateExcell()
        {
            DataTable dt = new DataTable();
            dt = ((DataView)dtGrid.ItemsSource).ToTable();

            String timeStamp = GetTimestamp(DateTime.Now);

            if (!Directory.Exists(@"C:\Financial_LOB\Output"))
                Directory.CreateDirectory(@"C:\Financial_LOB\Output");


            ExcelPackage p = new ExcelPackage();
            var wb = p.Workbook;
            var ws = wb.Worksheets.Add("Filtered Data");

            //load data into cell A1            
            ws.Cells["A1"].LoadFromDataTable(dt, true);
            ws.Cells.AutoFitColumns();
            using (ExcelRange objRange = ws.Cells["A1:XFD1"])
            {
                objRange.Style.Font.Bold = true;
                objRange.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                objRange.Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                objRange.Style.Fill.PatternType = ExcelFillStyle.Solid;
                objRange.Style.Fill.BackgroundColor.SetColor(System.Drawing.ColorTranslator.FromHtml("#B7DEE8"));
            }
            p.SaveAs(new FileInfo(@"C:\Financial_LOB\Output\FilteredData_" + timeStamp + ".xlsx"));

        }
        public void getData(string path)
        {
            DirectoryInfo di = new DirectoryInfo(path);
            FileInfo[] FileReport = di.GetFiles("*.xlsb");
            FileInfo[] FileTemplate = di.GetFiles("*.xlsx");

            string con1 = "";
            DataSet ds = new DataSet();
            DataTableCollection dt = ds.Tables;

            con1 =
@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + FileTemplate[0].FullName + " ;" +
@"Extended Properties='Excel 12.0;HDR=NO;IMEX=1'";

            

            if (FileTemplate[0].Name.Contains("Template"))
            {
                using (OleDbConnection connection = new OleDbConnection(con1))
                {
                    connection.Open();

                    OleDbCommand commandAD = new OleDbCommand("select * from [Sheet1$]", connection);
                    commandAD.CommandType = CommandType.Text;
                    OleDbDataAdapter myDataAdaptorAD = new OleDbDataAdapter(commandAD);
                    myDataAdaptorAD.Fill(ds, "Template");
                    dt = ds.Tables;

                }
            }

           

            LoadGrid(dt, FileReport);


        }

        public void LoadGrid(DataTableCollection dt , FileInfo[] FileReport)
        {
            int lvl = 0;
            foreach (DataRow row in dt[0].Rows.Cast<DataRow>().Skip(1))
            {

                if (row.ItemArray != null)
                    if (!row.ItemArray.All(x => x == null || (x != null && string.IsNullOrWhiteSpace(x.ToString()))))
                    {
                        Filter.Add(new Filters
                        {
                            rolename = row.ItemArray[0].ToString(),
                            level = row.ItemArray[1].ToString(),
                            comparison = row.ItemArray[2].ToString(),

                        }

                         );



                    }

            }

            DataSet ds = new DataSet();
            DataTableCollection dtn = ds.Tables;

            string con3 =
@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + FileReport[0].FullName + " ;" +
@"Extended Properties='Excel 12.0;HDR=YES;IMEX=1'";

            getCCIRow(con3);

            string con2 =
@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + FileReport[0].FullName + " ;" +
@"Extended Properties='Excel 12.0;HDR=NO;IMEX=1;MAXSCANROWS=0;ImportMixedTypes=Text'";


            if (FileReport[0].Name.Contains("LOB Financials"))
            {
                using (OleDbConnection connection = new OleDbConnection(con2))
                {
                    connection.Open();
         
                     OleDbCommand commandAD = connection.CreateCommand();
                     commandAD.CommandType = CommandType.Text;
                     string tableName = String.Format("[{0}$]", "Resource Level Forecast");
                    string filt = Filter[0].rolename.ToString();
                    string[] filtlvl = Filter[0].level.Split('-');
                    string ccicount = "F" + cciFlag;

                      lvl = Convert.ToInt32(filtlvl[0]);
                    
                    commandAD.CommandText = String.Format("SELECT F3, F5, F6, F7, F9 , {2} FROM {0} where F6 = '{1}'", tableName, filt, ccicount);
                    commandAD.CommandType = CommandType.Text;
                     OleDbDataAdapter myDataAdaptorAD = new OleDbDataAdapter(commandAD);
                     myDataAdaptorAD.Fill(ds, "ResourceLevelForecast");
                     dtn = ds.Tables;


                }
            }

            var t = new DataTable();
            t.Columns.Add(new DataColumn("Personnel #"));
            t.Columns.Add(new DataColumn("Enterprise id"));
            t.Columns.Add(new DataColumn("Role Name"));
            t.Columns.Add(new DataColumn("Level"));
            t.Columns.Add(new DataColumn("WO Number"));
            t.Columns.Add(new DataColumn("CCI%"));
            t.Columns.Add(new DataColumn("TempLevel"));

            // Add data to DataTable
            for (int lineNumber = 1; lineNumber < dtn[0].Rows.Count; lineNumber++)
            {
                DataRow newRow = t.NewRow();
                for (int column = 0; column < dtn[0].Columns.Count + 1; column++)
                {
                    if (column == 6)
                    {
                        string[] filtlvl = dtn[0].Rows[lineNumber][3].ToString().Split('-');
                        newRow[column] = Convert.ToInt32(filtlvl[0]);
                    }
                    //    else if(column == 5)
                    //{
                    //    double filtper = Convert.ToDouble(dtn[0].Rows[lineNumber][5]) * 100;
                    //    newRow[column] = String.Format("{0:0.00}", filtper)  + "%";
                    //}

                    else
                        newRow[column] = dtn[0].Rows[lineNumber][column];

                    
                }
                t.Rows.Add(newRow);
            }
            
            if (Filter[0].comparison.ToString() == "equal")
            {
                DataView dv = new DataView(t);
                dv.RowFilter = "TempLevel = " + lvl;
                tr = dv.ToTable();
            }
            if (Filter[0].comparison.ToString() == "less than or equal to")
            {
                DataView dv = new DataView(t);
                dv.RowFilter = "TempLevel >= " + lvl;
                tr = dv.ToTable();
            }
            if (Filter[0].comparison.ToString() == "less than")
            {
                DataView dv = new DataView(t);
                dv.RowFilter = "TempLevel > " + lvl;
                tr = dv.ToTable();
            }
            if (Filter[0].comparison.ToString() == "greater than or equal to")
            {
                DataView dv = new DataView(t);
                dv.RowFilter = "TempLevel <= " + lvl;
                tr = dv.ToTable();
            }
            if (Filter[0].comparison.ToString() == "greater than")
            {
                DataView dv = new DataView(t);
                dv.RowFilter = "TempLevel < " + lvl;
                tr = dv.ToTable();
            }

            buttonExcell.Visibility = Visibility.Visible;
            dtGrid.Visibility = Visibility.Visible;
            dtGrid.ItemsSource = tr.DefaultView;
            Label1.Visibility= Visibility.Visible;
            Label1.Content = "Total number of rows : " + tr.Rows.Count;



        }

        private void getCCIRow(string con3)
        {
            DataSet ds = new DataSet();
            DataTableCollection dtn = ds.Tables;

            using (OleDbConnection connection = new OleDbConnection(con3))
            {
                connection.Open();

                OleDbCommand commandAD = connection.CreateCommand();
                commandAD.CommandType = CommandType.Text;
                string tableName = String.Format("[{0}$]", "Resource Level Forecast");               
                commandAD.CommandText = String.Format("SELECT * FROM {0}", tableName);
                commandAD.CommandType = CommandType.Text;
                OleDbDataAdapter myDataAdaptorAD = new OleDbDataAdapter(commandAD);
                myDataAdaptorAD.Fill(ds, "ResourceLevelForecast");
                dtn = ds.Tables;

                int Flag = 0;

                foreach (var item in dtn[0].Rows[1].ItemArray)
                {
                     Flag = Flag + 0;

                    if (item.ToString() == "FY20")
                    {
                        cciFlag = Flag + 5;
                        break;
                    }
                    Flag++;
                    
                }

            }
        }
        public String GetTimestamp(DateTime value)
        {
            return value.ToString("yyyyMMddHHmmss");
        }


        
    }
}
