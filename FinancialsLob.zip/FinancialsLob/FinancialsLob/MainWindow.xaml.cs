﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FinancialsLob
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Filters> Filter = new List<Filters>();
       

        public MainWindow()
        {
            InitializeComponent();
        }
        private void button_Click(object sender, RoutedEventArgs e)
        {
            getData(@"D:\Financial_LOB\");
        }

        public void getData(string path)
        {
            DirectoryInfo di = new DirectoryInfo(path);
            FileInfo[] FileReport = di.GetFiles("*.xlsb");
            FileInfo[] FileTemplate = di.GetFiles("*.xlsx");

            string con1 = "";
            DataSet ds = new DataSet();
            DataTableCollection dt = ds.Tables;

            con1 =
@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + FileTemplate[0].FullName + " ;" +
@"Extended Properties='Excel 12.0;HDR=NO;IMEX=1'";

            

            if (FileTemplate[0].Name.Contains("Template"))
            {
                using (OleDbConnection connection = new OleDbConnection(con1))
                {
                    connection.Open();

                    OleDbCommand commandAD = new OleDbCommand("select * from [Sheet1$]", connection);
                    commandAD.CommandType = CommandType.Text;
                    OleDbDataAdapter myDataAdaptorAD = new OleDbDataAdapter(commandAD);
                    myDataAdaptorAD.Fill(ds, "Template");
                    dt = ds.Tables;

                }
            }

           

            LoadGrid(dt, FileReport);


        }

        public void LoadGrid(DataTableCollection dt , FileInfo[] FileReport)
        {
            foreach (DataRow row in dt[0].Rows.Cast<DataRow>().Skip(1))
            {

                if (row.ItemArray != null)
                    if (!row.ItemArray.All(x => x == null || (x != null && string.IsNullOrWhiteSpace(x.ToString()))))
                    {
                        Filter.Add(new Filters
                        {
                            rolename = row.ItemArray[0].ToString(),
                            level = row.ItemArray[1].ToString(),
                            comparison = row.ItemArray[2].ToString(),

                        }

                         );



                    }

            }

            DataSet ds = new DataSet();
            DataTableCollection dtn = ds.Tables;


            string con2 =
@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + FileReport[0].FullName + " ;" +
@"Extended Properties='Excel 12.0;HDR=NO;IMEX=1'";


            if (FileReport[0].Name.Contains("LOB Financials"))
            {
                using (OleDbConnection connection = new OleDbConnection(con2))
                {
                    connection.Open();
         
                     OleDbCommand commandAD = connection.CreateCommand();
                     commandAD.CommandType = CommandType.Text;
                     string tableName = String.Format("[{0}$]", "Resource Level Forecast");
                    string filt = Filter[0].rolename.ToString();

                     commandAD.CommandText = String.Format("SELECT F3, F5, F6, F7, F9 FROM {0} where F6 = '{1}'", tableName, filt);
                     commandAD.CommandType = CommandType.Text;
                     OleDbDataAdapter myDataAdaptorAD = new OleDbDataAdapter(commandAD);
                     myDataAdaptorAD.Fill(ds, "ResourceLevelForecast");
                     dtn = ds.Tables;


                }
            }

            var t = new DataTable();
            t.Columns.Add(new DataColumn("Personnel #"));
            t.Columns.Add(new DataColumn("Enterprise id"));
            t.Columns.Add(new DataColumn("Role Name"));
            t.Columns.Add(new DataColumn("Level"));
            t.Columns.Add(new DataColumn("WO Number"));


            // Add data to DataTable
            for (int lineNumber = 1; lineNumber < dtn[0].Rows.Count; lineNumber++)
            {
                DataRow newRow = t.NewRow();
                for (int column = 0; column < dtn[0].Columns.Count; column++)
                {
                    newRow[column] = dtn[0].Rows[lineNumber][column];
                }
                t.Rows.Add(newRow);
            }

            dtGrid.Visibility = Visibility.Visible;
            dtGrid.ItemsSource = t.DefaultView;
            Label1.Visibility= Visibility.Visible;
            Label1.Content = "Total number of rows : " + t.Rows.Count;



        }
    }
}
