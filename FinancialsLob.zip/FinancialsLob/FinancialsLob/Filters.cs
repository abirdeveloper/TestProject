﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinancialsLob
{
    class Filters
    {
        public string rolename { get; set; }
        public string level { get; set; }
        public string comparison { get; set; }
    }

}
